
#include "danxincl.h"

// Global var
extern Body *bdp;
extern Exbd *exbd[NCORES];
unsigned int mskdhnp,mskdrvp,mskcndp,mskcolp;
unsigned int mskdhnn,mskdrvn,mskcndn,mskcoln;

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void set_fpu (unsigned int mode)
{
//asm ("fldcw %0" : : "m" (*&mode));
//control87(_PC_53, MCW_PC);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Intpower(int bb,int ee) {
int ii,res;

res=1; for(ii=0;ii<ee;ii++) res*=bb;
return res;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Rnd1(int rnmax) {
return (int)(rnmax*(rand()/(RAND_MAX+1.0))); }

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Rnds(int rnmax) {
return (int)pow(-1,(double)Rnd1(rnmax))*Rnd1(rnmax); }

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
float Sigmoid0(float xx,float ss) {
   float res=(float)(1/(1+exp(-ss*xx))-0.5); return res;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Mysortxxxx(float par[],int szar,int opt,int ord[]) {
int   ii,jj,xii,*flags; float xval;
// opt=0: descending order,opt=1: ascending order

xval=0; xii=0; // to avoid warning
flags=(int *)malloc(sizeof(int)*szar);
for(ii=0;ii<szar;ii++) flags[ii]=YA;
for(ii=0;ii<szar;ii++) {
   if((ii%10000==0)&&(ii!=0)) printf("% d",ii);
   if(opt==0) { xval=-1; xii=0; } // max
   if(opt==1) { xval=+2; xii=0; } // min
   for(jj=0;jj<szar;jj++) {
      if(opt==0) if((xval<par[jj])&&(flags[jj]==YA)) { xval=par[jj]; xii=jj; }
      if(opt==1) if((xval>par[jj])&&(flags[jj]==YA)) { xval=par[jj]; xii=jj; }
   }
   ord[ii]=xii;
   flags[xii]=NO;
}
free(flags);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Compare (const void * a, const void * b) {
const Dgx *cga = (const Dgx *)a;
const Dgx *cgb = (const Dgx *)b;

if(cga->timer <cgb->timer) return -1;
if(cga->timer==cgb->timer) return  0;
if(cga->timer >cgb->timer) return  1;

return -1;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Ftsortxdgx(int thid,float par[],int szar,int opt,Dgx *ard,Dgx *ars) {
Exbd *edp=exbd[thid];

qsort (ars, szar, sizeof(Dgx), Compare);
memcpy(&ard[0],&ars[0],sizeof(Dgx)*szar);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Compare_dgf (const void * a, const void * b) {
const Dgf *dfa = (const Dgf *)a;
const Dgf *dfb = (const Dgf *)b;

if(dfa->actgen >dfb->actgen) return -1;
if(dfa->actgen==dfb->actgen) return  0;
if(dfa->actgen <dfb->actgen) return  1;

return -1;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Ftsortxdgf(int thid,float par[],int szar,int opt,Dgf *cfardst) {
Exbd *edp=exbd[thid];

qsort (cfardst, szar, sizeof(Dgf), Compare_dgf);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Compare_sigel (const void * a, const void * b) {
const Sigel *sea = (const Sigel *)a;
const Sigel *seb = (const Sigel *)b;

if(sea->sigdlt <seb->sigdlt) return -1;
if(sea->sigdlt >seb->sigdlt) return +1;
if(sea->sigdlt==seb->sigdlt) {
if(sea-> cd.x <seb-> cd.x) return -1;
if(sea-> cd.x >seb-> cd.x) return +1;
if(sea-> cd.x==seb-> cd.x) {
if(sea-> cd.y <seb-> cd.y) return -1;
if(sea-> cd.y >seb-> cd.y) return +1;
if(sea-> cd.y==seb-> cd.y) {
if(sea-> cd.z <seb-> cd.z) return -1;
if(sea-> cd.z >seb-> cd.z) return +1;
if(sea-> cd.z==seb-> cd.z) return +0;
}
}
}

return -1;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Fsortsigca(int thid,int szar,Sigel *sigcar) {
Exbd *edp=exbd[thid];

qsort (sigcar, szar, sizeof(Sigel), Compare_sigel);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*int Compare_ntpar (const void * a, const void * b) {
const Ntpel *nta = (const Ntpel *)a;
const Ntpel *ntb = (const Ntpel *)b;

if(nta->mother <ntb->mother) return -1;
if(nta->mother >ntb->mother) return  1;
if(nta->mother==ntb->mother) {
   if(nta->ptr >ntb->ptr) return -1;
   if(nta->ptr==ntb->ptr) return  0;
   if(nta->ptr <ntb->ptr) return  1;
}

return -1;
}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Compare_ntpar (const void * a, const void * b) {
const Ntpel *nta = (const Ntpel *)a;
const Ntpel *ntb = (const Ntpel *)b;

if(nta->ptr >ntb->ptr) return -1;
if(nta->ptr <ntb->ptr) return  1;
if(nta->ptr==ntb->ptr) {
if(nta->cds[0].x <ntb->cds[0].x) return -1;
if(nta->cds[0].x >ntb->cds[0].x) return +1;
if(nta->cds[0].x==ntb->cds[0].x) {
if(nta->cds[0].y <ntb->cds[0].y) return -1;
if(nta->cds[0].y >ntb->cds[0].y) return +1;
if(nta->cds[0].y==ntb->cds[0].y) {
if(nta->cds[0].z <ntb->cds[0].z) return -1;
if(nta->cds[0].z >ntb->cds[0].z) return +1;
if(nta->cds[0].z==ntb->cds[0].z) return +0;
}
}
}

return -1;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Fsortntpdr(int thid,int szar,Ntpel *ntpar) {
Exbd *edp=exbd[thid];

qsort (ntpar, szar, sizeof(Ntpel), Compare_ntpar);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Mysortxdgx(int thid,float par[],int szar,int opt,Dgx *ard,Dgx *ars) {
int   ci;
Exbd *edp=exbd[thid];

for(ci=0;ci<szar;ci++) edp->ordaux[ci]=ci;
Mysortxxxx(&par[0],szar,opt,&edp->ordaux[0]);
for(ci=0;ci<szar;ci++)
   memcpy(&edp->dgaro[ci],&ars               [ci] ,sizeof(Dgx));
for(ci=0;ci<szar;ci++)
   memcpy(&ard   [ci],&edp->dgaro[edp->ordaux[ci]],sizeof(Dgx));
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Mysortlrxx(int thid,float par[],int szar,int opt,Clsr *ard[],Clsr *ars[]){
int   ii;
Exbd *edp=exbd[thid];

for(ii=0;ii<szar;ii++) edp->auxarr[ii]=ii;
Mysortxxxx(&par[0],szar,opt,&edp->auxarr[0]);
for(ii=0;ii<szar;ii++)
   memcpy(&ard[ii],&ars[edp->auxarr[ii]],sizeof(Clsr *));
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Gencpy(int gen1[],int gen0[],int b0,int ncopied)
{
if(gen0!=NULL) memcpy(&gen1[b0],&gen0[b0],sizeof(int)*ncopied);
else memset(&gen1[b0],0,sizeof(int)*ncopied);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Leavexec(char * str) {
printf(str); printf("\n"); exit(1); }

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Cvint2base(int basear[],int *ndec0,int szar,int base,int *arind) {
int   ii,ndec;

// Least significant digit in last array position
*arind=*arind; // To avoid warnings
ndec=*ndec0;
for(ii=0;ii<szar;ii++) {
   basear[szar-1-ii]=ndec % base;
   ndec=ndec/base;
}
if(*arind!=-1) *arind+=szar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Cvbase2int(int basear[],int *ndec0,int szar,int base,int *arind) {
int  ii;

// Least significant digit in last array position
*ndec0=0;
for(ii=0;ii<szar;ii++)
   // *ndec0+=(int)pow(base,ii)*basear[szar-1-ii];
   *ndec0+=(int)Intpower(base,ii)*basear[szar-1-ii];
if(*arind!=-1) *arind+=szar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Cvbase2flt(int basear[],float *nflt0,int szar,int base,int *arind) {
int  ndec0; float maxval;

Cvbase2int(basear,&ndec0,szar,base,arind);
maxval=(float)Intpower(base,szar);
*nflt0=((ndec0/maxval)-(float)0.5)*2;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Varrescale(int *var,int scale0,int scale1) {
double fvar;

fvar=(double)*var;                  //fvar:   [0,scale0-1]
fvar=fvar/(double)(scale0-1);       //fvar:   [0,1]
// *var=(int)(fvar*(scale1-1));     //ivar:   [0,scale1-1]
fvar=fvar*(scale1-1);               //fvar:   [0,scale1-1]
// *var=floor(fvar+0.5);            //fvar:   [0,scale1-1] rounded
*var=(int)floor(fvar+0.5);          //fvar:   [0,scale1-1] rounded
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Mocmatch(int *mos,int *moc,int naposmin,int fscmax,int *napos,int *fsc) {
int ii,ui,vi,done,aiv,biv;

for(ii=0;ii<2;ii++) {
   vi=0;
   for(ui=0;ui<CLKMAX;ui++) {
      if (ii==0) aiv=mos[ui];
      if (ii==1) aiv=moc[ui];
      if (mos[ui]==-1) { printf("\n%d %d",ii,ui); Leavexec("osti "); }
      if (aiv==-1) return NO;
      if (aiv!= 0) {
         done=NO;
         while ((done==NO)&&(vi<CLKMAX)) {
            if (ii==0) biv=moc[vi];
            if (ii==1) biv=mos[vi];
            if (aiv==biv) done=YA; vi++;
         }
         if (done==NO) return NO;
      }
   }
}

*napos=CLKMAX; *fsc=0;
return YA;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*int Mocmatch(int *mos,int *moc,int naposmin,int fscmax,int *napos,int *fsc,int swc) {
int ii; // napos: nr of active positions

(*napos)=0; (*fsc)=0;
for(ii=0;ii<ASMAX;ii++) {
   if (mos[ii]==-1) printf("osti ");
   if (mos[ii]!=-1) (*napos)++;
   if((mos[ii]!=-1)&&(mos[ii]!=moc[ii])) (*fsc)++;
   if((*fsc)>fscmax) return NO;
}
if((*napos>=naposmin)&&((*fsc)<=fscmax)) return YA; else return NO;
}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Moccopy(int mocd[],int mocs[])
{
for(int hi=0;hi<CLKMAX;hi++) mocd[hi]=mocs[hi];
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
double Distance(int nx,int ny,int nz,int xx,int yy,int zz) {
double fx,fy,fz,dista,distb,dist;
double dstcoa0,dstcoa1,dstcoa2; //dstco: distance component
double dstcob0,dstcob1,dstcob2,dstcob3,dstcob4,dstcob5;

fx=1; fy=1; fz=1;
//fx=(double)0.333*(nx+1); fy=(double)0.333*(ny+1);
//dist=(double)(fx*abs(xx)+fy*abs(yy))/(GRIDX+GRIDY);

dstcoa0=(double)pow((double)(fx*abs(xx)),2);
dstcoa1=(double)pow((double)(fy*abs(yy)),2);
dstcoa2=(double)pow((double)(fz*abs(zz)),2);
dista=  (double)pow((dstcoa0+dstcoa1+dstcoa2),
   (double)0.5)/(GRIDX+GRIDY+GRIDZ);
dstcob0=(double)fabs((fy*abs(yy))-(fz*abs(zz)));
dstcob1=(double)fabs((fx*abs(xx))-(fz*abs(zz)));
dstcob2=(double)fabs((fx*abs(xx))-(fy*abs(yy)));
dstcob3=(double)abs(GRIDX);
dstcob4=(double)abs(GRIDY);
dstcob5=(double)abs(GRIDZ);
#if(NDIMS==2)
distb=  (double)dstcob2/Max3(dstcob3,dstcob4,-1);
#endif
#if(NDIMS==3)
distb=  (double)Max3(dstcob0,dstcob1,dstcob2)/Max3(dstcob3,dstcob4,dstcob5);
#endif
//dist =  (float)0.75*dista+(float)0.25*distb;
dist =  (double)1.00*dista+(double)0.00*distb;

return dist;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
double Dopdst(Coord *aa,Coord *bb) {

return //abs(aa->x-bb->x)+abs(aa->y-bb->y)+abs(aa->z-bb->z);
   sqrt(
      pow((double)(aa->x-bb->x),2)+
      pow((double)(aa->y-bb->y),2)+
      pow((double)(aa->z-bb->z),2));

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
double Dopdxt(Coord *aa,Coord *bb,int sw) {

return
   sqrt(
      pow((double)(aa->x-bb->x),2)+
      pow((double)(aa->y-bb->y),2)+
      pow((double)(aa->z-bb->z),2));

/*if(sw==1) return abs(aa->x-bb->x);
if(sw==2) return abs(aa->y-bb->y);
if(sw==3) return abs(aa->z-bb->z);
return (abs(aa->x-bb->x)+abs(aa->y-bb->y)+abs(aa->z-bb->z));*/
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Gpstatsx(Body *bdp) {

/*// statistics
int npres,dpres,npresind;
npres=0; dpres=0;
for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<popa[pi]->popsz;gy++) {
   gi=pi*POPSZ+gy;
   popa[pi]->Dnadecoder(popa[pi]->guys[gy].dna,NULL);
   npresind=0;
   for(ci=0;ci<dgarsz;ci++) {
      memcpy(&curdgx,&dgar[ci],sizeof(Dgx));
      pres=NO;
      for(ii=0;ii<=dhnr[gi];ii++) {
         if(((Cetmatch(&curdgx.etx[0],&dhar[gi][ii].etc[0],
         NAPMIN,FSCMAX,&sva,&svb,0)==YA))) {
            pres=YA; break; }}
      if(pres==YA) npresind++; }
   dpres+=dgarsz; npres+=npresind; }Max3
Printf2(fp1," presperc: %f ",(float)npres/dpres);*/
// statistics 2
/*int jj,dif,neql;
for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<popa[pi]->popsz;gy++) {
   gi=pi*POPSZ+gy;
   for(ii=0;ii<=dhnr[gi];ii++) {
      neql=0;
      for(jj=0;jj<=dhnr[gi];jj++) {
         dif=NO;
         for(hi=0;hi<=ASMAX;hi++)
            if(dhar[gi][ii].etc[hi]!=dhar[gi][jj].etc[hi]) dif=YA;
         if(dif=NO) neql++; if(neql>1) Printf2(fp1," oh cazzo");
      }
   }
}*/

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Setbitmask(void) {
unsigned int nn,mm;

nn= 0; mm=16; mskdhnp = ~(~0 << mm) << nn;
nn=16; mm= 4; mskdrvp = ~(~0 << mm) << nn;
nn=20; mm= 4; mskcndp = ~(~0 << mm) << nn;
nn=24; mm= 8; mskcolp = ~(~0 << mm) << nn;

nn= 0; mm=16; mskdhnp = ~(~0 << mm) << nn; mskdhnn= ~mskdhnp;
nn=16; mm= 4; mskdrvp = ~(~0 << mm) << nn; mskdrvn= ~mskdrvp;
nn=20; mm= 4; mskcndp = ~(~0 << mm) << nn; mskcndn= ~mskcndp;
nn=24; mm= 8; mskcolp = ~(~0 << mm) << nn; mskcoln= ~mskcolp;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Lreader(int par,Clsr *clp) {

if(par==Ldhn) return (int)clp->dhnrc3;
if(par==Ldrv) return (int)clp->drv;
if(par==Lcnd) return (int)clp->cnd;
if(par==Lcol) return (int)clp->col;

return -1;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*int Lreader(int par,Clsr *clp) {
unsigned int res;

if(par==Ldhn) {
   res=clp->dhnrc3 & mskdhnp;
   return (int)(res>> 0);
}
if(par==Ldrv) {
   res=clp->dhnrc3 & mskdrvp;
   return (int)(res>>16);
}
if(par==Lcnd) {
   res=clp->dhnrc3 & mskcndp;
   return (int)(res>>20);
}
if(par==Lcol) {
   res=clp->dhnrc3 & mskcolp;
   return (int)(res>>24);
}

return -1;
}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*int Lreader(int par,Clsr *clp) {
int res;

if(par==Ldhn) {
   res=clp->dhnrc3%10000;
}

if(par==Ldrv) {
   res=(clp->dhnrc3/10000)%10;
}

if(par==Lcnd) {
   //return clp->clcnd;
   if(clp->dhnrc3==65535) res=CLNOCEL;
   else                   res=(clp->dhnrc3/100000)%10;
}

if(par==Lcol) {
   res=clp->dhnrc3/1000000;
}

return res;
}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Lwriter(int par,Clsr *clp,int dhnneu,int drvneu,int cndneu,int colneu) {

if(dhnneu!=-1) clp->dhnrc3=(unsigned short)dhnneu;
if(drvneu!=-1) clp->drv   =(unsigned  char)drvneu;
if(cndneu!=-1) clp->cnd   =(unsigned  char)cndneu;
if(colneu!=-1) clp->col   =(unsigned  char)colneu;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*void Lwriter(int par,Clsr *clp,int dhnneu,int drvneu,int cndneu,int colneu) {
unsigned int res;

if(dhnneu!=-1) {
   res=clp->dhnrc3 & mskdhnn;
   clp->dhnrc3=res | (dhnneu<< 0);
}

if(drvneu!=-1) {
   res=clp->dhnrc3 & mskdrvn;
   clp->dhnrc3=res | (drvneu<<16);
}

if(cndneu!=-1) {
   res=clp->dhnrc3 & mskcndn;
   clp->dhnrc3=res | (cndneu<<20);
}

if(colneu!=-1) {
   res=clp->dhnrc3 & mskcoln;
   clp->dhnrc3=res | (colneu<<24);
}

}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*void Lwriter(int par,Clsr *clp,int dhnneu,int drvneu,int cndneu,int colneu) {
int  dhnold,drvold,cndold,colold;

if(dhnneu!=-1) {
   dhnold=clp->dhnrc3%10000;
   clp->dhnrc3-=dhnold;
   clp->dhnrc3+=dhnneu;
}

if(drvneu!=-1) {
   drvold=(clp->dhnrc3/10000)%10;
   clp->dhnrc3-=(drvold*10000);
   clp->dhnrc3+=(drvneu*10000);
}

if(cndneu!=-1) {
   //clp->clcnd=cndneu;
   cndold=((clp->dhnrc3/100000)%10);
   clp->dhnrc3-=(cndold*100000);
   clp->dhnrc3+=(cndneu*100000);
}

if(colneu!=-1) {
   colold=(clp->dhnrc3/1000000);
   clp->dhnrc3-=(colold*1000000);
   clp->dhnrc3+=(colneu*1000000);
}

}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
double Max3(double d0,double d1,double d2) {
double res;

res=(d0 >=d1) ? d0  : d1;
res=(res>=d2) ? res : d2;

return res;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Surfint(int as,Coord *cd,Exbd *edp) {
int preres=NO; int xx,yy,zz;
int cr_000,crm100,crp100,crm010,crp010,crm001,crp001;
int aiv,oiv;

xx=cd->x; yy=cd->y; zz=cd->z;

// if "in interior grid" xy & z
if(!((xx>=1)&&(xx<GRIDX-1)&&(yy>=1)&&(yy<GRIDY-1)&&(zz>=1)&&(zz<GRIDZ-1)))
   return YA;
else if(edp->clarcnd[xx][yy][zz]==1) preres=YA;

if(preres==NO) return NO;

cr_000=0; crm100=0; crp100=0; crm010=0; crp010=0; crm001=0; crp001=0;

cr_000=Lreader(Ldhn,&edp->clar[xx-0][yy-0][zz-0]);
crm100=Lreader(Ldhn,&edp->clar[xx-1][yy-0][zz-0]);
crp100=Lreader(Ldhn,&edp->clar[xx+1][yy-0][zz-0]);
crm010=Lreader(Ldhn,&edp->clar[xx-0][yy-1][zz-0]);
crp010=Lreader(Ldhn,&edp->clar[xx-0][yy+1][zz-0]);
crm001=Lreader(Ldhn,&edp->clar[xx-0][yy-0][zz-1]);
crp001=Lreader(Ldhn,&edp->clar[xx-0][yy-0][zz+1]);

// if borderline xy & z (24-20 > 22-20) (4-0 > 2-0)
if(preres==YA) if((edp->clarcnd[xx-1][yy-0][zz-0]==0)||(crm100!=cr_000)) return YA;
if(preres==YA) if((edp->clarcnd[xx+1][yy-0][zz-0]==0)||(crp100!=cr_000)) return YA;
if(preres==YA) if((edp->clarcnd[xx-0][yy-1][zz-0]==0)||(crm010!=cr_000)) return YA;
if(preres==YA) if((edp->clarcnd[xx-0][yy+1][zz-0]==0)||(crp010!=cr_000)) return YA;
if(preres==YA) if((edp->clarcnd[xx-0][yy-0][zz-1]==0)||(crm001!=cr_000)) return YA;
if(preres==YA) if((edp->clarcnd[xx-0][yy-0][zz+1]==0)||(crp001!=cr_000)) return YA;

return NO;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*int Surfint(Coord *cd,Exbd *edp) {
int preres,xx,yy,zz,ax,ay,az,aiv,ii;

xx=cd->x; yy=cd->y; zz=cd->z;

// if "in interior grid" xy & z
preres=NO;
if((xx>=1)&&(xx<GRIDX-1))
if((yy>=1)&&(yy<GRIDY-1))
if((zz>=1)&&(zz<GRIDZ-1)) {
   aiv=Lreader(Lcnd,&edp->clar[xx][yy][zz]);
   if((aiv==CLALIVE)||(aiv==CLALIVN)) preres=YA;
}
if(preres==NO) return NO;

// if borderline xyz
for(ii=0;ii<6;ii++) {
   if(ii==0) { ax=-1; ay=-0; az=-0; }
   if(ii==1) { ax=+1; ay=-0; az=-0; }
   if(ii==2) { ax=-0; ay=-1; az=-0; }
   if(ii==3) { ax=-0; ay=+1; az=-0; }
   if(ii==4) { ax=-0; ay=-0; az=-1; }
   if(ii==5) { ax=-0; ay=-0; az=+1; }
   aiv=Lreader(Lcnd,&edp->clar[xx+ax][yy+ay][zz+az]);
   if((aiv!=CLALIVE)&&(aiv!=CLALIVN)) return YA;
}

return NO;
}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Setedges(Coord *el,Coord *eh,Coord ed[]) {

// coordinates : BACK
ed[0].x=el->x; ed[0].y=el->y; ed[0].z=el->z;//NW, B
ed[1].x=eh->x; ed[1].y=el->y; ed[1].z=el->z;//NE, B
ed[2].x=el->x; ed[2].y=eh->y; ed[2].z=el->z;//SW, B
ed[3].x=eh->x; ed[3].y=eh->y; ed[3].z=el->z;//SE, B
// coordinates : FRONT
ed[4].x=el->x; ed[4].y=el->y; ed[4].z=eh->z;//NW, F
ed[5].x=eh->x; ed[5].y=el->y; ed[5].z=eh->z;//NE, F
ed[6].x=el->x; ed[6].y=eh->y; ed[6].z=eh->z;//SW, F
ed[7].x=eh->x; ed[7].y=eh->y; ed[7].z=eh->z;//SE, F

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Getthid(Exbd **edpp) {
int thid=0;

#if(MYOMP==1)
thid = omp_get_thread_num();
#endif
#if(MYMPI==1)
MPI_Comm_rank(MPI_COMM_WORLD,&thid);
#endif

*edpp=exbd[thid];

return thid;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Mpscpy(char *sndbuf, void *srcdat, int size, int *cnt) {

memcpy(sndbuf,srcdat,size); *cnt+=size;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Mprcpy(void *dstdat, char *recbuf, int size, int *cnt) {

memcpy(dstdat,recbuf,size); *cnt+=size;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Avgcd(Coord cdar[],int szar,Coord *avgcd) {
int  ii,aiv;
Coord *crd,lcd,vcd;
double dista,distb;

// average position in field
lcd.x=0; lcd.y=0; lcd.z=0;
for(ii=0;ii<szar;ii++) {
   crd=&cdar[ii]; lcd.x+=crd->x; lcd.y+=crd->y; lcd.z+=crd->z; }
lcd.x/=szar; lcd.y/=szar; lcd.z/=szar;
dista=8888; aiv=-1;
for(ii=0;ii<szar;ii++) {
   distb=Dopdst(&cdar[ii],&lcd);
   if(dista>distb) { dista=distb; aiv=ii; }
}
memcpy(avgcd,&cdar[aiv],sizeof(Coord));

}

//!----------------------------------------------------------------------------------------
//! fctheader
//!----------------------------------------------------------------------------------------
void Printf3(FILE *fptr, char *fmt) {

fprintf(stdout,"%s",fmt);
fprintf( fptr, "%s",fmt);

}

//!----------------------------------------------------------------------------------------
//! fctheader
//!----------------------------------------------------------------------------------------
void Sanchkdob(double *var,double aa,double bb) {

if(*var<aa) *var=aa; if(*var>bb) *var=bb;

}
