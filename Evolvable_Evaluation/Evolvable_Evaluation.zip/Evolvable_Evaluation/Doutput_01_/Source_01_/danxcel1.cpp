
#include "danxincl.h"

// Global var
Exbd *exbd[NCORES]; char cvar;

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int  main(int argc, char *argv[], char *env[]) {
int  ii,opt,mrar[20],mrtot;
long int msa,msb,msc,msd;
Body *bdp;
//Exbd *edp=exbd[0];

#if(DEBUG0==YA)
double a=3.0,b=7.0,c;

set_fpu (0x27F);  // use double-precision rounding

c=a/b;
if (c==a/b) printf ("comparison succeeds\n");
else        printf ("unexpected result");
#endif

#if(DEBUG7==YA)
int ei,gu; double bdv;
for(ii=1;ii<=20;ii++) {
   printf("\n");
   for(ei=0;ei<ii;ei++) {
      bdv=NNGUYS/(double)ii; gu=(int)(bdv*(ei+1));
      if (ei==ii-1) gu=NNGUYS; printf(" %3d",gu);
   }
}
#endif

#if(DEBUG0==YA)
mrar[ 0]=sizeof( Clsr)*SZGRID      /(1024*1024); // clar
mrar[ 1]=sizeof( Clsr)*SZGRID      /(1024*1024); // clar0
mrar[ 2]=sizeof( Clsr)*8*DPVMAX    /(1024*1024); // clarq
mrar[ 3]=sizeof( int )*SZGRID      /(1024*1024); // clarcnd
mrar[ 4]=sizeof(Coord)*SZGRID      /(1024*1024); // rrorder
mrar[ 5]=sizeof(float)*SZGRID      /(1024*1024); // rrorderdist
mrar[ 6]=sizeof( int )*SZGRID      /(1024*1024); // rrord
mrar[ 7]=sizeof( Clsr)*SZGRID      /(1024*1024); // clarf
mrar[ 8]=sizeof( int )*SZGRID      /(1024*1024); // etisooodp0grid
mrar[ 9]=sizeof( int )*SZGRID      /(1024*1024); // cdisooodp0grid
mrar[10]=sizeof( int )*SZGRID      /(1024*1024); // cdtgooodplgrid
mrar[11]=sizeof( Dpel)*SZGRID      /(1024*1024); // ooactdsgrid
mrar[12]=sizeof( Dpel)*SZGRID      /(1024*1024); // bstepsgrid
mrar[13]=sizeof( Dpel)*SZGRID      /(1024*1024); // estepsgrid
mrar[14]=sizeof( Dpel)*SZGRID      /(1024*1024); // xstepsgrid
mrtot=0; for(ii=0;ii<=11;ii++) mrtot+=mrar[ii];

printf("\n\nMemory check, grid-related (MB)\n");
printf("sizeof clar        : %5d  ",mrar[ 0]);
printf("sizeof clar0       : %5d\n",mrar[ 1]);
printf("sizeof clarq       : %5d  ",mrar[ 2]);
printf("sizeof clarcnd     : %5d\n",mrar[ 3]);
printf("sizeof rrorder     : %5d  ",mrar[ 4]);
printf("sizeof rrorderdist : %5d\n",mrar[ 5]);
printf("sizeof rrord       : %5d  ",mrar[ 6]);
printf("sizeof clarf       : %5d\n",mrar[ 7]);
printf("sizeof etisdp0grid : %5d  ",mrar[ 8]);
printf("sizeof cdisdp0grid : %5d\n",mrar[ 9]);
printf("sizeof cdtgdplgrid : %5d  ",mrar[10]);
printf("sizeof ooactdsgrid : %5d\n",mrar[11]);
//printf("sizeof bstepsgrid  : %5d  ",mrar[12]);
//printf("sizeof estepsgrid  : %5d\n",mrar[13]);
//printf("sizeof xstepsgrid  : %5d  ",mrar[14]);
printf("sizeof tot         : %5d  ",mrtot);

mrar[ 0]=sizeof( Coord)*DHARLS      /(1024*1024); // clardcd
mrar[ 1]=sizeof(  Dse )*DHARLS      /(1024*1024); // dhar
mrar[ 2]=sizeof(  Dgx )*DGARSZ*4    /(1024*1024); // dgar
mrar[ 3]=sizeof( Coord)*DHARLS*2    /(1024*1024); // drvaro
mrar[ 4]=sizeof( Ntpel)*NTPDIRSZ    /(1024*1024); // ntpdir
mrar[ 5]=sizeof(Aposel)*APOSARSZ    /(1024*1024); // aposar
mrar[ 6]=sizeof( Coord)*DHARLS      /(1024*1024); // drvar0
mrtot=0; for(ii=0;ii<=6;ii++) mrtot+=mrar[ii];

printf("\n\nMemory check, gene-related\n");
printf("sizeof clardcd     : %5d\n",mrar[ 0]);
printf("sizeof dhar        : %5d\n",mrar[ 1]);
printf("sizeof dgar        : %5d\n",mrar[ 2]);
printf("sizeof drvaro      : %5d\n",mrar[ 3]);
printf("sizeof ntpdir      : %5d\n",mrar[ 4]);
printf("sizeof aposar      : %5d\n",mrar[ 5]);
printf("sizeof drvar0      : %5d\n",mrar[ 6]);
printf("sizeof tot         : %5d  ",mrtot);

mrar[ 0]=sizeof( Exbd)              /(1024*1024); // Exbd
mrar[ 1]=sizeof( Guy )*NNGUYS       /(1024*1024); // popa
mrar[ 2]=sizeof( int )*SZGRID*3     /(1024*1024); // envr
mrar[ 3]=sizeof( Dpel)*SZGRID*1     /(1024*1024); // envr
mrtot=0; for(ii=0;ii<=3;ii++) mrtot+=mrar[ii];

printf("\n\nMemory check, alternative (MB)\n");
printf("sizeof Exbd  x core: %5d\n",mrar[ 0]);
printf("sizeof popa  x core: %5d\n",mrar[ 1]);
printf("sizeof envr  x core: %5d\n",mrar[ 2]);
printf("sizeof envr  x core: %5d\n",mrar[ 3]);
printf("tot          x core: %5d\n",mrtot);

printf("\n\nMemory check, other\n");
//printf("sizeof uns int       %5d\n",sizeof(unsigned int));
//printf("bases of dev gene       : %d\n" ,DGENSQ);
//printf("bases of operator       : %d\n" ,OXRXSQ);
//printf("bases of single gene    : %d\n" ,SGENSQ);
#endif

// HINT UNIX
// srand(time(0));
srand(RNSEED);

bdp =new Body();

if(argv[1]!=NULL) opt=0;
else              opt=1;

#if(RELOAD==YA)
opt=0;
#endif

bdp->Baseloop(opt,bdp);

return 0;
}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
Body::Body(void) {}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Baseloop(int opt,Body *bdp) {
char  *atmpstr,*atmpstr1,*buffer;
int   thid,gi,pi,gy,as,ls,us,ri,ei,ce,vx,vy,vz,ii,hi,si,gl,gu,ff,eval,di;
int   rn,aa,bb,aiv,biv,civ,bi,size,ddone;
int   moctmp[CLKMAX];
long  t0,t1,buflen,buflen0,buflen1,buflen3;
float shas;
double gph,bdv;
FILE  *fp=NULL; // to avoid warning
Exbd  *edp;
Guy   *gyp,*gzp,*gtp;
#if(MYMPI==1)
int rc;
MPI_Status stat;
#endif

#if(MYOMP==1)
//omp_set_ynamic(0);
omp_set_num_threads(NCORES);
#endif

#if(MYMPI==1)
rc=MPI_Init(NULL,NULL);
if (rc!=MPI_SUCCESS)
 { printf ("Error MPI: Abort.\n"); MPI_Abort(MPI_COMM_WORLD, rc); }
else
 { printf ("\nMPI_Init ok\n"); }
MPI_Comm_size (MPI_COMM_WORLD,&size); printf ("size: %d\n",size);
#endif

// calc buflen
// sendrec_0
buflen0 =sizeof(int);
buflen0+=sizeof(int)*SZGRID; if(ISGRID==1) buflen0*=3;
buflen0+=sizeof(Mtv);
// sendrec_1
buflen1 =sizeof(int)*6;
buflen1+=sizeof(Guy);
buflen1+=sizeof(int)* NNGUYS;
buflen1+=sizeof_gen_*(NNGUYS/NCORES+1);
buflen1+=BEGNSQ*(NNGUYS/NCORES+1);
// sendrec_3
buflen3 =sizeof(int);
buflen3+=sizeof(int);
buflen3+=sizeof(float)*(NNGUYS/NCORES+1);
buflen3+=sizeof(float)*(NNGUYS/NCORES+1);
#if(MOCDEV==YA)
buflen3+=sizeof( Dse )*(NNGUYS/NCORES+1)*DHARLS;
buflen3+=sizeof( Dgx )*(NNGUYS/NCORES+1);
#endif
#if(TAGCHK==YA)
// frgenes
buflen3+=sizeof( Dgx )*(NNGUYS/NCORES+1)*(DGEVXX*CLKMAX);
#endif
// calc
buflen=(buflen1>=buflen0) ? buflen1 :buflen0;
buflen=(buflen3>=buflen ) ? buflen3 :buflen ;
printf("%ld %ld %ld %ld",buflen0,buflen1,buflen3,buflen);

buffer=(char*)malloc(buflen);

// calc all -----------------------------------------------------------------
#if(MYOMP==1)
#pragma omp parallel private(ei,thid,pi)
#endif
for(ei=0;ei<NCORES;ei++) {
   thid=Getthid(&edp);
   if (thid==ei)
    { exbd[ei] = (Exbd *)malloc(sizeof(Exbd ));
      for(pi=0;pi<NPOPUL;pi++) exbd[ei]->popa[pi]=new Pop(ei,this);
      bdp->Initlocv(ei);
      bdp->Bodinit(ei);
      bdp->Envinit(ei,0);
      exbd[ei]->fdone=0; }
   printf("\nThread %d ", thid);
}
// calc all_end -------------------------------------------------------------

#if(DEBUG0==YA)
//Leavexec("esco");
#endif

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   //Txt2vtk(thid,1,46); exit(0);
}
// calc master_end ----------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   thid=Getthid(&edp);
   //bdp->Iogener(thid);
   //Calcmfitdist();
}
// calc master_end ----------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   if(opt==0) bdp->Loadmemo(0);
   if(opt==1) edp->cn0=0;
}
// calc master_end ----------------------------------------------------------

gtp=(Guy*)malloc(sizeof(Guy));
atmpstr  =(char *)malloc(200);
atmpstr1 =(char *)malloc(200);

// calc master --------------------------------------------------------------
remove(CONSFN);
thid=Getthid(&edp);
if (thid==0) {
   if(ISGRID==1) { strcpy(atmpstr1,CETISFN); Loadgrid(0,atmpstr1,0,MNTGFN); }
   if(ISGRID==1) { strcpy(atmpstr1, CDISFN); Loadgrid(0,atmpstr1,1,MNTGFN); }
   strcpy(atmpstr1,CDTGFN);
   Loadgrid(0,atmpstr1,2,MNTGFN);
   Dsload(0);
   for(ii=0;ii<CLKMAX;ii++) edp->evtnr0[ii]=0;
}
// calc master_end ----------------------------------------------------------

Sendrec0(0,buffer,&buflen0);

t0=(long)time(0);
thid=Getthid(&edp);
for(edp->cn=edp->cn0;edp->cn<=CYCLES;edp->cn++) {

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      fp=fopen(CONSFN, "a");
      edp->ausdr=0; if(((edp->cn-1)%SHOWPACE)==0) edp->ausdr=1;
      sprintf(atmpstr,"\n%d ",edp->cn);
      if(edp->ausdr==1) Printf3(fp,atmpstr);
      else              fprintf(stdout,"X");
      edp->pnr=1;
   }
   // calc master_end -------------------------------------------------------

   // calc master -----------------------------------------------------------
   // rnd permutation
   thid=Getthid(&edp);
   if (thid==0) {
      for(gi=0;gi<NNGUYS;gi++) edp->rndpmt[gi]=gi;
      for(gi=1;gi<NNGUYS;gi++) {
         rn=Rnd1(NNGUYS-1)+1; // 0 is excluded
         aa=edp->rndpmt[gi];
         bb=edp->rndpmt[rn];
         edp->rndpmt[gi]=bb;
         edp->rndpmt[rn]=aa;
      }
   }
   // calc master_end -------------------------------------------------------

   GSLAVE:cvar=cvar; // slave starts here
   #if(MYOMP==1)
   thid=Getthid(&edp);
   if (thid!=0) for(ei=0;ei<NCORES;ei++) exbd[ei]->cn=exbd[0]->cn;
   #endif
   #if(MYMPI==1)
   thid=Getthid(&edp);
   if (thid!=0) edp->cn++;
   #endif

   // calc all --------------------------------------------------------------
   #if(MYOMP==1)
   #pragma omp parallel private(ei,thid,pi)
   #endif
   for(ei=0;ei<NCORES;ei++) {
      thid=Getthid(&edp);
      if (thid==ei) {
         // gq
         if((0<=edp->cn)&&(edp->cn<edp->frz[0].ge)) edp->gq=0;
         for(ii=0;ii<NAMS-1;ii++)
            if((edp->frz[ii].ge<=edp->cn)&&(edp->cn<edp->frz[ii+1].ge))
             { edp->gq=ii+1; break; }
         // boundaries of evolved sector, as number of dev. genes
         edp->dgarxf=edp->frz[edp->gq].xf;
         edp->dgarsz=edp->frz[edp->gq].xe;
         // boundaries of evolved sector, as number of bases
         for(pi=0;pi<NPOPUL;pi++) {
            edp->popa[pi]->dnaxf=(BEGNSQ+(DGENSQ*edp->dgarxf));
            edp->popa[pi]->dnasz=(BEGNSQ+(DGENSQ*edp->dgarsz));
         }
      }
   }
   // calc all_end ----------------------------------------------------------

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      #if(PGFREEZE==YA)
      // copies frozen sector into all genomes
      aiv=BEGNSQ;              // boundaries of frozen sector
      biv=edp->popa[0]->dnaxf; // boundaries of frozen sector
      for(pi=0;pi<NPOPUL;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++)
         if(gi!=0)
          { gyp=&edp->popa[pi]->guys[gy];
            gzp=&edp->popa[ 0]->guys[ 0];
            memcpy(&gyp->gen[aiv],&gzp->gen[aiv],sizeof(int)*(biv-aiv)); }
      #endif
      Prexline(0);
      memcpy(&edp->guyf,&edp->popa[0]->guys[0],sizeof(Guy));
   }

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      strcpy(atmpstr,"\n[gq: %d ge: %5d xf: %3d xe: %3d ls: %d up: %d]");
      if(edp->ausdr==1) {
         printf(atmpstr,edp->gq,edp->frz[edp->gq].ge,edp->frz[edp->gq].xf,
         edp->frz[edp->gq].xe,edp->frz[edp->gq].ls,edp->frz[edp->gq].us);
      }
   }

   // calc master -----------------------------------------------------------
   // swaps guys
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=1;aa<NNGUYS;aa++) {
         bb=edp->rndpmt[aa];
         gyp=&edp->popa[aa/POPXSZ]->guys[aa%POPXSZ];
         gzp=&edp->popa[bb/POPXSZ]->guys[bb%POPXSZ];
         memcpy(gtp,gyp,sizeof(Guy));
         memcpy(gyp,gzp,sizeof(Guy));
         memcpy(gzp,gtp,sizeof(Guy));
      }
   }
   // calc master_end -------------------------------------------------------

   Sendrecv(1,buffer,&buflen1,&buflen3);

   // calc all --------------------------------------------------------------
   #if(MYOMP==1)
   #pragma omp parallel private(ei,thid,pi)
   #endif
   for(ei=0;ei<NCORES;ei++) {
      thid=Getthid(&edp);
      if (thid==ei) {
         Envinit(ei,1); // Inits env (actual grids only)
         edp->fset=0;
         #if(TAGCHK==YA)
         // updates frgenesa and frgenesb, inits frgenesc
         for(gi=0;gi<NNGUYS;gi++) for(di=0;di<(DGEVXX*CLKMAX);di++) {
            memcpy(&edp->frgenesa[gi][di],&edp->frgenesb[gi][di],sizeof(Dgx));
            memcpy(&edp->frgenesb[gi][di],&edp->frgenesc[gi][di],sizeof(Dgx));
            memcpy(&edp->frgenesc[gi][di],&edp->dgx0,sizeof(Dgx));
         }
         #endif
      }
   }
   // calc all_end ----------------------------------------------------------

   // computes extremes
   gl=0; gu=NNGUYS;
   #if(MYMPI==1)
   thid=Getthid(&edp);
   bdv=NNGUYS/(double)NCORES;
   gl=(int)(bdv*thid); gu=(int)(bdv*(thid+1));
   if (thid==NCORES-1) gu=NNGUYS;
   #endif

   #if(MYOMP==1)
   #pragma omp parallel private(gl,gu,gi,thid,edp,pi,gy,as,ls,us,ce,vx,vy,vz,hi,ff,eval,ddone)
   #endif
   if (0==0) {
   gl=0; gu=NNGUYS;
   thid=Getthid(&edp);
   bdv=NNGUYS/(double)NCORES;
   gl=(int)(bdv*thid); gu=(int)(bdv*(thid+1));
   if (thid==NCORES-1) gu=NNGUYS;
   ff=0;
   for(gi=gl;gi<gu;gi++) {
      edp->fset=0;
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      ii=0;
      thid=Getthid(&edp);
      #if(DEBUG0==YA)
      if (thid==0)
         if (edp->ausdr==1) if (gy==0) printf("\nThread %d pi %d", thid, pi);
      #endif
      ii=ii+1; if(ii%100==0) if(ii==0) { printf(" "); ii=1; }
      // Inits clar & dhar
      FORVXYZ memcpy(&edp->clar[vx][vy][vz],&edp->cs0,sizeof(Clsr));
      for(ce=0;ce<DHARLS;ce++) memcpy(&edp->dhar[ce],&edp->dse0,sizeof(Dse));
      // inits mtar
      for(ce=0;ce<DHARLS;ce++) memcpy(&edp->mtar[ce],&edp->mcl0,sizeof(Mcl));
      // Inits zygotes and isgrid
      edp->dhnr=-1;
      //Gridinit(thid,gi,as);
      // Decodes gen
      if(ff==0)
         edp->popa[pi]->Gendecoder(thid,edp->guyf.gen,NULL,0);
      // dgar0
      if(ff==0) for(ce=0;ce<edp->dgarsz;ce++)
          memcpy(&edp->dgar0[ce],&edp->dgar[ce],sizeof(Dgx));
      edp->popa[pi]->Gendecoder(thid,edp->popa[pi]->guys[gy].gen,NULL,1);
      // inits dvfrd
      for(ce=0;ce<edp->dgarsz;ce++) edp->dgar[ce].dvfrd=0;
      // shad & mfit
      if(!((REPLAY==YA)&&(gi==0)&&(ff==1))) {
         edp->popa[pi]->guys[gy].shad=0;
         edp->popa[pi]->guys[gy].mfit=0; }
      // development cycle
      ls=0; us=CLKMAX-1; /*us=CLKMAX-1;*/
      if(edp->fdone!=0) { ls=edp->frz[edp->gq].ls; us=edp->frz[edp->gq].us; }
      for(as=ls;as<=us;as++) {
         #if(DEBUG0==YA)
         //printf("\ncn=%d gi=%d as=%d",edp->cn,gi,as);
         //if(edp->cn==2)if(gi==0)if(as==0)
         // cvar=cvar;
         #endif
         // Inits zygotes and isgrid
         Gridinit(thid,gi,as);
         if ((edp->fdone==0)&&(as==edp->frz[edp->gq].ls)) {
            FORVXYZ memcpy(&edp->clarf[vx][vy][vz],&edp->clar[vx][vy][vz],sizeof(Clsr));
            memcpy(&edp->dharf[0],&edp->dhar[0],sizeof(Dse)*DHARLS);
            memcpy(&edp->mtarf[0],&edp->mtar[0],sizeof(Mcl)*DHARLS);
            edp->dhnrf=edp->dhnr;
            edp->fset=1;
         }
         if ((edp->fdone!=0)&&(as==ls)) {
            FORVXYZ memcpy(&edp->clar[vx][vy][vz],&edp->clarf[vx][vy][vz],sizeof(Clsr));
            memcpy(&edp->dhar[0],&edp->dharf[0],sizeof(Dse)*DHARLS);
            memcpy(&edp->mtar[0],&edp->mtarf[0],sizeof(Mcl)*DHARLS);
            edp->dhnr=edp->dhnrf;
         }
         Disrupt (thid,gi,as);
         Dgarprep(thid,gi,as,ls);
         #if(GRNMODE==YA)
         Grncalc(thid);
         #endif
         Shaper  (thid,gi,as,us);
         //Doper2 (if gi==0 or it has other as ahead or is about to change ms)
         if((as!=us)||(DOPAON==YA)) {
            #if  (DOPNEW==NO)
            Doper2(thid,gi,as);
            #elif(DOPNEW==YA)
            for(hi=0;hi<2000;hi++)
             { memcpy(&edp->pmocs[hi].cd,&edp->cd0,sizeof(Coord));
               edp->pmocs[hi].mother=-1;
               edp->pmocs[hi].smocnu=-1; }
            edp->ps=0;
            ddone=NO; hi=1;
            do {
               edp->ss=0; edp->sstmp=0;
               if((as>=ls)&&(as<=us)) Dopernew(thid,gi,as,hi,3);
               edp->sstmp=edp->ss;
               if((as>=ls)&&(as<=us)) Dopernew(thid,gi,as,hi,2);
               //if(as==1) Doper2(thid,gi,as);
               if(edp->ss<=0) ddone=YA; hi++;
               #if(DOPONE==YA)
               ddone=YA;
               #endif
            } while (ddone==NO);
            #endif
         }
         if ((edp->cn<edp->frz[edp->gq].ge)&&((edp->cn+1)>=edp->frz[edp->gq].ge))
         if ((gi==0)&&(as==ls))
            printf(" dop2");
         //Doper2_end
         //fitness evaluation
         #if((PGFREEZE==YA)||(PGFTEVAL==YA))
         eval=0;
         if((as==edp->frz[edp->gq].fs)||((as==us)&&(us<edp->frz[edp->gq].fs)))
         if(!((REPLAY==YA)&&(gi==0)&&(ff==1))) eval=1;
         //if(as==ASFITX) eval=1;
         #endif
         #if(EVFTEVAL==YA)
         eval=0;
         if(as==edp->stepeval) { eval=1; edp->fcoef=FITCOEFL; edp->fdecl=1.00; }
         if(as==edp->stepevly) { eval=1; edp->fdecl=FITDECLY; edp->fcoef=0.00; }
         if(as==edp->stepevlz) { eval=1; edp->fdecl=FITDECLZ; edp->fcoef=0.00; }
         #endif
         //Morphogenetic fitness evaluation
         #if((PGFREEZE==YA)||(PGFTEVAL==YA))
         if(eval==1)
          { edp->fshad=Fitbox(thid,gi,0,0,0,GRIDX-1,GRIDY-1,GRIDZ-1,&shas);
            edp->popa[pi]->guys[gy].shad=edp->fshad; }
         #endif
         #if(EVFTEVAL==YA)
         if(eval==1) {
            edp->fshad=Fitbox(thid,gi,0,0,0,GRIDX-1,GRIDY-1,GRIDZ-1,&shas);
            if(edp->popa[pi]->guys[gy].shad-edp->fshad<=edp->fdecl)
               edp->popa[pi]->guys[gy].shad+=edp->fcoef*edp->fshad; else
               edp->popa[pi]->guys[gy].shad=0; }
         #endif
         //Metabolic computation and metabolic fitness evaluation
         #if(MNETON==YA)
         #if((PGFREEZE==YA)||(PGFTEVAL==YA))
         if(eval==1)
          { edp->fmfit=Mnetcalc(thid,gi);
            edp->popa[pi]->guys[gy].mfit=edp->fmfit; }
         #endif
         #if(EVFTEVAL==YA)
         if(eval==1)
          { edp->fmfit=Mnetcalc(thid,gi);
            if(edp->popa[pi]->guys[gy].mfit-edp->fmfit<=edp->fdecl)
               edp->popa[pi]->guys[gy].mfit+=edp->fcoef*edp->fmfit; else
               edp->popa[pi]->guys[gy].mfit=0; }
         #endif
         #endif
         Gridupd(thid,gi,as,us,ff);
         // for guy 0, does some operations
         if (ff==0) if (eval==1) {
            for(ri=0;ri<DHARLS;ri++)
               memcpy(&edp->dvcdk0[ri],&edp->drvcdk[ri],sizeof(Coord));
         }
         // for guy 0, does some operations
         if (ff==0) if (as==us) {
            memcpy(&edp->dhar0,&edp->dhar,sizeof(Dse)*DHARLS);
            for(ce=0;ce<DHARLS;ce++) {
               for(hi=0;hi<CLKMAX;hi++) edp->dharaz[0][ce].moc[hi]=edp->dhar[ce].moc[hi];
               edp->dharaz[0][ce].lcrstp=edp->dhar[ce].lcrstp; }
            edp->dhnr0=edp->dhnr;
            for(ri=0;ri<DHARLS;ri++)
               memcpy(&edp->drvar0[ri],&edp->drvaro[ri],sizeof(Coord));
            edp->stepeval0=edp->stepeval;
            #if(CFLAG0==YA)
            FORVXYZ memcpy(&edp->clar0[vx][vy][vz],&edp->clar[vx][vy][vz],sizeof(Clsr));
            #endif
         }
      }
      #if(MOCDEV==YA)
      memcpy(&edp->dharal[gi][0],&edp->dhar[0],sizeof(Dse)*DHARLS);
      /*for(ce=0;ce<DHARLS;ce++)
         if((ce<=edp->dhnr)&&(edp->dhar[ce].asval<=edp->frz[edp->gq].fs))
            edp->dhnral[gi]=ce;*/
      edp->dhnral[gi]=edp->dhnr;
      #endif
      if (ff==0) gi--;
      if((ff==0)&&(edp->fset==1)) { edp->fdone=1; }
	   ff++;

      if (gi==gu-1)
      if ((edp->cn<edp->frz[edp->gq].ge)&&((edp->cn+1)>=edp->frz[edp->gq].ge))
         edp->fdone=0;
   }
   }

   #if(CFLAG0==YA)
   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      if(edp->ausdr==1) {
         sprintf(atmpstr,"\n\nstepeval0: %2d\n",edp->stepeval0); 
         Printf3(fp,atmpstr);
         for(ii=0;ii<CLKMAX;ii++) {
            sprintf(atmpstr," %2d",ii); 
            if(ii==24) atmpstr=strcat(atmpstr,"\n");
            Printf3(fp,atmpstr); }
         sprintf(atmpstr,"\n"); 
         Printf3(fp,atmpstr);
         aiv=0;
         for(ii=0;ii<CLKMAX;ii++) {
            sprintf(atmpstr," %2d",edp->evtnr0[ii]); 
            if(ii==24) atmpstr=strcat(atmpstr,"\n");
            Printf3(fp,atmpstr);
            aiv+=edp->evtnr0[ii];
         }
         sprintf(atmpstr," %2d\n",aiv);
         Printf3(fp,atmpstr);
         // statistics double mocs
         biv=0; civ=-1;
         for(ri=0;ri<edp->dhnr0;ri++) if (edp->dhar0[ri].moc[0]!=-1) {
            memcpy(&moctmp[0],&edp->dhar0[ri].moc[0],sizeof(int)*CLKMAX);
            aiv=0;
            for(si=0;si<edp->dhnr0;si++)
               if(memcmp(&moctmp[0],&edp->dhar0[si].moc[0],sizeof(int)*CLKMAX)==0) aiv++;
            cvar=cvar; // anchor
            if (aiv>biv) { biv=aiv; civ=ri; }
         }
         sprintf(atmpstr,"max nr of double moc: %2d %4d",biv,civ);
         Printf3(fp,atmpstr);
         // statistics double mocs_end
      }
   }
   // calc master_end -------------------------------------------------------
   #endif

   Sendrecv(3,buffer,&buflen1,&buflen3);

   // calc master -----------------------------------------------------------
   // restores order guys
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=NNGUYS-1;aa>=1;aa--) {
         bb=edp->rndpmt[aa];
         //printf(" aa=%d",aa); printf(" bb=%d",bb);
         gyp=&edp->popa[aa/POPXSZ]->guys[aa%POPXSZ];
         gzp=&edp->popa[bb/POPXSZ]->guys[bb%POPXSZ];
         memcpy(gtp,gyp,sizeof(Guy));
         memcpy(gyp,gzp,sizeof(Guy));
         memcpy(gzp,gtp,sizeof(Guy));
      }
   }
   // restores mocdev
   #if(MOCDEV==YA)
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=NNGUYS-1;aa>=1;aa--) {
         bb=edp->rndpmt[aa];
         memcpy(&edp->dharaltemp[0],&edp->dharal[aa][0],sizeof(Dse)*DHARLS);
         memcpy(&edp->dharal[aa][0],&edp->dharal[bb][0],sizeof(Dse)*DHARLS);
         memcpy(&edp->dharal[bb][0],&edp->dharaltemp[0],sizeof(Dse)*DHARLS);
         edp->dhnraltemp=edp->dhnral[aa];
         edp->dhnral[aa]=edp->dhnral[bb];
         edp->dhnral[bb]=edp->dhnraltemp;
      }
   }
   #endif
   #if(TAGCHK==YA)
   // TAGCHK restores frgenesc ----------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=NNGUYS-1;aa>=1;aa--) {
         bb=edp->rndpmt[aa];
         memcpy(&edp->frgentmp    [0],&edp->frgenesc[aa][0],sizeof(Dgx)*(DGEVXX*CLKMAX));
         memcpy(&edp->frgenesc[aa][0],&edp->frgenesc[bb][0],sizeof(Dgx)*(DGEVXX*CLKMAX));
         memcpy(&edp->frgenesc[bb][0],&edp->frgentmp    [0],sizeof(Dgx)*(DGEVXX*CLKMAX));
      }
   }
   // TAGCHK restores frgenesc_end ------------------------------------------
   #endif
   // calc master_end -------------------------------------------------------

   #if(MYMPI==1)
   thid=Getthid(&edp);
   if((thid!=0)&&((edp->cn)<CYCLES)) goto GSLAVE;
   #endif

   // calc master TAGCHK ----------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      for(gi=0;gi<NNGUYS;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         aiv=edp->popa[pi]->guys[gy].parents[0];
         biv=edp->popa[pi]->guys[gy].parents[1];
         // decodes stepeval
         bi=3; Cvbase2int(&edp->popa[pi]->guys[gy].gen[bi],
            &edp->stepeval,XTMRSQ,4,&bi);
      }
   }
   // calc master TAGCHK_end ------------------------------------------------

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      Calcfit(0);
      #if(DEBUG0==YA)
      Tagchck2(thid);
      Tagchck3(thid);
      #endif
      if(edp->ausdr==YA) {
         Showres(0,fp,atmpstr); Savememo(0); }
      if(edp->cn%GPSTEP==0) Germline(0); //Leavexec("testing Germliner");
      //if(ausdr==YA) { Showres (); Savememo (); }
      for(pi=0;pi<NPOPUL;pi++) 
         edp->popa[pi]->Galoop(0,0);
      t1=(long)time(0); gph=(double)((edp->cn-edp->cn0+1)*3600)/(t1-t0);
      sprintf(atmpstr,"gph: %.0f \n",gph);
      if(edp->ausdr==YA) Printf3(fp,atmpstr);
      fclose(fp);
   }
}

#if(MYMPI==1)
MPI_Finalize();
#endif

free(gtp);
free(atmpstr);
free(atmpstr1);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Initlocv (int thid) {
int  ii,hi,si;
Exbd *edp=exbd[thid];

// Inits et0
for(hi=0;hi<CLKMAX;hi++) edp->moc0[hi]=-1;

// Inits
edp->cd0.x=-1; edp->cd0.y=-1; edp->cd0.z=-1;

// Inits cgo0
edp->dgo0.ms0=-1; edp->dgo0.conr=-1;
for(ii=0;ii<2;ii++) {
   edp->dgo0.dpl[ii].x=-1;
   edp->dgo0.dpl[ii].y=-1;
   edp->dgo0.dpl[ii].z=-1;
}

// Inits dgx0
edp->dgx0.exord=-1;
edp->dgx0.swc  =-1;
edp->dgx0.timer=-1;
edp->dgx0.arpos=-1;
edp->dgx0.dvfrd=-1;
for(ii=0;ii<3;ii++) edp->dgx0.dhnrx[ii]=-1;
for(hi=0;hi<CLKMAX;hi++) edp->dgx0.res[hi]=-1;
memcpy(&edp->dgx0.dgo,&edp->dgo0,sizeof(Dgo));

// Inits guy0
edp->guy0.neugy=YA; edp->guy0.gaft=0; edp->guy0.shad=-1;
memset(&edp->guy0.gen,0,sizeof(int)*GENXSZ);

// Inits dpel0
edp->dpel0.d0=-1; edp->dpel0.e0=-1;

// Inits cs0
Lwriter(Lxxx,&edp->cs0,65535,0,CLNOCEL,0);
#if(MNETON==YA)
edp->cs0.mclnr=-1;
#endif

// Inits dse0
for(hi=0;hi<CLKMAX;hi++) edp->dse0.moc[hi]=-1;
for(ii=0;ii<50;ii++) edp->dse0.depend[ii]=-1; edp->dse0.ndep=0;
for(ii=0;ii<NMORPH;ii++) edp->dse0.infmoth[ii]=-1;
edp->dse0.lcrstp=-1; edp->dse0.actstp=-1; edp->dse0.sigstp=-1;
edp->dse0.dltcrt=0; edp->dse0.actdrv=0;

// Inits mcl0
for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++) edp->mcl0.iosmsk[ii][si]=0;
for(si=0;si<OXARSZ;si++) edp->mcl0.oxarap[si]=0;
edp->mcl0.olrxxx=-1; edp->mcl0.set=0;

// Inits aposel0
memcpy(&edp->aposel0.cd,&edp->cd0,sizeof(Coord));
for(si=0;si<NMORPH;si++) edp->aposel0.mphval[si]=+0;
for(si=0;si<NMORPH;si++) edp->aposel0.cntdrv[si]=-1;
edp->aposel0.dst=-1; edp->aposel0.close=-1;

// Inits sigel0
edp->sigel0.crtpnr=-1;
edp->sigel0.sigdlt=-1;
edp->sigel0.sigtyp=-1;
for(ii=0;ii<NMORPH;ii++) edp->sigel0.morphx[ii]=0;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Envinit(int thid,int opt) {
int  as,vx,vy,vz;
dimensa *aa,*bb,*cc; dimensc *dd;
Exbd *edp=exbd[thid];

if(opt==0) {
   if(ISGRID!=1) goto LAB000;
   aa = new dimensa[GRIDX]; edp->envr.etisooodp0grid=aa;
   bb = new dimensa[GRIDX]; edp->envr.cdisooodp0grid=bb;
   LAB000: cvar=cvar;
   cc = new dimensa[GRIDX]; edp->envr.cdtgooodplgrid=cc;
   dd = new dimensc[GRIDX]; edp->envr.oocurdsgrid=dd;
}

// Inits
if(opt==0) {
   FORVXYZ {
      if(ISGRID!=1) goto GTL003;
      edp->envr.etisooodp0grid[vx][vy][vz]=0;      // ACHTUNG
      edp->envr.cdisooodp0grid[vx][vy][vz]=0;      // ACHTUNG
      GTL003:cvar=cvar;
      edp->envr.cdtgooodplgrid[vx][vy][vz]=0;      // ACHTUNG
      memcpy(&edp->envr.oocurdsgrid[vx][vy][vz],&edp->dpel0,sizeof(Dpel));
   }
}

}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
void  Body::Bodinit(int ei) {
int   gi,pi,di,vx,vy,vz,cx,qr,ii,ki,si,hi,nx,ny,nz,rrdivrest,ri,ci,ce;
int   val,aa,bb,cc,ax,ay,sr;
float afv; FILE  *fp;
Exbd  *edp=exbd[ei];

// mnet,oxarsz
edp->oxarsz=OXARSZ;  // init

// grn
edp->sgarsz=DGARSZ;  // init

double gearx[NAMS]=AMSGEX,xfarx[NAMS]=AMSXFX,xearx[NAMS]=AMSXEX;
double dparx[NAMS]=AMSLSX,uparx[NAMS]=AMSUSX,dlarx[NAMS]=AMSDLX;
double fsarx[NAMS]=AMSFSX;
for(ii=0;ii<NAMS;ii++) {
   edp->frz[ii].ge =(int)(gearx[ii]*1000*AMSGECOE);
   edp->frz[ii].xf =(int) xfarx[ii];
   edp->frz[ii].xe =(int) xearx[ii];
   edp->frz[ii].ls =(int) dparx[ii];
   edp->frz[ii].us =(int) uparx[ii];
   edp->frz[ii].dl =(int) dlarx[ii];
   edp->frz[ii].fs =(int) fsarx[ii];
}

#if(DEBUG0==YA)
if(ei==0) {
   printf("\n");
   for(ii=0;ii<NAMS;ii++) {
      printf("%3d",edp->frz[ii].dl); if (ii==24) printf("\n");
   }
   printf("\n");
}
#endif

// xqar
for(di=0;di<DGARSZ;di++) {
   val=di;
   for(ii=-1;ii<NAMS-1;ii++) {
      if(ii==-1) { aa=0;               bb=edp->frz[0].xe;    }
      else       { aa=edp->frz[ii].xe; bb=edp->frz[ii+1].xe; }
      if(((aa<=val)&&(val<bb))) { edp->xqar[di]=ii+1; break; }
   }
}

// dgarsz,cn,cn0,clarf
edp->dgarsz=DGARSZ;
edp->cn=0; edp->cn0=0;
FORVXYZ memcpy(&edp->clarf[vx][vy][vz],&edp->cs0,sizeof(Clsr));

// fithst,zyg
int zygsss[12]=ZYGSSS;
for(ii=0;ii<FITHST;ii++) for(gi=0;gi<NNGUYS;gi++) {
   edp->shdhst[ii][gi]=0;
   edp->fithst[ii][gi]=0;
}

for(ii=0;ii<4;ii++) {
   edp->zygx[ii]=zygsss[3*ii+0];
   edp->zygy[ii]=zygsss[3*ii+1];
   edp->zygz[ii]=zygsss[3*ii+2];
}

// Exdp various
FORVXYZ memcpy(&edp->clar[vx][vy][vz],&edp->cs0,sizeof(Clsr));
//FORVXYZ Clsrinit(&edp->claro[vx][vy][vz],CLNOCEL);
for(cx=0;cx<DHARLS;cx++) memcpy(&edp->clard[cx],&edp->cs0,sizeof(Clsr));
for(qr=0;qr<8;qr++) for(cx=0;cx<DPVMAX;cx++)
   memcpy(&edp->clarq[qr][cx],&edp->cs0,sizeof(Clsr));
memcpy(&edp->moclp,&edp->cs0,sizeof(Clsr));
for(di=0;di<edp->dgarsz;di++) {
   memcpy(&edp->dgar  [di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->dgare [di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->dgaro [di],&edp->dgx0,sizeof(Dgx));
}

// Mnet ---------------------------------------------------------------------
for(ce=0;ce<DHARLS;ce++) memcpy(&edp->mtar[ce],&edp->mcl0,sizeof(Mcl));
// Mnet-end -----------------------------------------------------------------

// rrorder
//if (ei!=0) goto GTLKKK;
for(nx=0;nx<1;nx++) for(ny=0;ny<1;ny++) for(nz=0;nz<1;nz++) FORVXYZ {
//for(nx=0;nx<3;nx++) for(ny=0;ny<3;ny++) for(nz=0;nz<3;nz++) FORVXYZ {
   edp->rrorder[nx][ny][nz][vx+GRIDX*vy+(GRIDX*GRIDY)*vz].x=0;
   edp->rrorder[nx][ny][nz][vx+GRIDX*vy+(GRIDX*GRIDY)*vz].y=0;
   edp->rrorder[nx][ny][nz][vx+GRIDX*vy+(GRIDX*GRIDY)*vz].z=0;
}
for(nx=0;nx<1;nx++) for(ny=0;ny<1;ny++) for(nz=0;nz<1;nz++) { // ACHTUNG!!
//for(nx=0;nx<3;nx++) for(ny=0;ny<3;ny++) for(nz=0;nz<3;nz++) {
   #if(DEBUG0==YA)
   printf(" %4d %4d %4d",nx,ny,nz);
   #endif
   // reads rord (to speed-up)
   fp=fopen(XRORDFN,"r");
   if(fp!=NULL) {
      for(ii=0;ii<(GRIDX*GRIDY*GRIDZ);ii++)
         sr=fscanf(fp," %d %f %d %d %d\n",&cc,&afv,
            &edp->rrorder[nx][ny][nz][ii].x,
            &edp->rrorder[nx][ny][nz][ii].y,
            &edp->rrorder[nx][ny][nz][ii].z);
      fclose(fp);
      goto GTLHHH;
   }
   // reads rord (to speed-up)_end
   FORVXYZ edp->rrodist[nx][ny][nz][vx+GRIDX*vy+(GRIDX*GRIDY)*vz]
      =(float)Distance(nx,ny,nz,vx,vy,vz);
   for(ii=0;ii<(GRIDX*GRIDY*GRIDZ);ii++) edp->rrord[ii]=ii;
   Mysortxxxx(edp->rrodist[nx][ny][nz],(GRIDX*GRIDY*GRIDZ),1,edp->rrord);
   #if(DEBUG0==YA)
   printf("after sort\n");
   #endif
   for(ii=0;ii<(GRIDX*GRIDY*GRIDZ);ii++) {
      edp->rrorder[nx][ny][nz][ii].z=edp->rrord[ii]/(GRIDX*GRIDY);
      rrdivrest                      =edp->rrord[ii]%(GRIDX*GRIDY);
      edp->rrorder[nx][ny][nz][ii].y=rrdivrest/(GRIDX);
      edp->rrorder[nx][ny][nz][ii].x=rrdivrest%(GRIDX);
   }
   // writes rord (to speed-up)
   fp=fopen(XRORDFN,"w");
   if(fp!=NULL)
    { for(ii=0;ii<(GRIDX*GRIDY*GRIDZ);ii++)
         fprintf(fp," %6d %6f %6d %6d %6d\n",edp->rrord[ii],
            edp->rrodist[nx][ny][nz][edp->rrord[ii]],
            edp->rrorder[nx][ny][ny][ii].x,
            edp->rrorder[nx][ny][ny][ii].y,
            edp->rrorder[nx][ny][ny][ii].z);
      fclose(fp); }
   if((nx==0)&&(ny==0))fp=fopen(XDISTFN,"w");
   if(fp!=NULL) {
      for(ay=GRIDY-1;ay>=0;ay--) {
         for(ax=0;ax<GRIDX;ax++) {
            afv=(float)Distance(nx,ny,nz,ax,ay,0); fprintf(fp," %6f",afv); }
         fprintf(fp,"\n"); }
      fclose(fp);
   }
   // writes rord (to speed-up)_end
   GTLHHH:cvar=cvar;
}
//GTLKKK:cvar=cvar;
/*
memcpy(&exbd[ei]->rrorder[1][1][1][0],&exbd[0]->rrorder[1][1][1][0],
   sizeof(Coord)*GRIDX*GRIDY*GRIDZ);
memcpy(&exbd[ei]->rrodist[1][1][1][0],&exbd[0]->rrodist[1][1][1][0],
   sizeof(float)*GRIDX*GRIDY*GRIDZ);
memcpy(&exbd[ei]->rrord[0],&exbd[0]->rrord[0],
   sizeof( int )*GRIDX*GRIDY*GRIDZ);*/

#if(TAGCHK==YA)
// inits frgenes
for(gi=0;gi<NNGUYS;gi++) for(di=0;di<(DGEVXX*CLKMAX);di++) {
   memcpy(&edp->frgenesa[gi][di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->frgenesb[gi][di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->frgenesc[gi][di],&edp->dgx0,sizeof(Dgx));
}
// inits hstgenes
for(ii=0;ii<10000;ii++)
 { memcpy(&edp->hstgenes[ii].dgx,&edp->dgx0,sizeof(Dgx));
   edp->hstgenes[ii].actgen=-1; // -1 indicates array position is free
   edp->hstgenes[ii].copies=-1; }
edp->hgnr=0;

// inits taghst
for(ri=0;ri<6400;ri++) for(ci=0;ci<CLKMAX+2;ci++) edp->taghst[ri][ci]=0;
#endif

#if(CFLAG0==YA)
Setbitmask();
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Loadgrid(int thid,char *file,int opt,char *file2) {
int  vx,vy,vz,rx,ry,rz,val,ii,si,sr; FILE *fp;
Exbd *edp=exbd[thid];

if((fp=fopen(file,"r"))==NULL) Leavexec("File not found");
ii=0;
for(rz=0;rz<GRIDZ;rz++) for(ry=0;ry<GRIDY;ry++) for(rx=0;rx<GRIDX;rx++) {
   if((ii==0)||((ii+0)%GRIDX==0)) sr=fscanf(fp,"\n (vz:%d vy:%d vx:%d)",&vz,&vy,&vx);
   sr=fscanf(fp," %d",&val); ii++; vx=rx;
   if(opt==0) edp->envr.etisooodp0grid[vx][vy][vz]=val;
   if(opt==1) edp->envr.cdisooodp0grid[vx][vy][vz]=val;
   if(opt==2) edp->envr.cdtgooodplgrid[vx][vy][vz]=val;
}
fclose(fp);

#if(MNETON==YA)
if((fp=fopen(file2,"r"))==NULL) Leavexec("File not found");
// Loads target inputs
fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].x);
fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].y);
fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].z);
for(ii=0;ii<EXARSZ;ii++)
   for(si=0;si<SZSUSP;si++) fscanf(fp," %f",&edp->envr.mtv.iotar[0][ii][si]);
// Loads target outputs
fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].x);
fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].y);
fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].z);
for(ii=0;ii<EXARSZ;ii++)
   for(si=0;si<SZSUSP;si++) fscanf(fp," %f",&edp->envr.mtv.iotar[1][ii][si]);
fclose(fp);
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Sendrec0(int nr,char *buffer,long *buflen0) {
int  ei,vx,vy,vz,thid,si,aiv,biv,pi,gy,gi,gl,gu;
double bdv;
Exbd *edp;
Guy  *gyp,*gzp,*gtp;
#if(MYMPI==1)
int  rc;
MPI_Status stat;
#endif

// send-receive -------------------------------------------------------------
#if(MYMPI==0)
// cn0,envr
for(ei=1;ei<NCORES;ei++) {
   exbd[ei]->cn0=exbd[0]->cn0;
   FORVXYZ {
      exbd[ei]->envr.cdtgooodplgrid[vx][vy][vz]
      =exbd[0]->envr.cdtgooodplgrid[vx][vy][vz];
      if(ISGRID!=1) goto GTL000;
      exbd[ei]->envr.etisooodp0grid[vx][vy][vz]
      =exbd[0]->envr.etisooodp0grid[vx][vy][vz];
      exbd[ei]->envr.cdisooodp0grid[vx][vy][vz]
      =exbd[0]->envr.cdisooodp0grid[vx][vy][vz];
      GTL000: cvar=cvar;
      memcpy(&exbd[ei]->envr.mtv,&exbd[0]->envr.mtv,sizeof(Mtv));
   }
}
#endif
#if(MYMPI==1) // sendrec_0
thid=Getthid(&edp);
if (thid==0) {
   si=0;
   Mpscpy(&buffer[si],&edp->cn0,sizeof(int),&si);
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.cdtgooodplgrid[vx][vy][vz],sizeof(int),&si);
   if(ISGRID!=1) goto GTL001;
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.etisooodp0grid[vx][vy][vz],sizeof(int),&si);
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.cdisooodp0grid[vx][vy][vz],sizeof(int),&si);
   GTL001: cvar=cvar;
   Mpscpy(&buffer[si],&edp->envr.mtv,sizeof(Mtv),&si);
   for(ei=1;ei<NCORES;ei++) rc=MPI_Send(buffer,*buflen0,MPI_BYTE,ei,0,MPI_COMM_WORLD);
}
else /*FORVXYZ*/ {
   rc=MPI_Recv(buffer,*buflen0,MPI_BYTE, 0,0,MPI_COMM_WORLD,&stat);
   si=0;
   Mprcpy(&edp->cn0,&buffer[si],sizeof(int),&si);
   FORVXYZ Mprcpy(&edp->envr.cdtgooodplgrid[vx][vy][vz],&buffer[si],sizeof(int),&si);
   if(ISGRID!=1) goto GTL002;
   FORVXYZ Mprcpy(&edp->envr.etisooodp0grid[vx][vy][vz],&buffer[si],sizeof(int),&si);
   FORVXYZ Mprcpy(&edp->envr.cdisooodp0grid[vx][vy][vz],&buffer[si],sizeof(int),&si);
   GTL002: cvar=cvar;
   Mprcpy(&edp->envr.mtv,&buffer[si],sizeof(Mtv),&si);
}
#endif
// send-receive_end ---------------------------------------------------------

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Sendrecv(int nr,char *buffer,long *buflen1,long *buflen3) {
int  ei,vx,vy,vz,thid,si,aiv,biv,pi,gy,gi,gl,gu;
double bdv;
Exbd *edp;
Guy  *gyp,*gzp,*gtp;
#if(MYMPI==1)
int  rc; MPI_Status stat;
#endif

if(nr!=1) goto GTLEBB;
thid=Getthid(&edp);
//aiv=0;
aiv=edp->popa[0]->dnaxf;
biv=edp->popa[0]->dnasz;
*buflen1 =sizeof(int)*6;
*buflen1+=sizeof(Guy);
*buflen1+=sizeof(int)*NNGUYS;
*buflen1+=sizeof(int)*(NNGUYS/NCORES+1)*(biv-aiv);
*buflen1+=sizeof(int)*(NNGUYS/NCORES+1)*BEGNSQ;
if (edp->ausdr==1) printf(" buflen1=%ld",*buflen1);
#if(MYMPI==0)
for(ei=1;ei<NCORES;ei++) {
   exbd[ei]->cn=exbd[0]->cn;
   exbd[ei]->gq=exbd[0]->gq;
   exbd[ei]->dgarxf=exbd[0]->dgarxf;
   exbd[ei]->dgarsz=exbd[0]->dgarsz;
   memcpy(&exbd[ei]->guyf,&exbd[0]->guyf,sizeof(Guy));
   memcpy(&exbd[ei]->rndpmt[0],&exbd[0]->rndpmt[0],sizeof(int)*NNGUYS);
   for(pi=0;pi<NPOPUL;pi++) for(gy=0;gy<POPXSZ;gy++) {
      gyp=&exbd[ei]->popa[pi]->guys[gy];
      gzp=&exbd[ 0]->popa[pi]->guys[gy];
      memcpy(&gyp->gen[aiv],&gzp->gen[aiv],sizeof(int)*(biv-aiv));
      memcpy(&gyp->gen[  0],&gzp->gen[  0],sizeof(int)*BEGNSQ);
   }
}
#endif
#if(MYMPI==1)
if (thid==0) {
   for(ei=1;ei<NCORES;ei++) {
      bdv=NNGUYS/(double)NCORES;
      gl=(int)(bdv*ei); gu=(int)(bdv*(ei+1));
      if (ei==NCORES-1) gu=NNGUYS;
      si=0;
      Mpscpy(&buffer[si],&edp->cn,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->gq,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->dgarxf,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->dgarsz,sizeof(int),&si);
      Mpscpy(&buffer[si],&gl,sizeof(int),&si); //boundaries
      Mpscpy(&buffer[si],&gu,sizeof(int),&si); //boundaries
      Mpscpy(&buffer[si],&edp->guyf,sizeof(Guy),&si);
      Mpscpy(&buffer[si],&edp->rndpmt[0],sizeof(sizeof(int)*NNGUYS),&si);
      for(gi=gl;gi<gu;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         gyp=&edp->popa[pi]->guys[gy];
         Mpscpy(&buffer[si],&gyp->gen[aiv],sizeof(int)*(biv-aiv),&si);
         Mpscpy(&buffer[si],&gyp->gen[  0],sizeof(int)*BEGNSQ,&si);
      }
      rc=MPI_Send(buffer,*buflen1,MPI_BYTE,ei,1,MPI_COMM_WORLD);
   }
}
else {
   if (0==0) { // to keep aligned
      si=0;
      rc=MPI_Recv(buffer,*buflen1,MPI_BYTE,0,1,MPI_COMM_WORLD,&stat);
      Mprcpy(&edp->cn,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->gq,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->dgarxf,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->dgarsz,&buffer[si],sizeof(int),&si);
      Mprcpy(&gl,&buffer[si],sizeof(int),&si); //boundaries
      Mprcpy(&gu,&buffer[si],sizeof(int),&si); //boundaries
      Mprcpy(&edp->guyf,&buffer[si],sizeof(Guy),&si);
      Mprcpy(&edp->rndpmt[0],&buffer[si],sizeof(sizeof(int)*NNGUYS),&si);
      for(gi=gl;gi<gu;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         gyp=&edp->popa[pi]->guys[gy];
         Mprcpy(&gyp->gen[aiv],&buffer[si],sizeof(int)*(biv-aiv),&si);
         Mprcpy(&gyp->gen[  0],&buffer[si],sizeof(int)*BEGNSQ,&si);
      }
   }
}
#endif
GTLEBB:cvar=cvar;

if(nr!=3) goto GTLEDD;
thid=Getthid(&edp);
bdv=NNGUYS/(double)NCORES;
#if(MYMPI==0)
// consolidates pop
for(ei=1;ei<NCORES;ei++) {
   gl=(int)(bdv*ei); gu=(int)(bdv*(ei+1));
   if (ei==NCORES-1) gu=NNGUYS;
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      exbd[ 0]->popa[pi]->guys[gy].shad=
      exbd[ei]->popa[pi]->guys[gy].shad;
      exbd[ 0]->popa[pi]->guys[gy].mfit=
      exbd[ei]->popa[pi]->guys[gy].mfit;
      #if(MOCDEV==YA)
      memcpy(&exbd[0]->dharal[gi][0],&exbd[ei]->dharal[gi][0],sizeof(Dse)*DHARLS);
      exbd[0]->dhnral[gi]=exbd[ei]->dhnral[gi];
      #endif
      #if(TAGCHK==YA)
      memcpy(&exbd[ 0]->frgenesc[gi][0],&exbd[ei]->frgenesc[gi][0],sizeof(Dgx)*(DGEVXX*CLKMAX));
      #endif
   }
}
#endif
#if(MYMPI==1) // sendrec_3
gl=(int)(bdv*thid); gu=(int)(bdv*(thid+1));
if (thid==NCORES-1) gu=NNGUYS;
//aiv=(sizeof(int)*(gu-gl)*DHARLS*CLKMAX);
//biv=(sizeof(int)*(gu-gl));
if (thid!=0) {
   si=0;
   Mpscpy(&buffer[si],&gl,sizeof(int),&si); // boundaries
   Mpscpy(&buffer[si],&gu,sizeof(int),&si); // boundaries
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      gyp=&edp->popa[pi]->guys[gy];
      Mpscpy(&buffer[si],&gyp->shad,sizeof(float),&si);
      Mpscpy(&buffer[si],&gyp->mfit,sizeof(float),&si);
      #if(MOCDEV==YA)
      Mpscpy(&buffer[si],&edp->dharal[gi][0],sizeof(Dse)*DHARLS,&si);
      Mpscpy(&buffer[si],&edp->dhnral[gi],sizeof(int),&si);
      #endif
      #if(TAGCHK==YA)
      // frgenes
      Mpscpy(&buffer[si],&edp->frgenesc[gi][0],sizeof(Dgx)*(DGEVXX*CLKMAX),&si);
      #endif
   }
   rc=MPI_Send(buffer,*buflen3,MPI_BYTE,0,3,MPI_COMM_WORLD);
}
else for(ei=1;ei<NCORES;ei++) { // ACHTUNG: deve ricevere da qlq processo!
   si=0;
   rc=MPI_Recv(buffer,*buflen3,MPI_BYTE,MPI_ANY_SOURCE,3,MPI_COMM_WORLD,&stat);
   Mprcpy(&gl,&buffer[si],sizeof(int),&si); // boundaries
   Mprcpy(&gu,&buffer[si],sizeof(int),&si); // boundaries
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      gyp=&edp->popa[pi]->guys[gy];
      Mprcpy(&gyp->shad,&buffer[si],sizeof(float),&si);
      Mprcpy(&gyp->mfit,&buffer[si],sizeof(float),&si);
      #if(MOCDEV==YA)
      Mprcpy(&edp->dharal[gi][0],&buffer[si],sizeof(Dse)*DHARLS,&si);
      Mprcpy(&edp->dhnral[gi],&buffer[si],sizeof(int),&si);
      #endif
      #if(TAGCHK==YA)
      // frgenes
      Mprcpy(&edp->frgenesc[gi][0],&buffer[si],sizeof(Dgx)*(DGEVXX*CLKMAX),&si);
      #endif
   }
   cvar=cvar;
}
#endif
GTLEDD:cvar=cvar;
}
