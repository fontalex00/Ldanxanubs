
#include "danxincl.h"

// Global var
extern Exbd *exbd[NCORES]; extern char cvar;

//!--------------------------------------------------------------------------
//! fctheader. Hint: a cell can have the same distance from more than one driver
//! Therefore the assignment of ntuples may not be unique.
//!--------------------------------------------------------------------------
void  Body::Dopernew(int thid,int gi,int as,int is,int op) {
int   vx,vy,vz,sx,sy,sz,ki,ii,ri,si,fi,ni,fs,fx,aiv,biv,civ,div,eiv,oiv,ok;
int   dhn,apnr,surfc,surfd,smoceql,drclose,*ptr,femis[NMORPH];
int   smocnu,*apv,*bpv,*cpv,*dpv,sigmin,sigmax,nsc,doprat;
double dista,dopdst,dstmin,cdv;
Coord vcd,acd,dcd,cd,*crd; void *avv;
Ntpel *ntp;
FILE  *fptr00,*fp1,*fp2;
Exbd *edp=exbd[thid];

if(op==2) { dopdst=DOPDSTB; doprat=DOPRATB; }
if(op==3) { dopdst=DOPDSTS; doprat=DOPRATS; }

#if(DEBUG7==YA)
// converts driver into normal
if(op==3) if(as==2) if(is==3) {
   Lwriter(Lxxx,&edp->clar[4][61][16],-1,+0,-1,-1);
   edp->pmocs[64]=-1;
}
#endif

#if(CFLAG0==YA)
if(as-0>=0) if(edp->evtnr[as-0]==0) if(edp->evtnr[as-0]==0) if(edp->evtnr[as-1]==0)
   goto LABEOF;
//if(gi!=0) goto LABEOF;
//if(edp->ausdr==0) goto LABEOF;
#endif

#if(DEBUG0==YA)
if(edp->cn>=0) if(as== 2) if(op==3) if(gi==0)
   cvar=cvar;
#endif

// compiles clarcnd (only cells sleep and active)
FORVXYZ {
   edp->clarcnd[vx][vy][vz]=0;
   aiv=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
   if((aiv==CLALIVE)||(aiv==CLALIVN)) edp->clarcnd[vx][vy][vz]=1;
}

#if(CFLAG0==YA)
// compiles aposar
for(ii=0;ii<APOSARSZ;ii++) memcpy(&edp->aposar[ii],&edp->aposel0,sizeof(Aposel));
apnr=0;
FORVXYZ {
   vcd.x=vx; vcd.y=vy; vcd.z=vz;
   aiv=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
   if((aiv==CLALIVE)||(aiv==CLALIVN)) { //if((op==2)||((op==3)&&(surfc==YA))) {
      surfc=Surfint(as,&vcd,edp);
      dstmin=8888;
      for(ri=0;ri<DHARLS;ri++) if(edp->drvaro[ri].x!=-1) {
         surfd=Surfint(as,&edp->drvaro[ri],edp);
         if((op==2)||((op==3)&&(surfd==YA))) {
            dista=Dopdst(&edp->drvaro[ri],&vcd);
            if(dstmin>dista) dstmin=dista;
         }
      }
      memcpy(&edp->aposar[apnr].cd,&vcd,sizeof(Coord));
      edp->aposar[apnr].surfc=surfc;
      if(dstmin>dopdst) edp->aposar[apnr].close=0; // not too close
      else              edp->aposar[apnr].close=1; // too close
      edp->aposar[apnr].mother=edp->clar[vx][vy][vz].mother;
      apnr++;
   }
}

// sigcells array
nsc=0;
for(ni=0;ni<1000;ni++) memcpy(&edp->sigcells[ni],&edp->sigel0,sizeof(Sigel));
for(ri=0;ri<DHARLS;ri++) if(edp->drvaro[ri].x!=-1) {
   if(edp->dhar[ri].sigstp!=-1) {
      edp->sigcells[nsc].crtpnr=ri;
      edp->sigcells[nsc].sigdlt=edp->dhar[ri].sigstp-edp->dhar[ri].dltcrt;
      memcpy(&edp->sigcells[nsc].cd,&edp->drvaro[ri],sizeof(Coord));
      nsc++;
   }
}
Fsortsigca(thid,nsc,&edp->sigcells[0]);

fp1=fopen(XDBG1FN,"a");
// computes concentration of morphs
for(si=0;si<NMORPH;si++) femis[si]=0;
for(ni=0;ni<nsc;ni++) {
   ri=edp->sigcells[ni].crtpnr;
   for(ii=0;ii<apnr;ii++) {
      if(memcmp(&edp->drvaro[ri],&edp->aposar[ii].cd,sizeof(Coord))==0) {
         sigmin=8888; aiv=-1;
         for(si=0;si<NMORPH;si++) if(femis[si]==0) { aiv=si; break; }
         if(aiv==-1)
         for(si=0;si<NMORPH;si++)
            if(sigmin>edp->aposar[ii].mphval[si]) {
               sigmin=edp->aposar[ii].mphval[si]; aiv=si; }
         femis[aiv]=1;
         edp->sigcells[ni].sigtyp=aiv;
         break;
      }
   }
   for(ii=0;ii<apnr;ii++) {
      memcpy(&acd,&edp->aposar[ii].cd,sizeof(Coord));
      memcpy(&dcd,&edp->drvaro[ri]   ,sizeof(Coord));
      dista=Dopdxt(&dcd,&acd,aiv);
      biv=9-(int)(dista/FLDGAP);
      if((dista>SRCDST)||(biv<1)) biv=1; // min val = 1
      eiv=1;
      #if(CFLAG0==YA)
      oiv=Lreader(Ldhn,&edp->clar[acd.x][acd.y][acd.z]);
      civ=edp->clar[acd.x][acd.y][acd.z].mother;
      div=edp->clar[dcd.x][dcd.y][dcd.z].mother;
      // condition a: past influence future and not viceversa
      if(edp->dhar[oiv].lcrstp-edp->dhar[oiv].dltcrt <
         edp->dhar[ ri].sigstp-edp->dhar[ ri].dltcrt)
         eiv=0;
      // condition b: local drivers influence only their sisters
      if(edp->dhar[ri].actstp==-1) // local drivers
      if(civ!=div)
         eiv=0;
      #endif
      if(eiv==1)
      if(edp->aposar[ii].mphval[aiv]<biv) {
         edp->aposar[ii].mphval[aiv]=biv;
         edp->aposar[ii].cntdrv[aiv]= ri;
         #if(DEBUG0==YA)
         ok=NO;
         if(op==3) if (as== 7) if(acd.x==70) if(acd.y==31) if(acd.z==69) ok=YA;
         if(op==3) if (as==15) if(acd.x==70) if(acd.y==31) if(acd.z==69) ok=YA;
         if(ok==YA) {
            fprintf(fp1," as=%4d aiv=%4d biv=%4d ri=%4d sigstp=%4d dltcrt=%4d",
               as,aiv,biv,ri,edp->dhar[ri].sigstp,edp->dhar[ri].dltcrt);
            fprintf(fp1," [%4d] [%4d] %4d %4d %4d %4d %4d %4d %4d %4d\n",
               edp->dhar[ri].moc[1],edp->dhar[ri].moc[2],
               edp->aposar[ii].mphval[0],edp->aposar[ii].mphval[1],
               edp->aposar[ii].mphval[2],edp->aposar[ii].mphval[3],
               edp->aposar[ii].cntdrv[0],edp->aposar[ii].cntdrv[1],
               edp->aposar[ii].cntdrv[2],edp->aposar[ii].cntdrv[3]);
         }
			#endif
      }
   }
}
#endif
fclose(fp1);

// inits hasht
for(fi=0;fi<NTPDIRSZ;fi++) {
   ntp=&edp->ntpdir[fi];
   ntp->ptr=0;
   for(ii=0;ii<NMORPH;ii++) { ntp->mphval[ii]=-1; ntp->cntdrv[ii]=-1; }
   ntp->cds=(Coord *)malloc(100*sizeof(Coord)); ntp->sza=100;
   for(ii=0;ii<100;ii++) memcpy(&ntp->cds[ii],&edp->cd0,sizeof(Coord));
}
fs=0;

for(ii=0;ii<apnr;ii++) {
   vx=edp->aposar[ii].cd.x;
   vy=edp->aposar[ii].cd.y;
   vz=edp->aposar[ii].cd.z;
   apv=&edp->aposar[ii].mphval[0]; bpv=&edp->aposar[ii].cntdrv[0];
   surfc=edp->aposar[ii].surfc;
   ok=YA; for(si=0;si<NMORPH;si++) if(bpv[si]==-1) ok=NO;
   civ=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
   div=0; if((civ==CLALIVE)||(civ==CLALIVN)) div=1;
   #if(DOPALN==YA)
   div=0; if (civ==CLALIVN) div=1;
   #endif
   if(ok==YA) if(div==1)
   if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==0)
   if((op==2)||((op==3)&&(surfc==YA))) {
   //if(edp->aposar[ii].close==0) {
      fx=fs;
      for(fi=0;fi<fs;fi++) {
         aiv=memcmp(&edp->ntpdir[fi].mphval[0],apv,sizeof(int)*NMORPH);
         biv=memcmp(&edp->ntpdir[fi].cntdrv[0],bpv,sizeof(int)*NMORPH);
         if((aiv==0)&&(biv==0)) if(edp->ntpdir[fi].mother==edp->aposar[ii].mother)
          { fx=fi; break; }
      }
      if(fx==fs) { // new ntp
         avv=memcpy(&edp->ntpdir[fs].mphval[0],apv,sizeof(int)*NMORPH);
         avv=memcpy(&edp->ntpdir[fs].cntdrv[0],bpv,sizeof(int)*NMORPH);
         edp->ntpdir[fi].mother=edp->aposar[ii].mother;
         fs++;
      }
      ntp=&edp->ntpdir[fx];
      ntp->onr=fx;
      vcd.x=vx; vcd.y=vy; vcd.z=vz; ptr=&ntp->ptr;
      memcpy(&ntp->cds[ntp->ptr++],&vcd,sizeof(Coord));
      // realloc
      if(ntp->sza-ntp->ptr==1) {
         ntp->cds=(Coord *)realloc(ntp->cds,(ntp->sza+100)*sizeof(Coord));
         ntp->sza+=100;
      }
   }
}

// sorts
for(fi=0;fi<fs;fi++)
 { sigmax=0;
   for(ii=0;ii<NMORPH;ii++)
      if(sigmax<edp->ntpdir[fi].mphval[ii])
         sigmax=edp->ntpdir[fi].mphval[ii];
   edp->ntpdir[fi].dst=sigmax; }
Fsortntpdr(thid,fs,&edp->ntpdir[0]);

#if(CFLAG7==YA)
if(as==2) if(op==2) {
   aiv=0;
   FORVXYZ edp->clar[vx][vy][vz].col=0;
   for(fi=0;fi<fs-0;fi++) {
      for(ii=0;ii<edp->ntpdir[fi].ptr;ii++) {
         aiv++; crd=&edp->ntpdir[fi].cds[ii];
         vx=crd->x; vy=crd->y; vz=crd->z;
         cdv=(double)fi/fs;
         biv=1+cdv*12;
         edp->clar[vx][vy][vz].col=biv;
     }
   }
   printf(" aiv=%d",aiv);
}
#endif

#if(CFLAG7==YA)
if(as==2) if(op==2) {
   FORVXYZ edp->clar[vx][vy][vz].col=0;
   for(ii=0;ii<apnr;ii++) {
      vx=edp->aposar[ii].cd.x;
      vy=edp->aposar[ii].cd.y;
      vz=edp->aposar[ii].cd.z;
      edp->clar[vx][vy][vz].col=edp->aposar[ii].mphval[0];
   }
}
#endif

for(fi=0;fi<fs;fi++) {
   ntp=&edp->ntpdir[fi];
   #if(DEBUG0==YA)
   if((as==7)||(as==15))
   if(ntp->mphval[0]==4) if(ntp->mphval[1]==5) if(ntp->mphval[2]==7) if(ntp->mphval[3]==3)
      cvar=cvar;
   #endif
   #if(CFLAG0==YA)
   memcpy(&vcd,&ntp->cds[ntp->ptr-1],sizeof(Coord)); // max distance
   Avgcd(&ntp->cds[0],ntp->ptr,&vcd); // average position in field
   vx=vcd.x; vy=vcd.y; vz=vcd.z; // copy for clar
   #endif
   #if(DEBUG0==YA)
   aiv=Surfint(as,&vcd,edp);
   ok=NO;
   if(as== 7) if(vx==102) if(vy==31) if(vz==59) ok=YA;
   if(as==15) if(vx==102) if(vy==31) if(vz==59) ok=YA;
   if(ok==YA) {
      fp2=fopen(XDBG2FN,"a");
      for(ii=0;ii<ntp->ptr;ii++)
         fprintf(fp2,"vx=%4d vy=%4d vz=%4d %4d) %4d %4d %4d %4d %4d %4d\n",
            vx,vy,vz,ii,as,ntp->ptr,ntp->mother,
            ntp->cds[ii].x,ntp->cds[ii].y,ntp->cds[ii].z);
      fclose(fp2);
      cvar=cvar;
   }
   #endif
   oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
   edp->dltcrt=edp->dhar[oiv].dltcrt;
   for(ii=0;ii<NMORPH;ii++) edp->infmoth[ii]=ntp->cntdrv[ii];
   edp->nfdmoth=edp->clar[vx][vy][vz].mother;
   smocnu=0;
   for(ii=0;ii<NMORPH;ii++) smocnu+=ntp->mphval[ii]*Intpower(10,NMORPH-1-ii);
   oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
   edp->dltcrt=edp->dhar[oiv].dltcrt;
   smoceql=NO; drclose=NO;
   for(si=0;si<edp->ps;si++) if (edp->pmocs[si].mother==edp->clar[vx][vy][vz].mother) {
      #if(NEQUAL==YA)
      if (edp->pmocs[si].smocnu==smocnu) smoceql=YA;
      #endif
      //if((op==2)||((op==3)&&(Surfint(as,&edp->pmocs[si].cd,edp)==YA)))
      //if(Dopdst(&edp->pmocs[si].cd,&vcd)<=dopdst) drclose=YA;
   }
   if(ntp->ptr>=doprat)
   if(smoceql==NO) if(drclose==NO) {
      #if(DOPALN==YA)
      civ=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
      if(civ!=CLALIVN) goto GTLCCC;
      #endif
      oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
      edp->dltcrt=edp->dhar[oiv].dltcrt;
      memcpy(&edp->mocnew[0],&edp->dhar[oiv].moc[0],sizeof(int)*CLKMAX);
      edp->smocnew=smocnu;
      edp->moclp.dhnrc3=65535;
      edp->isval=is;
      Dharupd (thid,gi,as,-1,YA,CLALIVN,op,&vcd);
      Daughter(thid,gi,as,-1,YA,CLALIVN,-1,&vcd);
      Dthrmnet(thid,gi,as,-1,YA,CLALIVN,-1,&vcd);
      edp->ss++;
      edp->pmocs[edp->ps].cd.x=vx;
      edp->pmocs[edp->ps].cd.y=vy;
      edp->pmocs[edp->ps].cd.z=vz;
      edp->pmocs[edp->ps].smocnu=smocnu;
      edp->pmocs[edp->ps].mother=edp->clar[vx][vy][vz].mother;
      edp->ps++;
      GTLCCC:cvar=cvar;
   }
}

#if(DEBUG0==YA)
fptr00=fopen(CONSFN, "a");
if(edp->ausdr==1) {
   fprintf(stdout,"\n[%2d %2d %d %4d %4d]",as,is,op,fs,edp->ss-edp->sstmp);
   fprintf(fptr00,"\n[%2d %2d %d %4d %4d]",as,is,op,fs,edp->ss-edp->sstmp); }
fclose(fptr00);
#endif

for(fi=0;fi<NTPDIRSZ;fi++) free(edp->ntpdir[fi].cds); edp->ntpdir[fi].sza=0;

LABEOF:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Doper2(int thid,int gi,int as) {
int  ex,ey,ez,ri,ii,rx,ry,rz,cnd;
int  vx,vy,vz,mx,my,mz,dfound,nhx,nhy,nhz,oiv;
Coord cd,vcd,mcd;
Exbd *edp=exbd[thid];

// compiles clarcnd (only cells active and sleep)
FORVXYZ {
   edp->clarcnd[vx][vy][vz]=0;
   cnd=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
   if((cnd==CLALIVN)||(cnd==CLALIVE)) edp->clarcnd[vx][vy][vz]=1;
}

// here considers only the first driver ([0])
ri=0; for(ii=0;ii<DHARLS;ii++) if(edp->drvaro[ii].x>=0) {
   ex=edp->drvaro[ii].x;
   ey=edp->drvaro[ii].y;
   ez=edp->drvaro[ii].z;
   memcpy(&edp->clardcd[ri],&edp->drvaro[ii],sizeof(Coord));
   edp->clard[ri++]=edp->clar[ex][ey][ez]; }
if(ri==0) goto GTLEOF;

// Plan B
// if clar[vx][vy][vz] is superficial and non-driver and in the vicinity
// no cell is superficial and driver ... then clar[vx][vy][vz] becomes driver
rx=-888; ry=-888; rz=-888;
edp->smocnew=SMOCMA;
nhx=DOP2NS; nhy=DOP2NS; if(NDIMS==2) nhz=0; if(NDIMS==3) nhz=DOP2NS;
for(vz=nhz;vz<GRIDZ-nhz;vz++) {
   for(vx=nhx;vx<GRIDX-nhx;vx++) for(vy=nhy;vy<GRIDY-nhy;vy++) {
      vcd.x=vx; vcd.y=vy; vcd.z=vz;
      // if "in interior grid", non-void, borderline, NON-driver
      // if(edp->clar[vx][vy][vz].dhnrc3==65535) goto GTPXX0;
      if(edp->clarcnd[vx][vy][vz]==1)
      if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==0)
      if(Surfint(as,&vcd,edp)==YA) {
         // search neighbourhood, start ----------------
         dfound=NO;
         if(abs(rx-vx)<=nhx)
         if(abs(ry-vy)<=nhy)
         if(abs(rz-vz)<=nhz) dfound=YA;
         if(dfound==NO) {
            for(mz=vz-nhz;mz<=vz+nhz;mz++) {
               for(mx=vx-nhx;mx<=vx+nhx;mx++) for(my=vy-nhy;my<=vy+nhy;my++) {
                  mcd.x=vx; mcd.y=vy; mcd.z=vz;
                  // if "in interior grid",non-void,borderline,driver
                  // if(edp->clar[mx][my][mz].dhnrc3!=65535) {
                  if(edp->clarcnd[mx][my][mz]==1)
                  if(Lreader(Ldrv,&edp->clar[mx][my][mz])==1)
                  if(Surfint(as,&mcd,edp)==YA) {
                     dfound=YA;
                     rx=mx; ry=my; rz=mz;
                     goto GTLAAA;
                  }
               }
            }
         }
         GTLAAA:cvar=cvar;

         if(dfound==NO) {
            Closedr(thid,gi,vx,vy,vz,ri,&edp->mocnew[0]);
            edp->smocnew++;
            cd.x=vx; cd.y=vy; cd.z=vz;
            oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
            edp->dltcrt=edp->dhar[oiv].dltcrt;
            edp->moclp.dhnrc3=65535;
            Dharupd (thid,gi,as,-1,YA,CLALIVN, 2,&cd);
            Daughter(thid,gi,as,-1,YA,CLALIVN,-1,&cd);
            Dthrmnet(thid,gi,as,-1,YA,CLALIVN,-1,&cd);
         }
         // search neighbourhood, end ------------------
      }
   }
}

GTLEOF:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Closedr(int thid,int gi,int ex,int ey,int ez,int ri,int *moc) {
int  rj,rd,md,mda;
Exbd *edp=exbd[thid];

md=(GRIDX+GRIDY+GRIDZ); rd=-1;
for(rj=0;rj<ri;rj++) {
   mda=abs(edp->clardcd[rj].x-ex)
      +abs(edp->clardcd[rj].y-ey)
      +abs(edp->clardcd[rj].z-ez);
   if(md>mda) { md=mda; rd=rj; }}
Moccopy(&moc[0],&edp->dhar[Lreader(Ldhn,&edp->clard[rd])].moc[0]);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void   Body::Remred(int thid,int gi,int as,int di,int vx,int vy,int vz,int ss) {
int    qr,qrmax,ux,uy,uz,ax,ay,az,sx,sy,sz,nx,ny,nz,drv,cnd,dhn;
double distmax,dista,hex,hey,hez,tr[9],rx,ry,rz,ix0,ix1,iy0,iy1,iz0,iz1;
int    kx,ky,kz,dx,dy,dz,ix,iy,iz,sane,iout,done,clmove;
Exbd   *edp=exbd[thid];

ux=0; uy=0; uz=0; // to avoid warnings

if(NDIMS==2) qrmax=4;
if(NDIMS==3) qrmax=8;

#if(DEBUG7==YA)
if (edp->cn==22) printf(" start %d %d",gi,ss);
#endif

if(REMRED==NO) goto GTLEOF; //$

#if(DEBUG0==YA)
if (gi==0) if (as==2)
   cvar=cvar;
#endif

// ellissoid: semi-axes, centre and displacement
hex=(double)abs((edp->actdgr.dpl[7].x-edp->actdgr.dpl[0].x))/2;
hey=(double)abs((edp->actdgr.dpl[7].y-edp->actdgr.dpl[0].y))/2;
hez=(double)abs((edp->actdgr.dpl[7].z-edp->actdgr.dpl[0].z))/2;
kx=2*DPLMAX/2; dx=(int)hex+edp->actdgr.dpl[0].x;
ky=2*DPLMAX/2; dy=(int)hey+edp->actdgr.dpl[7].y;
kz=2*DPLMAX/2; dz=(int)hez+edp->actdgr.dpl[0].z;
memcpy(&tr[0],&edp->actdgr.tr[0],sizeof(double)*9);

for(qr=0;qr<qrmax;qr++) {
   if(qr==0) { ux=-1; uy=+1; uz=-1; } // NWB
   if(qr==1) { ux=+1; uy=+1; uz=-1; } // NEB
   if(qr==2) { ux=-1; uy=-1; uz=-1; } // SWB
   if(qr==3) { ux=+1; uy=-1; uz=-1; } // SEB
   if(qr==4) { ux=-1; uy=+1; uz=+1; } // NWF
   if(qr==5) { ux=+1; uy=+1; uz=+1; } // NEF
   if(qr==6) { ux=-1; uy=-1; uz=+1; } // SWF
   if(qr==7) { ux=+1; uy=-1; uz=+1; } // SEF
   nx=-1; ny=-1; nz=-1;
   distmax=Distance(nx,ny,nz,
      abs(edp->actdgr.dpl[qr].x),
      abs(edp->actdgr.dpl[qr].y),
      abs(edp->actdgr.dpl[qr].z));

   nx=0; ny=0; nz=0;
   // Remove
   done=NO;
   if (ss==0) { edp->bci[qr]=0; edp->uui[qr]=1; } // bufferised cells index
   if (ss==1) { edp->rci[qr]=0; edp->uui[qr]=1; } // redeployed cells index
   do {
      ax=edp->rrorder[nx][ny][nz][edp->uui[qr]].x; sx=vx+ax*ux;
      ay=edp->rrorder[nx][ny][nz][edp->uui[qr]].y; sy=vy+ay*uy;
      az=edp->rrorder[nx][ny][nz][edp->uui[qr]].z; sz=vz+az*uz;
      // with trans
      rx=(tr[0]*(ax*ux)+tr[1]*(ay*uy)+tr[2]*(az*uz));
      ry=(tr[3]*(ax*ux)+tr[4]*(ay*uy)+tr[5]*(az*uz));
      rz=(tr[6]*(ax*ux)+tr[7]*(ay*uy)+tr[8]*(az*uz));
      //ix=0; iy=0; iz=0;
      iout=0;
      for(ix=0;ix<2;ix++) for(iy=0;iy<2;iy++) for(iz=0;iz<2;iz++) {
         // to make nore robust: if difference is too big, takes the other boundary
         ix0=floor(rx); //if(fabs(ix0-rx)>0.98) ix0=ceil (rx);
         ix1=ceil (rx); //if(fabs(ix1-rx)>0.98) ix1=floor(rx);
         iy0=floor(ry); //if(fabs(iy0-ry)>0.98) iy0=ceil (ry);
         iy1=ceil (ry); //if(fabs(iy1-ry)>0.98) iy1=floor(ry);
         iz0=floor(rz); //if(fabs(iz0-rz)>0.98) iz0=ceil (rz);
         iz1=ceil (rz); //if(fabs(iz1-rz)>0.98) iz1=floor(rz);
         // xxxx
         if(ix==0) sx=vx+dx+(int)ix0; if(ix==1) sx=vx+dx+(int)ix1;
         if(iy==0) sy=vy+dy+(int)iy0; if(iy==1) sy=vy+dy+(int)iy1;
         if(iz==0) sz=vz+dz+(int)iz0; if(iz==1) sz=vz+dz+(int)iz1;
         // with trans_end
         if(NDIMS==2) { az=0; sz=0; }
         // Sanity checks
         sane=NO;
         if((sx>=0)&&(sx<GRIDX))
         if((sy>=0)&&(sy<GRIDY))
         if((sz>=0)&&(sz<GRIDZ)) sane=YA;
         if(sane==NO) iout++;
         // Sanity checks: end
         clmove=NO;
         if (ss==0) if (sane==YA)
         if (Lreader(Lcnd,&edp->clar[sx][sy][sz])!=CLNOCEL) clmove=YA;
         if (ss==1) if (sane==YA) if (edp->rci[qr]<edp->bci[qr])
         if (Lreader(Lcnd,&edp->clar[sx][sy][sz])==CLNOCEL) clmove=YA;
         if (clmove==YA) {
            if (ss==1) Moveclsr (thid,&edp->clar[sx][sy][sz],&edp->clarq[qr][edp->rci[qr]++]);
            // updates drvaro -----------------------------
            drv=Lreader(Ldrv,&edp->clar[sx][sy][sz]);
            cnd=Lreader(Lcnd,&edp->clar[sx][sy][sz]);
            dhn=Lreader(Ldhn,&edp->clar[sx][sy][sz]);
            if (ss==0) if (drv==1) if((cnd==CLALIVE)||(cnd==CLALIVN)) {
               //if(edp->drvaro[dhn].x==sx)
               //if(edp->drvaro[dhn].y==sy)
               //if(edp->drvaro[dhn].z==sz)
               edp->drvaro[dhn].x=-1;
               edp->cndaro[dhn]=CLNOCEL;
            }
            if (ss==1) if (drv==1) if((cnd==CLALIVE)||(cnd==CLALIVN)) {
               edp->drvaro[dhn].x=sx;
               edp->drvaro[dhn].y=sy;
               edp->drvaro[dhn].z=sz;
               edp->cndaro[dhn]=Lreader(Lcnd,&edp->clar[sx][sy][sz]);
            }
            // updates drvaro_end -------------------------
            if (ss==0) Moveclsr(thid,&edp->clarq[qr][edp->bci[qr]++],&edp->clar[sx][sy][sz]);
         }
         #if(DEBUG7==YA)
         if (edp->cn==32) if (gi==gi) {
            //printf("\ncurso qr=%d bci[qr]=%d rci[qr]=%d",qr,edp->bci[qr],edp->rci[qr]);
            //printf(" sx=%d sy=%d sz=%d",sx,sy,sz);
         }
         #endif
      } // close for cycle
      dista=Distance(nx,ny,nz,abs(ax),abs(ay),abs(az));
      //if(ss==0) if(dista>1*distmax) done=YA;
      //if(ss==1) if(dista>2*distmax) done=YA;
      if(iout>0) done=YA;
      if(ss==1) if(edp->rci[qr]>=edp->bci[qr]) done=YA;
      edp->uui[qr]++;
   }  while (done==NO);
   cvar=cvar; //anchor
}

#if(DEBUG7==YA)
if (gi==0) printf("\nss=%5d",ss);
if (gi==0) if (ss==0) for(qr=0;qr<8;qr++) printf(" %5d",edp->bci[qr]);
if (gi==0) if (ss==1) for(qr=0;qr<8;qr++) printf(" %5d",edp->rci[qr]);
#endif

GTLEOF:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
void Body::Gridinit(int thid,int gi,int as) {
char str[20];
int  hi,ii,xi,ki,si,zi,vx,vy,vz,aiv,biv,aa;
Coord cd;
Exbd *edp=exbd[thid];

if(as!=0) goto LABEOF;

strcpy(str,"driver overflow");

if(ISGRID==0) {
   for(zi=0;zi<ZYGTOT;zi++) {
      #if(CFLAG0==YA)
      for(ii=0;ii<CLKMAX;ii++) edp->mocnew[ii]=0; edp->smocnew=SMOCMA+zi;
      cd.x=edp->zygx[zi]; cd.y=edp->zygy[zi]; cd.z=edp->zygz[zi];
      edp->moclp.dhnrc3=0; // should be -1, but unsigned short
      edp->isval=0; edp->dltcrt=as;
      Dharupd (thid,gi,as,-1,YA,CLALIVN, 0,&cd);
      Daughter(thid,gi,as,-1,YA,CLALIVN,-1,&cd);
      Dthrmnet(thid,gi,as,-1,YA,CLALIVN,-1,&cd);
      Lwriter(Lcol,&edp->clar[cd.x][cd.y][cd.z],-1,-1,-1,7);
      #endif
      #if(MNETON==YA)
      edp->clar[vx][vy][vz].mclnr=edp->dhnr;
      // oxarap
      for(xi=0;xi<OXARSZ;xi++)
         edp->mtar[edp->clar[vx][vy][vz].mclnr].oxarap[xi]=1;
      for(ki=0;ki<2;ki++) for(si=0;si<SZSUSP;si++)
         edp->mtar[edp->clar[vx][vy][vz].mclnr].iosmsk[ki][si]=3;
      edp->mtar[edp->clar[vx][vy][vz].mclnr].olrxxx=-1;
      edp->mtar[edp->clar[vx][vy][vz].mclnr].set=1;
      #endif
   }
}
if(ISGRID==1) {
   edp->dhnr=0;
   for(vz=0;vz<GRIDZ;vz++)
   for(vy=GRIDY-1;vy>=0;vy--)
   for(vx=0;vx<GRIDX;vx++) {
      aiv=edp->envr.etisooodp0grid[vx][vy][vz];
      biv=edp->envr.cdisooodp0grid[vx][vy][vz];
      if (aiv==-1) { // empty cells
      }
      if((aiv!=-1)&&(aiv< 30000)) { // normal cells
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],aiv,0,CLALIVE,biv);
      }
      if((aiv!=-1)&&(aiv>=30000)&&(aiv<60000)) { // cells asleep
         aiv-=30000;
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],aiv,0,CLALIVE,biv);
      }
      if((aiv!=-1)&&(aiv> 60000)) { // driver cells
         aiv-=60000;
         if(edp->dhnr>(int)pow((float)4,(float)XRESSQ)) Leavexec(str);
         for(hi=0;hi<CLKMAX;hi++) edp->dhar[aiv].moc[hi]=0;
         edp->dhar[aiv].moc[0]=aiv;
         edp->dhar[aiv].lcrstp=0;
         if(edp->dhnr<aiv) edp->dhnr=aiv;
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],aiv,+1,CLALIVE,biv);
      }
   }
}

if(ISGRID==2) {
   // writes drv signals to one quadrant
   FORVXYZ
      if((vz<=GRIDZ/2)&&(vy<=GRIDY/2)&&(vz<=GRIDZ/2))
      if((vx%NDQBLC==0)&&(vy%NDQBLC==0)&&(vz%NDQBLC==0))
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,-1,255);
   // copies symmetrically to other quadrants
   FORVXYZ if(vx>GRIDX/2) {
      aa=GRIDX-1-vx;
      Copyclsr(&edp->clar[vx][vy][vz],&edp->clar[aa][vy][vz]); }
   FORVXYZ if(vy>GRIDY/2) {
      aa=GRIDY-1-vy;
      Copyclsr(&edp->clar[vx][vy][vz],&edp->clar[vx][aa][vz]); }
   FORVXYZ if(vz>GRIDZ/2) {
      aa=GRIDZ-1-vz;
      Copyclsr(&edp->clar[vx][vy][vz],&edp->clar[vx][vy][aa]); }

   ii=0;
   FORVXYZ {
      //aa=Rnd1(16);
      aa=7;
      if(Lreader(Lcol,&edp->clar[vx][vy][vz])==255) { // drv
         for(hi=0;hi<CLKMAX;hi++) edp->dhar[ii].moc[hi]=0;
         edp->dhar[ii].moc[0]=ii;
         edp->dhar[ii].lcrstp=0;
         edp->dhnr=ii;
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],ii,+1,CLALIVE,aa);
         ii++;
      }
      else {
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],+0,+0,CLALIVE,aa);
      }
   }
}

LABEOF:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
void  Body::Gridupd(int thid,int gi,int as,int us,int ff) {
int   pi,gy,vx,vy,vz,aiv,biv,drv,clcnd,eval,hs;
float shad,shas;
Exbd *edp=exbd[thid];

pi=gi/POPXSZ; gy=gi%POPXSZ;

// ACTUAL, as grids (aiv for dhnr, biv for conr)
if(((pi==0)&&(gy==0))||((pi==0)&&(gy==68))) FORVXYZ {
   aiv=-1; biv=-1;
   if (edp->clar[vx][vy][vz].dhnrc3!=65535) {
      drv  =Lreader(Ldrv,&edp->clar[vx][vy][vz]);
      clcnd=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
      if(clcnd==CLALIVE) aiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
      if(clcnd==CLALIVE) biv=Lreader(Lcol,&edp->clar[vx][vy][vz]);
      if(clcnd==CLALIVN) aiv=Lreader(Ldhn,&edp->clar[vx][vy][vz])+30000;
      if(clcnd==CLALIVN) biv=Lreader(Lcol,&edp->clar[vx][vy][vz]);
      if(drv==1)         aiv=Lreader(Ldhn,&edp->clar[vx][vy][vz])+60000;
      if(clcnd==CLNOCEL) aiv=-1;
      if(clcnd==CLNOCEL) biv=-1;
      if(clcnd==CLCHOLN) aiv=-2;
      if(clcnd==CLCHOLN) biv=-1;
      if(clcnd==CLCHOLE) aiv=-1;
      if(clcnd==CLCHOLE) biv=-1;
      if(clcnd==CLDESTR) aiv=-1;
      if(clcnd==CLDESTR) biv=-1;
   }
   if(gi==0) if(ff==0) { 
      edp->envr.oocurdsgrid[vx][vy][vz].d0=aiv; 
      edp->envr.oocurdsgrid[vx][vy][vz].e0=biv; 
   }
}
//if(NDIMS==3)
if(edp->ausdr==YA) if(gi==0) if(ff==0) {
   hs=CLKMAX-1; if(edp->cn!=edp->cn0) hs=edp->frz[edp->gq].us;
   if(as<=hs) Savegrid(thid,0,as); }

// epacgyxdsxgrid is updated elsewhere

}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
float Body::Fitbox(int thid,int gi,int lx,int ly,int lz,int ux,int uy,int uz,float *shas) {
int   pi,gy,vx,vy,vz,aiv,biv,fiv,ci,ides,iins,ont,gpts,bpts,bad;
float shad,bdes,bins,bous,cins,xins,cinsar[COLORS],shco0,afv,bfv,oc,ious;
Clsr  *clp,*clf;
Exbd  *edp=exbd[thid];

pi=gi/POPXSZ; gy=gi%POPXSZ;

bad=NO; gpts=0; bpts=0; ides=0; iins=0; ious=0; for(ci=0;ci<COLORS;ci++) cinsar[ci]=0;
for(vx=lx;vx<=ux;vx++) for(vy=ly;vy<=uy;vy++) for(vz=lz;vz<=uz;vz++) {
   clp=&edp->clar[vx][vy][vz]; clf=&edp->clarf[vx][vy][vz];
   aiv=edp->envr.cdtgooodplgrid[vx][vy][vz];
   if(clp->dhnrc3==65535) biv=-1; // For speed
   else biv=((Lreader(Lcnd,clp)==CLALIVE) || (Lreader(Lcnd,clp)==CLALIVN)) ? Lreader(Lcol,clp):-1;
   #if(CFLAG7==1)
   if(clf->dhnrc3==65535) fiv=-1; // For speed
   else fiv=((Lreader(Lcnd,clf)==CLALIVE) || (Lreader(Lcnd,clf)==CLALIVN)) ? Lreader(Lcol,clf):-1;
   ont=NO; // on target
   if((vx< 70)&&(vy>180)&&(vz<=vz)) ont=YA; // zampa posteriore dx 
   if((vx>150)&&(vy>180)&&(vz<=vz)) ont=YA; // zampa posteriore sx
   if((vx< 85)&&(vy< 90)&&(vz< 45)) ont=YA; // zampa anteriore dx 
   if((vx>135)&&(vy< 90)&&(vz< 45)) ont=YA; // zampa anteriore sx
   if((biv!=fiv)&&(ont=YA)) gpts++;
   if((biv!=fiv)&&(ont=NO)) bpts++;
   if(bpts/(double)(gpts+bpts)>=0.10) bad=YA; 
   #endif
   #if(CFLAG0==1)
   oc=1.0;
   //if(vx< 50) if(vy>130) oc=0.5;
   //if(vx>166) if(vy>130) oc=0.5;
   //if(vy< 65) if(vz< 20) oc=0.5;
   //if(vy< 65) oc=0.5;
   #endif
   if (aiv!=-1)             ides+= 1;
   if((aiv!=-1)&&(biv!=-1)) iins+= 1;
   if((aiv==-1)&&(biv!=-1)) ious+=oc;
   #if(FITOPA==0)
   for(ci=0;ci<NCOLORS;ci++) if((aiv==ci)&&(biv==ci)) cinsar[ci]++;
   #endif
   #if(FITOPA==1)
   /*if((aiv!=-1)&&(biv!=-1)) {
      afv=(float)(abs(aiv-biv));
      if(afv<FITTOL)
         cinsar[aiv]+=1-(float)0.7*(afv/FITTOL);
   }*/
   if((aiv!=-1)&&(biv!=-1)) {
      bfv=0; afv=(float)(abs(aiv-biv));
      if(afv<FITTOL) bfv=1-(float)0.7*(afv/FITTOL);
      if((aiv<=COLTOL)&&(biv<=COLTOL)) bfv=1;
      cinsar[aiv]+=bfv;
   }
   #endif
}

// float conv
bdes=(float)ides;
bins=(float)iins;
bous=(float)ious;

cvar=cvar;//anchor
cins=0;
for(ci=0;ci<COLORS;ci++) { cins+=cinsar[ci]; }
if (cins<0) cins=0;
// calc
shco0=(float)SHCOE0;
if(edp->cn<=(18000*AMSGECOE))
   shco0*=(float)(edp->cn/(18000*AMSGECOE));
shco0=(float)SHCOE0;
xins=(float)((1-shco0)*bins+(shco0)*cins);

#if(FITOPB==0)
// calc shad
if (bdes==0) shad=-1;
else {
   shad=(float)(xins-SHCOE2*bous)/bdes;
   #if(CFLAG0==1)
   shad=(shad-SHADINIT)/(1-SHADINIT);
   if(shad<0) shad=0;
   //printf(" %3d %4.3f",gi,shad); if (gi%10==0) printf("\n");
   if((shad<0)||(shad>1)) printf("\ncazzus");
   if(bad==YA) shad=0; 
   #endif
}
// calc shas
afv=(float)(xins-SHCOE2*bous); if (afv<0) afv=0;
*shas=(bdes-afv)/SZGRID;
#endif

#if(FITOPB==1)
// calc shad
float szgrid=(float)(ux-lx+1)*(uy-ly+1)*(uz-lz+1);
if((szgrid-bdes)==0) shad=-1;
else {
   shad=(float)(szgrid-bous-bdes-SHCOE2*(bdes-xins))/(szgrid-bdes);
   if(shad<0) shad=0;
}
// calc shas
afv=(szgrid-bous-bdes-SHCOE2*(bdes-xins)); if (afv<0) afv=0;
*shas=((szgrid-bdes)-afv)/SZGRID;
#endif

return shad;
}






