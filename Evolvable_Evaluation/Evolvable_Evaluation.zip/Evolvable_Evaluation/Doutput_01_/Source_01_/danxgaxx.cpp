
#include "danxincl.h"

// Global var
extern Exbd *exbd[NCORES]; extern char cvar;

// Module var
int popsz0,popsz1;
Guy guys0[POPXSZ],guys1[POPXSZ],guysold[POPXSZ];

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Genrnd(int thid,int nn) {
int gy,bi,genok=0;

for(gy=0;gy<popsz;gy++) Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=nn;
gy=0;
while(gy<nn) {
   genok=0;
   for(bi=0;bi<dnasz;bi++)
      if(dnp[bi].flag==1) guys1[gy].gen[bi]=Rnd1(dnp[bi].bval);
      else                guys1[gy].gen[bi]=dnp[bi].bval;
   for(bi=0;bi<GHDRSZ;bi++) guys1[gy].gen[bi]=0; // header always initialized to 0
   if(Genvalid(thid,guys1[gy].gen,NULL)==YA) genok=1;
   else Gencpy(guys1[gy].gen,NULL,0,dnasz);
   guys1[gy].parents[0]=-1; guys1[gy].parents[1]=-1;
   if (genok==1) gy++;
}

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Reproduction(int thid,int sons) {
int gy,ii,rn0,son=0; float gaftsum,rn,*wheel;

// cmt: gaft must be >=0
wheel=(float *)malloc(sizeof(float)*popsz);
for(gy=0;gy<popsz;gy++) Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=sons;

gaftsum=0; for(gy=0;gy<popsz0;gy++) gaftsum+=guys0[gy].gaft;
if(gaftsum>0) {
   wheel[0]=guys0[0].gaft / gaftsum;
   for(gy=0;gy<popsz0-1;gy++) wheel[gy+1]=wheel[gy]+guys0[gy+1].gaft/gaftsum;
   for(ii=0;ii<sons;ii++) {
      rn=Rnd1(1000)/(float)1000;
      if(rn < wheel[0]) son=0;
      for(gy=0;gy<popsz0-1;gy++) if(rn>=wheel[gy] && rn<wheel[gy+1]) {
         son=gy+1;
         break; }
      Gencpy(guys1[ii].gen,guys0[son].gen,0,dnasz);
      guys1[ii].parents[0]=guys0[son].parents[0];
      guys1[ii].parents[1]=guys0[son].parents[1];
   }
}
else
   for(ii=0;ii<sons;ii++) {
      rn0=Rnd1(popsz0);
      Gycp(1,guys1,guys0,ii,rn0,1);
   }

free(wheel);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Decimation(int thid,int ndeads,unsigned char deathtype) {
int gy,*ord; float *par;

ord=(int*)malloc(sizeof(int)*popsz); par=(float*)malloc(sizeof(float)*popsz);
for(gy=0;gy<popsz;gy++) ord[gy]=0;
for(gy=0;gy<popsz;gy++) par[gy]=0;

for(gy=0;gy<POPXSZ;gy++) Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=popsz0-ndeads;

for(gy=0;gy<popsz0;gy++) par[gy]=guys0[gy].gaft;
Mysortxxxx(&par[0],popsz0,0,&ord[0]);
for(gy=0;gy<popsz0-ndeads;gy++) {
   if(deathtype==0) Gycp(1,guys1,guys0,gy,ord[gy],1);
   if(deathtype==1) Gycp(1,guys1,guys0,gy,ord[popsz0-1-gy],1);
}

free(ord); free(par);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Crossover(int thid,float pcross) {
uchar crossok=NO;
int   *crossdna0,*crossdna1,gy,ii,n,rn0,rn1,rn4,rn5,aiv,biv,vers,*crossar;
float rn3;

crossdna0=(int *)malloc(sizeof(int)*dnasz);
crossdna1=(int *)malloc(sizeof(int)*dnasz);
crossar  =(int *)malloc(sizeof(int)*popsz);

for(gy=0;gy<popsz;gy++) Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=popsz0;
for(gy=0;gy<popsz0;gy++) crossar[gy]=gy;

for(n=popsz0;n>0;n-=2) {
   ii=popsz0-n;
   rn0=-1; rn1=-1; while(rn0>=rn1) { rn0=Rnd1(n); rn1=Rnd1(n); }
   rn3=Rnd1(1000)/(float)1000;
   // Crossover attempt
   if(rn3<pcross) {
      crossok=NO; vers=0;
      while((crossok==NO) && (vers<=ATPMAX)) {
         rn4=Rnd1(dnasz-0); // 1. crossover point
         rn5=Rnd1(dnasz-0); // 2. crossover point
         if (rn4<=rn5) { aiv=rn4; biv=rn5; }
         if (rn4> rn5) { aiv=rn5; biv=rn4; }
         Gencpy(crossdna0,guys0[crossar[rn0]].gen,0,dnasz);
         Gencpy(crossdna1,guys0[crossar[rn1]].gen,0,dnasz);
         Gencpy(crossdna0,guys0[crossar[rn1]].gen,aiv,biv-aiv+1);
         Gencpy(crossdna1,guys0[crossar[rn0]].gen,aiv,biv-aiv+1);
         /*Gencpy(crossdna0,guys0[crossar[rn0]].gen,0,rn4);
         Gencpy(crossdna1,guys0[crossar[rn1]].gen,0,rn4);
         Gencpy(crossdna0,guys0[crossar[rn1]].gen,rn4,dnasz-rn4);
         Gencpy(crossdna1,guys0[crossar[rn0]].gen,rn4,dnasz-rn4);*/
         if((Genvalid(thid,&crossdna0[0],NULL)==NO)||
            (Genvalid(thid,&crossdna1[0],NULL)==NO)) goto EOB0;
         Gencpy(guys1[ii  ].gen,crossdna0,0,dnasz);
         Gencpy(guys1[ii+1].gen,crossdna1,0,dnasz);
         // parents
         guys1[ii+0].parents[0]=guys0[crossar[rn0]].parents[0];
         guys1[ii+0].parents[1]=guys0[crossar[rn1]].parents[0];
         guys1[ii+1].parents[0]=guys0[crossar[rn0]].parents[0];
         guys1[ii+1].parents[1]=guys0[crossar[rn1]].parents[0];
         // parents_end
         crossok=YA;
         EOB0:vers++;
      }
   }
   // Crossover failure
   if((rn3>=pcross) || (crossok==NO)) {
      Gycp(1,guys1,guys0,ii  ,crossar[rn0],1);
      Gycp(1,guys1,guys0,ii+1,crossar[rn1],1);
   }
   // Crossar rearrengement
   for(gy=rn0;  gy<=n-1;gy++) crossar[gy]=crossar[gy+1];
   for(gy=rn1-1;gy<=n-1;gy++) crossar[gy]=crossar[gy+1];
}

free(crossdna0);
free(crossdna1);
free( crossar );
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Mutation(int thid,float pcmutx,float maxpercmut) {
uchar dnaok;
int   *neudna,gy,ii,rn0,rn1,rn2,vers,mxchgd,di,civ;
float rfv;
Exbd *edp=exbd[thid];

neudna=(int *)malloc(sizeof(int)*dnasz);
mxchgd=(int  )(maxpercmut*dnasz);

for(gy=0;gy<popsz;gy++) Gencpy(guys1[gy].gen,NULL,0,dnasz);
popsz1=popsz0;

for(gy=0;gy<popsz0;gy++) {
   //rfv=0;
   rfv=Rnd1(1000)/(float)1000;
   dnaok=NO; vers=0;
   if(rfv<pcmutx) {
      while((dnaok==NO) && (vers<=ATPMAX)) {
         Gencpy(neudna,guys0[gy].gen,0,dnasz);
         rn0=Rnd1(mxchgd);
         for(ii=1;ii<=rn0;ii++) {
            rn1=Rnd1(dnasz-1);
            if (rn1<GHDRSZ) rn1=GHDRSZ; // no mutations in the header
            civ=1;
            // no mutation in MOSs
            /*for(di=0;di<edp->dgarsz;di++) {
               aiv=BEGNSQ+di*DGOXSQ+1+OPXXSQ+ASXXSQ+1;
               biv=aiv+(MOSXSQ*CLKMAX);
               if((rn1>=aiv)&&(rn1<biv)) civ=0;
            }
            bfv=Rnd1(1000)/(float)1000;
            if(civ==0) if(bfv<0.33) civ=1;*/
            // end
            if(civ==1)
            if(dnp[rn1].flag==1) { rn2=Rnd1(dnp[rn1].bval); neudna[rn1]=rn2; }
         }
         if(Genvalid(thid,&neudna[0],NULL)==YA) {
            Gencpy(guys1[gy].gen,neudna,0,dnasz);
            dnaok=YA;
         }
         else vers++;
      }
   }
   if((rfv>=pcmutx) || (dnaok==NO))
    { Gencpy(guys1[gy].gen,guys0[gy].gen,0,dnasz); }
}

free(neudna);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Gycp (int opt,Guy gard[],Guy gars[],int ad,int as,int n) {

for(int gy=0;gy<n;gy++) {
   Gencpy(gard[ad+gy].gen,gars[as+gy].gen,0,dnasz);
   gard[ad+gy].parents[0]=gars[as+gy].parents[0];
   gard[ad+gy].parents[1]=gars[as+gy].parents[1];
   if(opt==1) gard[ad+gy].gaft=gars[as+gy].gaft;
}
if(gard==guys0) popsz0=n;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Galoop(int thid,int opt) {
int  gy;
Exbd *edp=exbd[thid];

// Inits guys0,guys1,guysold
for(gy=0;gy<popsz;gy++) memcpy(&guys0  [gy],&edp->guy0,sizeof(Guy));
for(gy=0;gy<popsz;gy++) memcpy(&guys1  [gy],&edp->guy0,sizeof(Guy));
for(gy=0;gy<popsz;gy++) memcpy(&guysold[gy],&guys[gy], sizeof(Guy));
for(gy=0;gy<popsz;gy++) memcpy(&guys   [gy],&edp->guy0,sizeof(Guy));
// Inits parents
for(gy=0;gy<popsz;gy++) guysold[gy].parents[0]=gy;
for(gy=0;gy<popsz;gy++) guysold[gy].parents[1]=-1;

// nkids0 gen's are sons of spopsz0
Gycp(1,guys0,guysold,0,0,spopsz0);
Reproduction(thid,nkids0);
Gycp(1,guys0,guys1,0,0,nkids0);
Crossover(thid,PCROSS);
Gycp(1,guys0,guys1,0,0,nkids0);
Mutation(thid,(float)PMUTAT,(float)MPCMUT);
Gycp(1,guys ,guys1,0,0,nkids0);

// nkids1 gen's are sons of spopsz1
Gycp(1,guys0,guysold,0,spopsz0,spopsz1);
Reproduction(thid,nkids1);
Gycp(0,guys ,guys1,nkids0,0,nkids1);

// Replaces worst nkids0+nkids1 of spopsz0
Gycp(1,guys0,guysold,0,0,spopsz0);
Decimation(thid,nkids0+nkids1,0);
Gycp(0,guys ,guys1,nkids0+nkids1,0,spopsz0-nkids0-nkids1);

// New spopsz1
Genrnd(thid,spopsz1);
Gycp(0,guys, guys1,spopsz0,0,spopsz1);

// Old chmp in pos 0
memcpy(&guys[0],&guysold[0],sizeof(Guy));

// Init guys - Checks validity
for(gy=0;gy<popsz;gy++) {
   if(Genvalid(thid,guys[gy].gen,&guys[gy])==NO) {
      Genrnd(thid,1); Gencpy(guys[gy].gen,guys1[0].gen,0,dnasz); }
   guys[gy].neugy=YA;
   //guys[gy]. gaft= 0;
   /*for(gyold=0;gyold<popsz;gyold++) {
      if(memcmp(&guys[gy].gen[0],&guysold[gyold].gen[0],dnasz*sizeof(int))==0) {
         memcpy(&guys[gy],&guysold[gyold],sizeof(Guy));
         guys[gy].neugy=NO;
         break;
      }
   }*/
}

#if(DEBUG0==YA)
for(gy=0;gy<popsz;gy++) {
}
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
Pop::Pop (int thid,Body * bdp) {
Cons(thid,bdp);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Pop::Cons(int thid,Body * _popbdp) {
int  gy,bi,ivara;

popbdp=_popbdp; popsz=POPXSZ; dnasz=GENXSZ;
spopsz0=POPSZ0; nkids0=NKIDS0; spopsz1=POPSZ1; nkids1=NKIDS1;

// Init dnp -----------------------------------------------------------------
for(bi=0;bi<GENXSZ;bi++) {
   ivara=4;
   if(bi==0) ivara=DGARSZ; if(bi==1) ivara=-1; if(bi==2) ivara=DPLMAX;
   dnp[bi].bval=ivara; dnp[bi].flag=1; }
// end ----------------------------------------------------------------------

if(thid==0) {
   Genrnd(thid,popsz);
   for(gy=0;gy<popsz;gy++) {
      Gencpy(guys[gy].gen,guys1[gy].gen,0,dnasz);
      guys[gy].neugy=YA; guys[gy].gaft=0; guys[gy].shad=0;
      guys[gy].parents[0]=-1; guys[gy].parents[1]=-1;
   }
   //Gendecoder(&guys[0].gen[0],&guys[0]);
}
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Pop::Gendecoder(int thid,int gen[],Guy *gyp,int opt) {
int   ii,hi,di,bi,si,dx,dy,dz,aiv,biv,civ,ox,max,min,xf;
float coe,afv;
Dgx   curdgx; Oxr curoxr;
Coord  dpl[2];
Exbd *edp=exbd[thid];

bi=3; //first 3 numbers in the Genome are not decoded
// stepeval
Cvbase2int(&gen[bi],&edp->stepeval,XTMRSQ,4,&bi);
if(edp->stepeval<0) edp->stepeval=0;
if(edp->stepeval>CLKMAX-1) edp->stepeval=CLKMAX-1;
// stepevlr,stepevls
edp->stepevly=edp->stepeval+1;
if(edp->stepevly>CLKMAX-1) edp->stepevly=edp->stepeval;
edp->stepevlz=edp->stepeval+2;
if(edp->stepevlz>CLKMAX-1) edp->stepevlz=edp->stepeval;

// Decodes exp genome
for(ox=0;ox<edp->oxarsz;ox++) {
   // inits curoxr
   memset(&curoxr,0,sizeof(Oxr));
   bi=GHDRSZ+ox*OXRXSQ;
   curoxr.oxarpos=ox;                      // act currently unused!
   if(gen[bi++]<=1) curoxr.act=0; else curoxr.act=1; curoxr.act=-1;
   Cvbase2int (&gen[bi],&curoxr.lrxx     ,LRXXSQ,4,&bi);
   for(ii=0;ii<MAXIPS;ii++)
   Cvbase2int (&gen[bi],&curoxr.isui[ii] ,SIXXSQ,4,&bi);
   for(ii=0;ii<MAXIPS+1;ii++)
    { Cvbase2flt(&gen[bi],&afv,WHTXSQ,4,&bi);
      curoxr.whts[ii]=(double)afv; }
   Cvbase2int (&gen[bi],&curoxr.osui     ,SIXXSQ,4,&bi);
   // varrescales
   for(ii=0;ii<MAXIPS;ii++)
   Varrescale (&curoxr.isui[ii],(int)Intpower(4,SIXXSQ),SZSUSP);
   Varrescale (&curoxr.osui    ,(int)Intpower(4,SIXXSQ),SZSUSP);
   // xxxx
   memcpy(&edp->oxar[ox],&curoxr,sizeof(Oxr));
}

// Inits dgar
if (opt==0) xf=0; if (opt==1) xf=edp->dgarxf;
for(di=0;di<xf;di++)
   memcpy(&edp->dgar[di],&edp->dgar0[di],sizeof(Dgx));
for(di=xf;di<edp->dgarsz;di++)
   memcpy(&edp->dgar[di],&edp->dgx0,sizeof(Dgx));

for(di=xf;di<edp->dgarsz;di++) {
   #if(GRNMODE==YA)
   Cvbase2int(&gen[bi],&edp->sgar[di].swc,SGSNSQ,4,&bi);
   for(ii=0;ii<SGIASZ;ii++) Cvbase2int(&gen[bi],&edp->sgar[di].ifp,SGIFSQ,4,&bi);
   Cvbase2int(&gen[bi],&edp->sgar[di].thp,SGTHSQ,4,&bi);
   Cvbase2int(&gen[bi],&edp->sgar[di].cdn,SGCDSQ,4,&bi);
   Cvbase2int(&gen[bi],&edp->sgar[di].csn,SGSCSQ,4,&bi);
   if(edp->sgar[di].swc<=2) edp->sgar[di].swc =0; else edp->sgar[di].swc=1;
   if(edp->sgar[di].csn<=2) edp->sgar[di].csn=-1; else edp->sgar[di].csn=1;
   Varrescale(&edp->sgar[di].cdn,(int)Intpower(4,SGSCSQ),10);
   goto GTLEOC;
   #endif
   // inits curdgx
   memcpy(&curdgx,&exbd[thid]->dgx0,sizeof(Dgx));
   bi=BEGNSQ+di*DGENSQ;
   if(gen[bi++]<=1) curdgx.swc=0; else curdgx.swc=1;
   Cvbase2int(&gen[bi],&curdgx.exord,XORDSQ,4,&bi);
   #if(PGFREEZE==NO)
   Varrescale(&curdgx.exord,(int)pow(4,(float)XORDSQ),edp->dgarsz);
   #endif
   // input:ds
   Cvbase2int(&gen[bi],&curdgx.timer,XTMRSQ,4,&bi);
   Varrescale(&curdgx.timer,(int)Intpower(4,XTMRSQ),CLKMAX);
   Cvbase2int(&gen[bi],&biv,1,4,&bi);
   biv=3; // FORCE dp relevant
   if(biv<=1) curdgx.timer=-1; // as not relevant
   if(TMON==NO) curdgx.timer=-1;
   if(TMON==NO) gen[bi-1]=0; // on-the-fly correction
   // input:etx
   for(hi=0;hi<CLKMAX;hi++) {
      Cvbase2int(&gen[bi],&curdgx.res[hi],XRESSQ,4,&bi); }
   for(hi=0;hi<CLKMAX;hi++) {
      Cvbase2int(&gen[bi],&biv,1,4,&bi);
      // if(ivarb<=1) curdgx.etx[hi]=-1; // Force: all relevant
   }  // etx[hi] not relevant
   // output:dpl
   for(ii=0;ii<6;ii++) {
      if((ii==0)||(ii==2)||(ii==4)) gen[bi]=0; //FORCE (pt 0 in NWB, 1 in SEF)
      if((ii==1)||(ii==3)||(ii==5)) gen[bi]=2; //FORCE (pt 0 in NWB, 1 in SEF)
      if(gen[bi++]<=1) aiv=-1; else aiv=+1;
      Cvbase2int(&gen[bi],&biv,XDPLSQ-1,4,&bi);
      // dpl rescale or threshold
      //Varrescale(&ivara,(int)pow(4,DPLSQ-1),DPLMAX);
      //if(ivara>DPLMAX) ivara=DPLMAX;
      civ=edp->frz[edp->xqar[di]].dl;
      if(biv>civ) biv=civ; aiv*=biv;
      // allows for external proliferation
      if((ii==0)||(ii==2)||(ii==4)) aiv+=1; // maxval=0 -> maxval=+1
      if((ii==1)||(ii==3)||(ii==5)) aiv-=1; // minval=0 -> minval=-1
      // dpl assignment
      if(ii==0) dpl[0].x=aiv; // - negative
      if(ii==1) dpl[0].y=aiv; // + positive
      if(ii==2) dpl[0].z=aiv; // - negative
      if(ii==3) dpl[1].x=aiv; // + positive
      if(ii==4) dpl[1].y=aiv; // - negative
      if(ii==5) dpl[1].z=aiv; // + positive
   }
   // output:ms0,ms1,shp,dgd
   Cvbase2int(&gen[bi],&curdgx.dgo.ms1,XMS0SQ,4,&bi);
   Cvbase2int(&gen[bi],&curdgx.dgo.ms0,XMS1SQ,4,&bi);
   for(ii=0;ii<9;ii++) {
      Cvbase2int(&gen[bi],&aiv,XDGDSQ,4,&bi);
      curdgx.dgo.tr[ii]=(((double)aiv/63)-0.5)*2; }
   if(NDIMS==2)
      for(ii=4;ii<8;ii++) curdgx.dgo.tr[ii]=0;
   // output:colours
   Cvbase2int(&gen[bi],&curdgx.dgo.conr,XCOLSQ,4,&bi);
   Cvbase2int(&gen[bi],&curdgx.dgo.c2nr,XCOLSQ,4,&bi);
   // output:mnet-related
   for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++)
      Cvbase2int(&gen[bi],&curdgx.dgo.iosmsk[ii][si],XSUFSQ,4,&bi);
   for(ii=0;ii<OXRCHD;ii++)
      Cvbase2int(&gen[bi],&curdgx.dgo.oxrchd[ii],XCHXSQ,4,&bi);
   Cvbase2int(&gen[bi],&curdgx.dgo.olrxxx,XOLRSQ,4,&bi);
   // end of decoding -------------------------------------------------------
   // on-the-fly corrections and forced -------------------------------------
   //if(curdgx.cgo.ms0==0) curdgx.cgo.ms0=1;
   // dx,dy,dz
   dx=(dpl[1].x-dpl[0].x+1); // ACHTUNG
   dy=(dpl[0].y-dpl[1].y+1); // ACHTUNG
   dz=(dpl[1].z-dpl[0].z+1); // ACHTUNG
   if(dx<=0) { dpl[0].x-=1; dpl[1].x+=1; }
   if(dy<=0) { dpl[1].y-=1; dpl[0].y+=1; }
   if(dz<=0) { dpl[0].z-=1; dpl[1].z+=1; }

   //max,min
   max=(dx >=dy) ? dx  : dy;
   max=(max>=dz) ? max : dz;
   min=(dx <=dy) ? dx  : dy;
   min=(min<=dz) ? min : dz;
   coe=(min/(float)max);
   //printf("%f\n",coe);
   if(coe<0.5) {
      //printf("caught ");
      dpl[0].y=dpl[1].x; dpl[1].y=dpl[0].x;
      dpl[0].z=dpl[0].x; dpl[1].z=dpl[1].x;
   }
   #if(SPHERE==1)
   dpl[0].x=-dpl[1].x; dpl[1].x=+dpl[1].x;
   dpl[0].y=+dpl[1].x; dpl[1].y=-dpl[1].x;
   dpl[0].z=-dpl[1].x; dpl[1].z=+dpl[1].x;
   #endif
   Setedges(&dpl[0],&dpl[1],&curdgx.dgo.dpl[0]);
   // end -------------------------------------------------------------------
   memcpy(&edp->dgar[di],&curdgx,sizeof(Dgx));
   #if(GRNMODE==YA)
   GTLEOC: cvar=cvar;//dbg anchor
   #endif
}
// Last inits
for(di=0;di<edp->dgarsz;di++) {
   edp->dgar[di].arpos=di;
   #if(DEBUG7==YA) // Measure to increase "ageing"
   if((edp->dgar[di].as>ASFITX)&&(edp->dgar[di].as<=CLKMAX))
      edp->dgar[di].on=1;
   #endif
}

// Sorts by exord ?
cvar=cvar; //anchor
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
uchar Pop::Genvalid(int thid,int gen[],Guy *gyp) {
uchar res; int di,dx,dy,dz;
Exbd *edp=exbd[thid];

res=YA;
Gendecoder(0,&gen[0],gyp,1);
for(di=0;di<edp->dgarsz;di++) {
   if(edp->dgar[di].exord!=-1) {
      dx=(edp->dgar[di].dgo.dpl[1].x-edp->dgar[di].dgo.dpl[0].x+1);
      dy=(edp->dgar[di].dgo.dpl[0].y-edp->dgar[di].dgo.dpl[1].y+1);
      dz=(edp->dgar[di].dgo.dpl[1].z-edp->dgar[di].dgo.dpl[0].z+1);
      if(dx<=0) res=NO; // useful for "external" proliferation
      if(dy<=0) res=NO; // useful for "external" proliferation
      if(dz<=0) res=NO; // useful for "external" proliferation
      //if(edp->dgar[di].dgo.dpl[0].x>0) res=NO;
      //if(edp->dgar[di].dgo.dpl[0].y>0) res=NO;
      //if(edp->dgar[di].dgo.dpl[1].x<0) res=NO;
      //if(edp->dgar[di].dgo.dpl[1].y<0) res=NO;
   }
}
return res;
}


