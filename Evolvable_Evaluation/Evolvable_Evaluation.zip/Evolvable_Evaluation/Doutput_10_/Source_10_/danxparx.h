
// version:

#define _CRT_SECURE_NO_DEPRECATE

// Frequently modified, always ----------------------------
#define MYOMP     0
#define MYMPI     1
#define NCORES    32
#define CYCLES    275000
#define SHOWPACE  200
#define RELOAD    NO
#define REPLAY    NO
#define GRNMODE   NO //YA
// Frequently modified, specific --------------------------
#define RNSEED 110 // moved from group "GA"
#define TAGPACE   10
#define PLSTEVAL  0.015 // mutation prob. for stepeval
#define PLGENETM  0.015 // mutation prob. for gene timers
#define FITCOEFL  1.00
#define FITDECLY  0.00
#define FITDECLZ  0.00
#define DGEVXX    3 // (other)
#define HSTSTP    500 // (other)
#define AMSGECOE  3.00 // (Dvfreeze)
#define N2DRAT    4 // normal to driver ratio (shaping-related)
#define DOP2NS    3 // doper2 neighbourhood size (shaping-related)
#define DOPDSTB   7 // dopnew neighbourhood size (shaping-related), bulk
#define DOPDSTS   7 // dopnew neighbourhood size (shaping-related), surface
#define DOPRATB  64 // dopnew min number of cell of a region (cell ratio), bulk
#define DOPRATS  16 // dopnew min number of cell of a region (cell ratio), surface
#define NDQBLC   -1 // normal to driver quot for 'marble' block (shaping-related)
#define FLDGAP    7 // gap between fields
#define SRCDST  550 // max source distance
#define REGFDS   71 // regeneration first ds
// Big options --------------------------------------------
#define ISGRID    0  // to load initial grid status
#define NICHEX    YA // for niching in fitness fct
#define REMRED    NO // for remove-redeploy procedure
#define TMON      YA // to disable timers
#define MNETON    NO // for metabolic computation
#define AUTOGP    NO // GP feature
#define PGFREEZE  NO // progressive freezing
#define PGFTEVAL  NO // progressive fitness evaluation
#define EVFTEVAL  YA // evolvable fitness evaluation
#define MOCDEV    YA // if NO it's used only moc set of the best (PF)
#define SPHERE    0  // uses spheres
#define TAGCHK    YA // tagchk
#define DOPAON    NO // Dop always ON with PGFREEZE=YA
#define DOPNEW    NO // New doping mechanism
#define NOCANC    0  // #if option. No cancellation of cells (for val=1,2)
#define DOPONE    YA // one round of doping only for each ds
#define DOPALN    YA // driver conversion only on "fresh" cells
#define NEQUAL    YA // equal MOC not allowed
// PGFREEZE: if YA means strict PF, one by one!!!
// PGFREEZE: if NO means no PF at all!!!
// Space and time related ---------------------------------
#define NDIMS     3  // if() option. Number of dimensions
#define COLORS   16
#define COLTOL   -1  // below colour differences are not counted
#define GRIDX    38
#define GRIDY   134
#define GRIDZ    94
#define SZGRID   (GRIDX*GRIDY*GRIDZ)
#define ZYGSSS   {19,67,21,1,1,1,25,27,11,25,27,11}
#define ZYGTOT   1
#define CLKMAX   18
#define CLKFIT   17
// Shaping-related ----------------------------------------
#define MS0MAX    3
#define DPLMAX    32 // questo parametro conta solo per DPVMAX!!! Vale frz[xqar[di]].dl !!
#define DPVMAX    ((2*DPLMAX)*(2*DPLMAX)*(2*DPLMAX)) // prolif. parallelepiped volume max
// Fitness related ----------------------------------------
#define FITOPA    1 // fitness option A
#define FITOPB    0 // fitness option B
#define SHADINIT  0.0 // shad initial value
#define FITEXP    2.5
#define FITTOL    2 // fitness tolerance
#define SHCOE0    1.00 // shad coef ([0-1] -> [b&w-color])
#define SHCOE2    0.50 // shad coef
#define FITMIX    0.00 // mix between shape and metabolism ([0-1] -> [shape-metabolism])
#define XSDS      4
#define YSDS      2
#define ZSDS      2
// Big array size ---------------------------------------------
#define DGARSZ        360  // dgar total elements
#define DHARLS      10000
#define MNETSZ      10000
#define DVPTSMAX   100000
#define NTPDIRSZ    10000
#define APOSARSZ  1500000
// Other --------------------------------------------------
#define SMOCMA    5000
#define SMOCMB    9999
#define NAPMIN    1
#define FSCMAX    0
#define FITHST    500
#define GPSTEP    2
#define SHOWED    1
#define ZSTEPS    NO
#define NSTEPS    10
#define VTKOPT    1
#define UXOUTMAX  8
#define NMORPH    4
// Debug and others
#define CFLAG0    YA
#define DEBUG0    YA
#define NEWCODE   YA
#define MUTAT0    NO

// Dvfreeze -----------------------------------------------
#define NAMS      50  // number of age milestones
#define NAMSO     10  // number of age milestones
//      AMSGE  generat. e.p." (*)    IF      // (*) interval endpoint (1st=0)
//      AMSXF  frozen instructions"  THEN
//      AMSXE  instruction e.p." (*) IF/THEN // (*) interval endpoint (1st=0)
//      AMSLS  lower step            THEN
//      AMSUS  upper step            THEN
//      AMSDL  dpl max array         THEN
#define AMSGEA   0.1, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,
#define AMSXFA     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
#define AMSXEA   360, 360, 360, 360, 360, 360, 360, 360, 360, 360,
#define AMSLSA     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
#define AMSUSA    17,  17,  17,  17,  17,  17,  17,  17,  17,  17,
#define AMSDLA    12,  12,  12,  12,  12,  12,  12,  10,  10,  10,
#define AMSFSA    17,  17,  17,  17,  17,  17,  17,  17,  17,  17,
// xxxx
#define AMSGEB  10.0,11.0,12.0,13.0,14.0,15.0,16.0,17.0,18.0,19.0,
#define AMSXFB     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
#define AMSXEB   360, 360, 360, 360, 360, 360, 360, 360, 360, 360,
#define AMSLSB     0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
#define AMSUSB    17,  17,  17,  17,  17,  17,  17,  17,  17,  17,
#define AMSDLB    10,  10,  10,  10,  10,  10,  10,  10,  10,  10,
#define AMSFSB    17,  17,  17,  17,  17,  17,  17,  17,  17,  17,
// xxxx
#define AMSGEC  20.0,21.0,22.0,23.0,24.0,25.0,26.0,27.0,28.0,29.0,
#define AMSXFC     0,   0,   0, 440, 460, 480, 500, 520, 540, 560,
#define AMSXEC   360, 360, 360, 460, 480, 500, 520, 540, 560, 580,
#define AMSLSC     0,   0,   0,  23,  24,  25,  26,  27,  28,  29,
#define AMSUSC    17,  17,  17,  23,  24,  25,  26,  27,  28,  29,
#define AMSDLC    10,  10,  10,  12,  12,  12,  12,  12,  12,  12,
#define AMSFSC    17,  17,  17,  49,  49,  49,  49,  49,  49,  49,
// xxxx
#define AMSGED  30.0,31.0,32.0,33.0,34.0,35.0,36.0,37.0,38.0,39.0,
#define AMSXFD   580, 600, 620, 640, 660, 680, 700, 720, 740, 760,
#define AMSXED   600, 620, 640, 660, 680, 700, 720, 740, 760, 780,
#define AMSLSD    30,  31,  32,  33,  34,  35,  36,  37,  38,  39,
#define AMSUSD    30,  31,  32,  33,  34,  35,  36,  37,  38,  39,
#define AMSDLD    10,  10,  10,  10,  10,  10,  10,  10,  10,  10,
#define AMSFSD    49,  49,  49,  49,  49,  49,  49,  49,  49,  49,
// xxxx
#define AMSGEE  40.0,41.0,42.0,43.0,44.0,45.0,46.0,47.0,48.0,49.0
#define AMSXFE   780, 800, 820, 840, 860, 880, 900, 920, 940, 960
#define AMSXEE   800, 820, 840, 860, 880, 900, 920, 940, 960, 980
#define AMSLSE    40,  41,  42,  43,  44,  45,  46,  47,  48,  49
#define AMSUSE    40,  41,  42,  43,  44,  45,  46,  47,  48,  49
#define AMSDLE    10,  10,  10,  10,  10,  10,  10,  10,  10,  10
#define AMSFSE    49,  49,  49,  49,  49,  49,  49,  49,  49,  49
// xxxx
#define AMSGEX {AMSGEA AMSGEB AMSGEC AMSGED AMSGEE}
#define AMSXFX {AMSXFA AMSXFB AMSXFC AMSXFD AMSXFE}
#define AMSXEX {AMSXEA AMSXEB AMSXEC AMSXED AMSXEE}
#define AMSLSX {AMSLSA AMSLSB AMSLSC AMSLSD AMSLSE}
#define AMSUSX {AMSUSA AMSUSB AMSUSC AMSUSD AMSUSE}
#define AMSDLX {AMSDLA AMSDLB AMSDLC AMSDLD AMSDLE}
#define AMSFSX {AMSFSA AMSFSB AMSFSC AMSFSD AMSFSE}

// Files-input --------------------------------------------
#define XRORDFN "/users/kdm/cndcnd/Mvvv_drd/Dinputx_xx/exrord.txt"
#define CETISFN "/users/kdm/cndcnd/Mvvv_drd/Dinputx_xx/bodddd0_ooooooooo_voxgr.txt"
#define  CDISFN "/users/kdm/cndcnd/Mvvv_drd/Dinputx_xx/boeeee0_ooooooooo_voxgr.txt"
#define  CDTGFN "/users/kdm/cndcnd/Mvvv_drc/Dinputx_xx/aaanubi_038134094_voxgr.txt"
#define  MNTGFN "/users/kdm/cndcnd/Mvvv_drc/Dinputx_xx/aaanubi_038134094_xmnet.txt"
#define    HCFN "/users/kdm/cndcnd/Mvvv_drc/Dinputx_xx/bxcgar2.txt"
#define  ASMBFN "/users/kdm/cndcnd/Mvvv_drc/Dinputx_xx/Symbols\\do_"
#define  BSMBFN "/users/kdm/cndcnd/Mvvv_drc/Dinputx_xx/Symbols\\dx_"
// Files-output -------------------------------------------
#define OUTDIRN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/"
#define  CONSFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxconsole.txt"
#define  GENXFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxgen.txt"
#define  HSTXFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxhst.txt"
#define  TAG2FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxtag2.txt"
#define  TAG3FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxtag3.txt"
#define  DGARFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxdgar.txt"
#define  DHLSFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/bxdhls.txt"
#define VTKFILE "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exvtkfn"
#define GRDFILE "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exgrdfn"
#define MNET0FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/hxmnet0.txt"
#define MNET1FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/hxmnet1.txt"
#define MNET2FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/hxmnet2.txt"
#define  ETACFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/zodddd0_ooooooooo_voxgr.txt"
#define  CDACFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/zoeeee0_ooooooooo_voxgr.txt"
// Files-output-ds grids
#define ASAD0FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/cxasad0.txt"
#define ASADXFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/cxasadx.txt"
#define ASAE0FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/cxasae0.txt"
#define ASAEXFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/cxasaex.txt"
#define ASADSFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/cxasads.txt"
#define ASAMSFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/dxasams.txt"
// I/O DEBUG
#define XDBG1FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exdbg1.txt"
#define XDBG2FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exdbg2.txt"
#define XDBG3FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exdbg3.txt"
#define XDBG4FN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exdbg4.txt"
#define XDISTFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/exdst0.txt"
#define XSUSPFN "/users/kdm/cndcnd/Mvvv_drc/Doutput_10/xxsusp.txt"

// Mnet ---------------------------------------------------
#define OXARSZ    32 // expression list size
#define SZSUSP    8
#define MAXIPS    2
#define LAYERS    3
#define SIGMA1    4
#define THRESHA   ((float)0.5)
#define OXRCHD    3
#define IPARSZ    4
#define OPARSZ    4
#define MXARSZ    4
#define EXARSZ    10
// Mnet_End -----------------------------------------------

// Variables' size in the Genome --------------------------
// Instructions, left  part -------------------------------
#define XORDSQ    5 //order of precedence field
#define XTMRSQ    3 //timer               field
#define XRESSQ    7 //regulatory set      field
// Instructions, right part -------------------------------
#define XDPLSQ    4 //displacement        field
#define XMS0SQ    1 //master switch       field
#define XMS1SQ    1 //master switch       field
#define XDGDSQ    3 //diagonal distance   field
#define XCOLSQ    2 //color number        field
#define XOLRSQ    2 //outside lr          field
#define XSUFSQ    1 //subst. filter       field
#define XCHXSQ    3 //changed oxr's       field
// Totals -------------------------------------------------
#define DGLPSQ    (1+XORDSQ+XTMRSQ+1+(XRESSQ*CLKMAX)+CLKMAX)
#define DGRAQ1    ((6*XDPLSQ)+XMS0SQ+XMS1SQ+(9*XDGDSQ)+XCOLSQ+XCOLSQ)
#define DGRBQ1    (XOLRSQ+SZSUSP+SZSUSP+(OXRCHD*XCHXSQ))
#define DGRPQ1    (DGRAQ1+DGRBQ1)
#define DGENSQ    (DGLPSQ+DGRPQ1)
#define DGARSQ    (DGENSQ*DGARSZ) // DGAR total bases
// Exp structure ------------------------------------------
#define LRXXSQ    1 // layer
#define SIXXSQ    2 // subst. identifier
#define WHTXSQ    2 // function
#define OXRXSQ    (1+LRXXSQ+(MAXIPS*SIXXSQ)+((MAXIPS+1)*WHTXSQ)+SIXXSQ)
#define OXARSQ    (OXRXSQ*OXARSZ)
// grn structure ------------------------------------------
#define SGIASZ    2 // if array size
#define SGSCSQ    1 // switch
#define SGIFSQ    7 // if part
#define SGTHSQ    7 // then part
#define SGSNSQ    1 // contribution sign
#define SGCDSQ    3 // contribution code
#define SGENSQ    (SGSCSQ+(SGIFSQ*SGIASZ)+SGTHSQ+SGSNSQ+SGCDSQ) // entire gene

// GA -----------------------------------------------------
#define NPOPUL     1 //12
#define GHDRSZ     (3+XTMRSQ) // gen header size
#define BEGNSQ    (GHDRSZ+OXARSQ)
#define GENXSZ    (GHDRSZ+OXARSQ+DGARSQ)
#define PCROSS    0.5
#define PMUTAT    0.5
#define MPCMUT    0.005
#define ATPMAX    60
#define POPSZ0    120
#define POPSZ1    24
#define POPXSZ    (POPSZ0+POPSZ1)
#define NKIDS0    96 // must be: POPSZ0 > NKIDS0+NKIDS1
#define NKIDS1    12
#define NICHESS   1
#define NICHEA    2
#define NNGUYS    (NPOPUL*POPXSZ)

// LABELS & abbreviations ---------------------------------
#define NO        0
#define YA        1
// Cell conditions
#define CLUNDEF   0 // undefined
#define CLNOCEL   1 // no cell
#define CLCHOLN   2 // cellular hole just created
#define CLCHOLE   3 // cellular hole as a result of cell died
#define CLALIVN   4 // cell just created
#define CLALIVE   5 // cell alive
#define CLDESTR   6 // cell destroyed
// xxxx
#define Ldhn      0
#define Ldrv      1
#define Lcnd      2
#define Lcol      3
#define Lxxx      4
#define FORVXYZ   for(vx=0;vx<GRIDX;vx++) for(vy=0;vy<GRIDY;vy++) for(vz=0;vz<GRIDZ;vz++)
#define sizeof_gen_ (sizeof(int)*GENXSZ)
#define sizeofcgar0 (sizeof(Cgx)*edp->cgarsz)
#define sizeofdharf (sizeof(Cge)*DHARLS)
