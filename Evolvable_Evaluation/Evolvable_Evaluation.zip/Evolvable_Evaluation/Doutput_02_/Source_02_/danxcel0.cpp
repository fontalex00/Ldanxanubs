
#include "danxincl.h"

// Global var
extern Exbd  *exbd[NCORES];

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int  main(int argc, char *argv[], char *env[]) {
int  opt;
long int msa,msb,msc,msd,msf;
Body *bdp;
//Exbd *edp=exbd[0];

#if(DEBUG0==YA)
double a=3.0,b=7.0,c;

set_fpu (0x27F);  /* use double-precision rounding */

c=a/b;
if (c==a/b) printf ("comparison succeeds\n");
else        printf ("unexpected result\n");
#endif

#if(DEBUG0==YA)
int ii,ei,gu; double bdv;
for(ii=1;ii<=20;ii++) {
   printf("\n");
   for(ei=0;ei<ii;ei++) {
      bdv=NNGUYS/(double)ii; gu=(int)(bdv*(ei+1));
      if (ei==ii-1) gu=NNGUYS; printf(" %3d",gu);
   }
}
#endif

#if(DEBUG0==YA)
printf("\nMemory check\n");
printf("sizeof clar             : %ld\n",sizeof( Clsr)*SZGRID);
printf("sizeof clarq            : %ld\n",sizeof( Clsr)*8*DPVMAX);
printf("sizeof dgar             : %ld\n",sizeof(  Dgx)*DGARSZ);
printf("sizeof dhar             : %ld\n",sizeof(  Cge)*NNGUYS);
printf("sizeof bstepsgrid       : %ld\n",sizeof( Dpel)*SZGRID);
printf("sizeof Clsr             : %ld\n",sizeof( Clsr));
printf("sizeof Exbd             : %ld\n",sizeof( Exbd));
printf("sizeof Dgx              : %ld\n",sizeof(  Dgx));
printf("sizeof Cge              : %ld\n",sizeof(  Cge));
printf("sizeof rrorder          : %ld\n",sizeof(Coord)*SZGRID);
printf("sizeof rrorderdist      : %ld\n",sizeof(float)*SZGRID);
printf("sizeof clarf            : %ld\n",sizeof( Clsr)*SZGRID);
printf("sizeof dharf            : %ld\n",sizeof(  Cge)*DHARLS);
printf("sizeof drvar0           : %ld\n",sizeof(Coord)*ASMAX*DHARLS);
printf("sizeof dgarpop          : %ld\n",sizeof(  Dgx)*DGARSZ*POPXSZ);

msa=(sizeof(Exbd)*4)/1000000;
msb=(sizeof( int)*SZGRID*4)/1000000;
msc=(sizeof(Dpel)*SZGRID*ASMAX0)/1000000;
msd=(sizeof( Guy)*NNGUYS*4)/1000000;
msf=msa+msb+msc+msd;
printf("sizeof Exbd  (MB,4 core): %ld\n",msa);
printf("sizeof envr1 (MB,4 core): %ld\n",msb);
printf("sizeof envr2 (MB,4 core): %ld\n",msc);
printf("sizeof popa  (MB,4 core): %ld\n",msd);
printf("tot                     : %ld\n",msf);
#endif

// HINT UNIX
// srand(time(0));
srand(RNSEED);

bdp =new Body();

if(argv[1]!=NULL) opt=0;
else              opt=1;

bdp->Baseloop(opt,bdp);

return 0;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Baseloop(int opt,Body *bdp) {
char  cvar=0,*atmpstr,*atmpstr1,*buffer;
int   thid,gi,pi,gy,as,ls,us,ri,ei,ce,vx,vy,vz,ii,hi,si,gl,gu,ff,eval,di;
int   rn,aa,bb,aiv,biv,bi,size;
long  t0,t1,buflen,buflen0,buflen1,buflen3;
float shas;
double gph,bdv;
FILE  *fptr00=NULL; // to avoid warning
Exbd  *edp;
Guy   *gyp,*gzp,*gtp;
#if(MYMPI==1)
int rc;
MPI_Status stat;
#endif

#if(MYOMP==1)
//omp_set_ynamic(0);
omp_set_num_threads(NCORES);
#endif

#if(MYMPI==1)
rc=MPI_Init(NULL,NULL);
if (rc!=MPI_SUCCESS)
 { printf ("Error MPI: Abort.\n"); MPI_Abort(MPI_COMM_WORLD, rc); }
else
 { printf ("\nMPI_Init ok\n"); }
MPI_Comm_size (MPI_COMM_WORLD,&size); printf ("size: %d\n",size);
#endif

// calc buflen
// sendrec_0
buflen0 =sizeof(int);
buflen0+=sizeof(int)*SZGRID; if(ISGRID==1) buflen0*=3;
buflen0+=sizeof(Mtv);
// sendrec_1
buflen1 =sizeof(int)*6;
buflen1+=sizeof(Guy);
buflen1+=sizeof(int)   * NNGUYS;
buflen1+=sizeof_gen_   *(NNGUYS/NCORES+1);
buflen1+=(GNHSZ+OXARSQ)*(NNGUYS/NCORES+1);
// sendrec_3
buflen3 =sizeof( int );
buflen3+=sizeof( int );
buflen3+=sizeof(float)*(NNGUYS/NCORES+1);
buflen3+=sizeof(float)*(NNGUYS/NCORES+1);
#if(MOCDEV==YA)
buflen3+=sizeof( Cge )*(NNGUYS/NCORES+1)*DHARLS;
buflen3+=sizeof( Dgx )*(NNGUYS/NCORES+1);
#endif
// frgenes
buflen3+=sizeof( Dgx )*(NNGUYS/NCORES+1)*(DGEVXX*ASMAX0);
// calc
buflen=(buflen1>=buflen0) ? buflen1 :buflen0;
buflen=(buflen3>=buflen ) ? buflen3 :buflen ;
printf("%ld %ld %ld %ld",buflen0,buflen1,buflen3,buflen);

buffer=(char*)malloc(buflen);

// calc all -----------------------------------------------------------------
#if(MYOMP==1)
#pragma omp parallel private(ei,thid,pi)
#endif
for(ei=0;ei<NCORES;ei++) {
   thid=Getthid(&edp);
   if (thid==ei)
    { exbd[ei] = (Exbd *)malloc(sizeof(Exbd ));
      for(pi=0;pi<NPOPS;pi++) exbd[ei]->popa[pi]=new Pop(ei,this);
      bdp->Initlocv(ei);
      bdp->Bodinit(ei);
      bdp->Envinit(ei,0);
      exbd[ei]->fdone=0; }
   printf("\nThread %d ", thid);
}
// calc all_end -------------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   //Txt2vtk(thid,1,46); exit(0);
}
// calc master_end ----------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   thid=Getthid(&edp);
   //bdp->Iogener(thid);
   //Calcmfitdist();
}
// calc master_end ----------------------------------------------------------

// calc master --------------------------------------------------------------
thid=Getthid(&edp);
if (thid==0) {
   if(opt==0) bdp->Loadmemo(0);
   if(opt==1) edp->cn0=0;
}
// calc master_end ----------------------------------------------------------

gtp=(Guy*)malloc(sizeof(Guy));
atmpstr  =(char *)malloc(200);
atmpstr1 =(char *)malloc(200);

// calc master --------------------------------------------------------------
remove(CONSFN);
thid=Getthid(&edp);
if (thid==0) {
   if(ISGRID==1) { strcpy(atmpstr1,CETISFN); Loadgrid(0,atmpstr1,0,MNTGFN); }
   if(ISGRID==1) { strcpy(atmpstr1, CDISFN); Loadgrid(0,atmpstr1,1,MNTGFN); }
   strcpy(atmpstr1,CDTGFN);
   Loadgrid(0,atmpstr1,2,MNTGFN);
}
// calc master_end ----------------------------------------------------------

Sendrec0(0,buffer,&buflen0);

t0=(long)time(0);
thid=Getthid(&edp);
for(edp->cn=edp->cn0;edp->cn<=CYCLES;edp->cn++) {

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      fptr00=fopen(CONSFN, "a");
      edp->ausdr=0; if((edp->cn%SHOWPACE)==0) edp->ausdr=1;
      strcpy(atmpstr,"\n%d ");
      if(edp->ausdr==1) {
         fprintf(stdout,atmpstr,edp->cn);
         fprintf(fptr00,atmpstr,edp->cn);
      } else fprintf(stdout,"X");
      edp->pnr=1;
   }
   // calc master_end -------------------------------------------------------

   // calc master -----------------------------------------------------------
   // rnd permutation
   thid=Getthid(&edp);
   if (thid==0) {
      for(gi=0;gi<NNGUYS;gi++) edp->rndpmt[gi]=gi;
      for(gi=1;gi<NNGUYS;gi++) {
         rn=Rnd1(NNGUYS-1)+1; // 0 is excluded
         aa=edp->rndpmt[gi];
         bb=edp->rndpmt[rn];
         edp->rndpmt[gi]=bb;
         edp->rndpmt[rn]=aa;
      }
   }
   // calc master_end -------------------------------------------------------

   GSLAVE:cvar=cvar; // slave starts here
   #if(MYOMP==1)
   thid=Getthid(&edp);
   if (thid!=0) for(ei=0;ei<NCORES;ei++) exbd[ei]->cn=exbd[0]->cn;
   #endif
   #if(MYMPI==1)
   thid=Getthid(&edp);
   if (thid!=0) edp->cn++;
   #endif

   // calc all --------------------------------------------------------------
   #if(MYOMP==1)
   #pragma omp parallel private(ei,thid,pi)
   #endif
   for(ei=0;ei<NCORES;ei++) {
      thid=Getthid(&edp);
      if (thid==ei) {
         // gq
         if((0<=edp->cn)&&(edp->cn<edp->frz[0].ge)) edp->gq=0;
         for(ii=0;ii<NAMS-1;ii++)
            if((edp->frz[ii].ge<=edp->cn)&&(edp->cn<edp->frz[ii+1].ge))
             { edp->gq=ii+1; break; }
         // boundaries of evolved sector, as number of dev. genes
         edp->dgarxf=edp->frz[edp->gq].xf;
         edp->dgarsz=edp->frz[edp->gq].xe;
         // boundaries of evolved sector, as number of bases
         for(pi=0;pi<NPOPS;pi++) {
            edp->popa[pi]->dnaxf=(GNHSZ+OXARSQ+(DGOXSQ*edp->dgarxf));
            edp->popa[pi]->dnasz=(GNHSZ+OXARSQ+(DGOXSQ*edp->dgarsz));
         }
      }
   }
   // calc all_end ----------------------------------------------------------

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      #if(PGFREEZE==YA)
      // copies frozen sector into all genomes
      aiv=GNHSZ+OXARSQ;        // boundaries of frozen sector
      biv=edp->popa[0]->dnaxf; // boundaries of frozen sector
      for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++)
         if(gi!=0)
          { gyp=&edp->popa[pi]->guys[gy];
            gzp=&edp->popa[ 0]->guys[ 0];
            memcpy(&gyp->gen[aiv],&gzp->gen[aiv],sizeof(int)*(biv-aiv)); }
      #endif
      Prexline(0);
      memcpy(&edp->guyf,&edp->popa[0]->guys[0],sizeof(Guy));
   }

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      strcpy(atmpstr,"\n[gq: %d ge: %5d xf: %3d xe: %3d ls: %d up: %d]");
      if(edp->ausdr==1) {
         printf(atmpstr,edp->gq,edp->frz[edp->gq].ge,edp->frz[edp->gq].xf,
         edp->frz[edp->gq].xe,edp->frz[edp->gq].ls,edp->frz[edp->gq].us);
      }
   }

   // calc master -----------------------------------------------------------
   // swaps guys
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=1;aa<NNGUYS;aa++) {
         bb=edp->rndpmt[aa];
         gyp=&edp->popa[aa/POPXSZ]->guys[aa%POPXSZ];
         gzp=&edp->popa[bb/POPXSZ]->guys[bb%POPXSZ];
         memcpy(gtp,gyp,sizeof(Guy));
         memcpy(gyp,gzp,sizeof(Guy));
         memcpy(gzp,gtp,sizeof(Guy));
      }
   }
   // calc master_end -------------------------------------------------------

   Sendrecv(1,buffer,&buflen1,&buflen3);

   // calc all --------------------------------------------------------------
   #if(MYOMP==1)
   #pragma omp parallel private(ei,thid,pi)
   #endif
   for(ei=0;ei<NCORES;ei++) {
      thid=Getthid(&edp);
      if (thid==ei) {
         Envinit(ei,1); // Inits env (actual grids only)
         edp->fset=0;
         // inits frgenes
         for(gi=0;gi<NNGUYS;gi++) for(di=0;di<(DGEVXX*ASMAX0);di++) {
            memcpy(&edp->frgenesc[gi][di],&edp->dgx0,sizeof(Dgx));
         }
      }
   }
   // calc all_end ----------------------------------------------------------

   // computes extremes
   gl=0; gu=NNGUYS;
   #if(MYMPI==1)
   thid=Getthid(&edp);
   bdv=NNGUYS/(double)NCORES;
   gl=(int)(bdv*thid); gu=(int)(bdv*(thid+1));
   if (thid==NCORES-1) gu=NNGUYS;
   #endif

   #if(MYOMP==1)
   #pragma omp parallel private(gl,gu,gi,thid,edp,pi,gy,as,ls,us,ce,vx,vy,vz,hi,ff,eval)
   #endif
   if (0==0) {
   gl=0; gu=NNGUYS;
   thid=Getthid(&edp);
   bdv=NNGUYS/(double)NCORES;
   gl=(int)(bdv*thid); gu=(int)(bdv*(thid+1));
   if (thid==NCORES-1) gu=NNGUYS;
   ff=0;
   for(gi=gl;gi<gu;gi++) {
      edp->fset=0;
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      ii=0;
      thid=Getthid(&edp);
      #if(DEBUG0==YA)
      if (thid==0)
         if (edp->ausdr==1) if (gy==0) printf("\nThread %d pi %d", thid, pi);
      #endif
      ii=ii+1; if(ii%100==0) if(ii==0) { printf(" "); ii=1; }
      // Inits clar & dhar
      FORVXYZ Clsrinit(&edp->clar[vx][vy][vz],CLNOCEL);
      for(ce=0;ce<DHARLS;ce++) memcpy(&edp->dhar[ce],&edp->cge0,sizeof(Cge));
      // inits mtar
      for(ce=0;ce<DHARLS;ce++) memcpy(&edp->mtar[ce],&edp->mcl0,sizeof(Mcl));
      // Inits zygotes and isgrid
      Gridinit(thid,gi);
      // Decodes gen
      if(ff==0)
         edp->popa[pi]->Gendecoder(thid,edp->guyf.gen,NULL,0);
      // dgar0
      if(ff==0)
         for(ce=0;ce<edp->dgarsz;ce++)
            memcpy(&edp->dgar0[ce],&edp->dgar[ce],sizeof(Dgx));
      if(DGARLOAD==NO)
         edp->popa[pi]->Gendecoder(thid,edp->popa[pi]->guys[gy].gen,NULL,1);
      if(DGARLOAD==YA)
         Loaddvar(thid,HCFN,edp->dgar,atmpstr);
      // shad & mfit
      edp->popa[pi]->guys[gy].shad=0;
      edp->popa[pi]->guys[gy].mfit=0;
      // development cycle
      ls=0; us=ASMAX-1;
      if(edp->fdone!=0) { ls=edp->frz[edp->gq].ls; us=edp->frz[edp->gq].us; }
      for(as=ls;as<=us;as++) {
         if ((edp->fdone==0)&&(as==edp->frz[edp->gq].ls)) {
            FORVXYZ memcpy(&edp->clarf[vx][vy][vz],&edp->clar[vx][vy][vz],sizeof(Clsr));
            memcpy(&edp->dharf[0],&edp->dhar[0],sizeof(Cge)*DHARLS);
            memcpy(&edp->mtarf[0],&edp->mtar[0],sizeof(Mcl)*DHARLS);
            edp->dhnrf=edp->dhnr;
            edp->fset=1;
         }
         if ((edp->fdone!=0)&&(as==ls)) {
            FORVXYZ memcpy(&edp->clar[vx][vy][vz],&edp->clarf[vx][vy][vz],sizeof(Clsr));
            memcpy(&edp->dhar[0],&edp->dharf[0],sizeof(Cge)*DHARLS);
            memcpy(&edp->mtar[0],&edp->mtarf[0],sizeof(Mcl)*DHARLS);
            edp->dhnr=edp->dhnrf;
         }
         Dgarprep(thid,gi,as,ls);
         Shaper  (thid,gi,as,us);
         //Doper2 (if gi==0 or it has other as ahead or is about to change ms)
         if ((ff==0)||
            ((PGFREEZE==YA)&&(DOPAON==YA))||
            ((PGFREEZE==NO)&&(edp->evtnr[as]>0))||
				((edp->cn<edp->frz[edp->gq].ge)&&((edp->cn+1)>=edp->frz[edp->gq].ge))) {
            Doper2(thid,gi,as);
         }
         if ((edp->cn<edp->frz[edp->gq].ge)&&((edp->cn+1)>=edp->frz[edp->gq].ge))
         if ((gi==0)&&(as==ls))
            printf(" dop2");
         //Doper2_end
         //fitness evaluation
         #if((PGFREEZE==YA)||(PGFTEVAL==YA))
         eval=0;
         if((as==edp->frz[edp->gq].fs)||((as==us)&&(us<edp->frz[edp->gq].fs))) eval=1;
         #endif
         #if(EVFTEVAL==YA)
         eval=0;
         if(as==edp->stepeval) { eval=1; edp->fcoef=FITCOEFL; edp->fdecl=1.00; }
         if(as==edp->stepevly) { eval=1; edp->fdecl=FITDECLY; edp->fcoef=0.00; }
         if(as==edp->stepevlz) { eval=1; edp->fdecl=FITDECLZ; edp->fcoef=0.00; }
         #endif
         //Morphogenetic fitness evaluation
         #if((PGFREEZE==YA)||(PGFTEVAL==YA))
         if(eval==1)
          { edp->fshad=Fitbox(thid,gi,0,0,0,GRIDXX-1,GRIDYY-1,GRIDZZ-1,&shas);
            edp->popa[pi]->guys[gy].shad=edp->fshad; }
         #endif
         #if(EVFTEVAL==YA)
         if(eval==1) {
            #if(DEBUG0==YA)
            if (edp->cn==4) if (gi==30)
               cvar=cvar;
            #endif
            edp->fshad=Fitbox(thid,gi,0,0,0,GRIDXX-1,GRIDYY-1,GRIDZZ-1,&shas);
            if(edp->popa[pi]->guys[gy].shad-edp->fshad<=edp->fdecl)
               edp->popa[pi]->guys[gy].shad+=edp->fcoef*edp->fshad; else
               edp->popa[pi]->guys[gy].shad=0; }
         #endif
         //Metabolic computation and metabolic fitness evaluation
         #if(MNETON==YA)
         #if((PGFREEZE==YA)||(PGFTEVAL==YA))
         if(eval==1)
          { edp->fmfit=Mnetcalc(thid,gi);
            edp->popa[pi]->guys[gy].mfit=edp->fmfit; }
         #endif
         #if(EVFTEVAL==YA)
         if(eval==1)
          { edp->fmfit=Mnetcalc(thid,gi);
            if(edp->popa[pi]->guys[gy].mfit-edp->fmfit<=edp->fdecl)
               edp->popa[pi]->guys[gy].mfit+=edp->fcoef*edp->fmfit; else
               edp->popa[pi]->guys[gy].mfit=0; }
         #endif
         #endif
         Gridupd(thid,gi,as,us);
         // for guy #0, does some operations
         if (ff==0) if (eval==1) {
            for(ri=0;ri<DHARLS;ri++)
               memcpy(&edp->dvcdk0[ri],&edp->drvcdk[ri],sizeof(Coord));
         }
         // for guy #0, does some operations
         if (ff==0) if (as==us) {
            memcpy(&edp->dhar0,&edp->dhar,sizeof(Cge)*DHARLS);
            for(ce=0;ce<DHARLS;ce++) for(hi=0;hi<ASMAX0;hi++)
               edp->dharaz[0][ce].moc[hi]=edp->dhar[ce].moc[hi];
            edp->dhnr0=edp->dhnr;
            for(ri=0;ri<DHARLS;ri++)
               memcpy(&edp->drvar0[ri],&edp->drvaro[ri],sizeof(Coord));
            edp->stepeval0=edp->stepeval;
            #if(DEBUG0==YA)
            FORVXYZ memcpy(&edp->clar0[vx][vy][vz],&edp->clar[vx][vy][vz],sizeof(Clsr));
            #endif
         }
      }
      #if(MOCDEV==YA)
      memcpy(&edp->dharal[gi][0],&edp->dhar[0],sizeof(Cge)*DHARLS);
      /*for(ce=0;ce<DHARLS;ce++)
         if((ce<=edp->dhnr)&&(edp->dhar[ce].asval<=edp->frz[edp->gq].fs))
            edp->dhnral[gi]=ce;*/
      edp->dhnral[gi]=edp->dhnr;
      #endif
      if (ff==0) gi--;
      if((ff==0)&&(edp->fset==1)) { edp->fdone=1; }
	   ff++;

      if (gi==gu-1)
      if ((edp->cn<edp->frz[edp->gq].ge)&&((edp->cn+1)>=edp->frz[edp->gq].ge))
         edp->fdone=0;
   }
   }

   #if(DEBUG0==YA)
   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      if(edp->ausdr==1) {
         fprintf(stdout,"\n\nstepeval0: %2d",edp->stepeval0);
         fprintf(fptr00,"\n\nstepeval0: %2d",edp->stepeval0);
         fprintf(stdout,"\nGC:       ");
         fprintf(fptr00,"\nGC:       ");
         for(ii=0;ii<ASMAX;ii++)
          { fprintf(stdout," %2d",ii);
            fprintf(fptr00," %2d",ii); }
         fprintf(stdout,"\ncgevnr:   ");
         fprintf(fptr00,"\ncgevnr:   ");
         aiv=0;
         for(ii=0;ii<ASMAX;ii++)
          { fprintf(stdout," %2d",edp->evtnr0[ii]);
            fprintf(fptr00," %2d",edp->evtnr0[ii]);
            aiv+=edp->evtnr0[ii]; }
         fprintf(stdout," %2d",aiv);
         fprintf(fptr00," %2d",aiv);
         fprintf(stdout,"\n");
      }
   }
   // calc master_end -------------------------------------------------------
   #endif

   Sendrecv(3,buffer,&buflen1,&buflen3);

   // calc master -----------------------------------------------------------
   // restores order guys
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=NNGUYS-1;aa>=1;aa--) {
         bb=edp->rndpmt[aa];
         //printf(" aa=%d",aa); printf(" bb=%d",bb);
         gyp=&edp->popa[aa/POPXSZ]->guys[aa%POPXSZ];
         gzp=&edp->popa[bb/POPXSZ]->guys[bb%POPXSZ];
         memcpy(gtp,gyp,sizeof(Guy));
         memcpy(gyp,gzp,sizeof(Guy));
         memcpy(gzp,gtp,sizeof(Guy));
      }
   }
   // restores mocdev
   #if(MOCDEV==YA)
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=NNGUYS-1;aa>=1;aa--) {
         bb=edp->rndpmt[aa];
         memcpy(&edp->dharaltemp[0],&edp->dharal[aa][0],sizeof(Cge)*DHARLS);
         memcpy(&edp->dharal[aa][0],&edp->dharal[bb][0],sizeof(Cge)*DHARLS);
         memcpy(&edp->dharal[bb][0],&edp->dharaltemp[0],sizeof(Cge)*DHARLS);
         edp->dhnraltemp=edp->dhnral[aa];
         edp->dhnral[aa]=edp->dhnral[bb];
         edp->dhnral[bb]=edp->dhnraltemp;
      }
   }
   #endif
   // TAGCHK restores frgenesc ----------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      for(aa=NNGUYS-1;aa>=1;aa--) {
         bb=edp->rndpmt[aa];
         memcpy(&edp->frgentmp    [0],&edp->frgenesc[aa][0],sizeof(Dgx)*(DGEVXX*ASMAX0));
         memcpy(&edp->frgenesc[aa][0],&edp->frgenesc[bb][0],sizeof(Dgx)*(DGEVXX*ASMAX0));
         memcpy(&edp->frgenesc[bb][0],&edp->frgentmp    [0],sizeof(Dgx)*(DGEVXX*ASMAX0));
      }
   }
   // TAGCHK restores frgenesc_end ------------------------------------------
   // calc master_end -------------------------------------------------------

   #if(MYMPI==1)
   thid=Getthid(&edp);
   if((thid!=0)&&((edp->cn)<CYCLES)) goto GSLAVE;
   #endif

   // calc master TAGCHK ----------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      for(gi=0;gi<NNGUYS;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         aiv=edp->popa[pi]->guys[gy].parents[0];
         biv=edp->popa[pi]->guys[gy].parents[1];
         // decodes stepeval
         bi=3; Cvbase2int(&edp->popa[pi]->guys[gy].gen[bi],
            &edp->stepeval,ASXXSQ,4,&bi);
         if (biv==-1) {
            edp->ancestc[gi]=aiv; edp->ftevalc[gi]=edp->stepeval;
         }
      }
   }
   // calc master TAGCHK_end ------------------------------------------------

   // calc master -----------------------------------------------------------
   thid=Getthid(&edp);
   if (thid==0) {
      Calcfit(0);
      #if(DEBUG0==YA)
      Tagchck2(thid);
      Tagchck3(thid);
      #endif
      if(edp->ausdr==YA)
       { Showres (0,fptr00,atmpstr); Savememo (0); }
      if(edp->cn%GPSTEP==0) Germline(0); //Leavexec("testing Germliner");
      //if(ausdr==YA) { Showres (); Savememo (); }
      for(pi=0;pi<NPOPS;pi++)
         edp->popa[pi]->Galoop(0,0);
      t1=(long)time(0); gph=(double)((edp->cn-edp->cn0+1)*3600)/(t1-t0);
      strcpy(atmpstr,"gph: %.0f \n");
      if(edp->ausdr==YA)
       { fprintf(stdout,atmpstr,gph);
         fprintf(fptr00,atmpstr,gph); }
      fclose(fptr00);
   }
}

#if(MYMPI==1)
MPI_Finalize();
#endif

free(gtp);
free(atmpstr);
free(atmpstr1);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Tagchck2(int thid) {
char  cvar=0;
int   gi,ga,gb,gc,di,ac,bc;
Exbd *edp=exbd[thid];

#if(DEBUG0==YA)
if (edp->cn==4)
   cvar=cvar;
#endif

 for(gc=0;gc<NNGUYS;gc++) {
   gb=-1; if (gc!=-1) gb=edp->ancestc[gc];
   ga=-1; if (gb!=-1) ga=edp->ancestb[gb];
   if((ga==-1)||(gb==-1)) goto GTLFFF;
   bc=-1;
   for(di=0;di<=(DGEVXX*edp->ftevalc[gc]);di++) {
      if (memcmp(&edp->frgenesc[gc][di],&edp->frgenesb[gb][di],sizeof(Dgx))!=0) {
         bc=di; break; // first gene from which the 2 guys start to diverge
      }
   }
   ac=-1;
   for(di=0;di<=(DGEVXX*edp->ftevalc[gc]);di++) {
      if (memcmp(&edp->frgenesc[gc][di],&edp->frgenesa[ga][di],sizeof(Dgx))!=0) {
         ac=di; break; // first gene from which the 2 guys start to diverge
      }
   }
   if((bc==-1)&&(ac!=-1))
   if (edp->ftevalc[gc]==edp->ftevalb[gb])
   if (edp->ftevalc[gc]==edp->ftevala[ga])
   if((edp->frgenesc[gc][ac].exeas>=0)&&(edp->frgenesc[gc][ac].exeas<ASMAX)) {
      edp->tagcnt[edp->ftevalc[gc]][edp->frgenesc[gc][ac].exeas]+=1;
      #if(DEBUG0==YA)
      if (edp->frgenesc[gc][ac].exord==-1)
         cvar=cvar;
      #endif
   }
   GTLFFF:cvar=cvar;
}

for(gi=0;gi<NNGUYS;gi++) for(di=0;di<(DGEVXX*ASMAX0);di++) {
   memcpy(&edp->frgenesa[gi][di],&edp->frgenesb[gi][di],sizeof(Dgx));
   memcpy(&edp->frgenesb[gi][di],&edp->frgenesc[gi][di],sizeof(Dgx));
   memcpy(&edp->frgenesc[gi][di],&edp->dgx0,sizeof(Dgx));
}
for(gi=0;gi<NNGUYS;gi++) {
   edp->ancesta[gi]=edp->ancestb[gi];
   edp->ancestb[gi]=edp->ancestc[gi];
   edp->ancestc[gi]=-1;
}
for(gi=0;gi<NNGUYS;gi++) {
   edp->ftevala[gi]=edp->ftevalb[gi];
   edp->ftevalb[gi]=edp->ftevalc[gi];
   edp->ftevalc[gi]=-1;
}

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Tagchck3(int thid) {
char  cvar=0;
int   pres,gc,cc,ii,si,ox,aiv;
float *par=NULL;
Dgx   *dgxp;
Exbd *edp=exbd[thid];

if (edp->cn%TAGPACE!=0) goto GTLYYY;

// assigns std values to var excluded from comparison
for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*ASMAX0);cc++) {
   dgxp=&edp->frgenesc[gc][cc];
   for(ii=0;ii<3;ii++) dgxp->dhnrx[ii]=-2;
   dgxp->arpos=-2;
   dgxp->exord=-2;
   dgxp->dhptx=-2;
   dgxp->napos=-2;
   dgxp-> fsc =-2;
   dgxp->exeas=-2;
   dgxp->dgo.ms1 =-2;
   dgxp->dgo.c2nr=-2;
   if((MNETON==NO)||(FITMIX==0.00)) {
      dgxp->dgo.olrxxx=-2;
      for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++) dgxp->dgo.iosmsk[ii][si]=-2;
      for(ox=0;ox<OXRCHD;ox++) dgxp->dgo.oxrchd[ox]=-2;
   }
}

// are old genes still present?
for(ii=0;ii<edp->hgnr;ii++) {
   edp->hstgenes[ii].copies=0;
   pres=0;
   for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*ASMAX0);cc++) {
      if (memcmp(&edp->frgenesc[gc][cc],&edp->hstgenes[ii].dgx,sizeof(Dgx))==0) {
         edp->hstgenes[ii].copies++; if (pres==0) edp->hstgenes[ii].actgen++;
         pres=1;
      }
   }
   if (pres==0) { // position is freed
      //memcpy(&edp->hstgenes[ii].dgx,&edp->dgx0,sizeof(Dgx));
      edp->hstgenes[ii].actgen=-1;
      edp->hstgenes[ii].copies=-1;
   }
}

// are there new genes?
for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*ASMAX0);cc++) {
   if (edp->frgenesc[gc][cc].mos[0]==-1) goto GTLAAA;
   pres=0; aiv=-1;
   for(ii=0;ii<edp->hgnr;ii++) {
      if (edp->hstgenes[ii].actgen!=-1) // position occupied
      if (memcmp(&edp->frgenesc[gc][cc],&edp->hstgenes[ii].dgx,sizeof(Dgx))==0) {
         pres=1; break; // if pres is 1 aiv is not used anyway
      }
      if (edp->hstgenes[ii].actgen==-1) // position free
      if (aiv==-1) {                    // assigns only once
         aiv=ii;
      }
   }
   if (pres==0) {
      if (aiv==-1) { aiv=edp->hgnr; edp->hgnr++; }
      memcpy(&edp->hstgenes[aiv].dgx,&edp->frgenesc[gc][cc],sizeof(Dgx));
      edp->hstgenes[aiv].actgen=0;
      edp->hstgenes[aiv].copies=0;
   }
   GTLAAA:cvar=cvar;
}

// sort
Ftsortxdgf(thid,par,edp->hgnr,1,edp->hstgenes);

GTLYYY:cvar=cvar;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Sendrec0(int nr,char *buffer,long *buflen0) {
char cvar=0;
int  ei,vx,vy,vz,thid,si,aiv,biv,pi,gy,gi,gl,gu;
double bdv;
Exbd *edp;
Guy  *gyp,*gzp,*gtp;
#if(MYMPI==1)
int  rc;
MPI_Status stat;
#endif

// send-receive -------------------------------------------------------------
#if(MYMPI==0)
// cn0,envr
for(ei=1;ei<NCORES;ei++) {
   exbd[ei]->cn0=exbd[0]->cn0;
   FORVXYZ {
      exbd[ei]->envr.cdtgooodplgrid[vx][vy][vz]
      =exbd[0]->envr.cdtgooodplgrid[vx][vy][vz];
      if(ISGRID!=1) goto GTL000;
      exbd[ei]->envr.etisooodp0grid[vx][vy][vz]
      =exbd[0]->envr.etisooodp0grid[vx][vy][vz];
      exbd[ei]->envr.cdisooodp0grid[vx][vy][vz]
      =exbd[0]->envr.cdisooodp0grid[vx][vy][vz];
      GTL000: cvar=cvar;
      memcpy(&exbd[ei]->envr.mtv,&exbd[0]->envr.mtv,sizeof(Mtv));
   }
}
#endif
#if(MYMPI==1) // sendrec_0
thid=Getthid(&edp);
if (thid==0) {
   si=0;
   Mpscpy(&buffer[si],&edp->cn0,sizeof(int),&si);
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.cdtgooodplgrid[vx][vy][vz],
      sizeof(int),&si); if(ISGRID!=1) goto GTL001;
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.etisooodp0grid[vx][vy][vz],
      sizeof(int),&si);
   FORVXYZ Mpscpy(&buffer[si],&edp->envr.cdisooodp0grid[vx][vy][vz],
      sizeof(int),&si);
   GTL001: cvar=cvar;
   Mpscpy(&buffer[si],&edp->envr.mtv,sizeof(Mtv),&si);
   for(ei=1;ei<NCORES;ei++)
      rc=MPI_Send(buffer,*buflen0,MPI_BYTE,ei,0,MPI_COMM_WORLD);
}
else /*FORVXYZ*/ {
   rc=MPI_Recv(buffer,*buflen0,MPI_BYTE, 0,0,MPI_COMM_WORLD,&stat);
   si=0;
   Mprcpy(&edp->cn0,&buffer[si],sizeof(int),&si);
   FORVXYZ Mprcpy(&edp->envr.cdtgooodplgrid[vx][vy][vz],&buffer[si],
      sizeof(int),&si); if(ISGRID!=1) goto GTL002;
   FORVXYZ Mprcpy(&edp->envr.etisooodp0grid[vx][vy][vz],&buffer[si],
      sizeof(int),&si);
   FORVXYZ Mprcpy(&edp->envr.cdisooodp0grid[vx][vy][vz],&buffer[si],
      sizeof(int),&si);
   GTL002: cvar=cvar;
   Mprcpy(&edp->envr.mtv,&buffer[si],sizeof(Mtv),&si);
}
#endif
// send-receive_end ---------------------------------------------------------

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Sendrecv(int nr,char *buffer,long *buflen1,long *buflen3) {
int  ei,vx,vy,vz,thid,si,aiv,biv,pi,gy,gi,gl,gu;
char cvar=0; double bdv;
Exbd *edp;
Guy  *gyp,*gzp,*gtp;
#if(MYMPI==1)
int  rc; MPI_Status stat;
#endif

if(nr!=1) goto GTLEBB;
thid=Getthid(&edp);
//aiv=0;
aiv=edp->popa[0]->dnaxf;
biv=edp->popa[0]->dnasz;
*buflen1 =sizeof(int)*6;
*buflen1+=sizeof(Guy);
*buflen1+=sizeof(int)*NNGUYS;
*buflen1+=sizeof(int)*(NNGUYS/NCORES+1)*(biv-aiv);
*buflen1+=sizeof(int)*(NNGUYS/NCORES+1)*(GNHSZ+OXARSQ);
if (edp->ausdr==1) printf(" buflen1=%ld",*buflen1);
#if(MYMPI==0)
for(ei=1;ei<NCORES;ei++) {
   exbd[ei]->cn=exbd[0]->cn;
   exbd[ei]->gq=exbd[0]->gq;
   exbd[ei]->dgarxf=exbd[0]->dgarxf;
   exbd[ei]->dgarsz=exbd[0]->dgarsz;
   memcpy(&exbd[ei]->guyf,&exbd[0]->guyf,sizeof(Guy));
   memcpy(&exbd[ei]->rndpmt[0],&exbd[0]->rndpmt[0],sizeof(int)*NNGUYS);
   for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<POPXSZ;gy++) {
      gyp=&exbd[ei]->popa[pi]->guys[gy];
      gzp=&exbd[ 0]->popa[pi]->guys[gy];
      memcpy(&gyp->gen[aiv],&gzp->gen[aiv],sizeof(int)*(biv-aiv));
      memcpy(&gyp->gen[  0],&gzp->gen[  0],sizeof(int)*(GNHSZ+OXARSQ));
   }
}
#endif
#if(MYMPI==1)
if (thid==0) {
   for(ei=1;ei<NCORES;ei++) {
      bdv=NNGUYS/(double)NCORES;
      gl=(int)(bdv*ei); gu=(int)(bdv*(ei+1));
      if (ei==NCORES-1) gu=NNGUYS;
      si=0;
      Mpscpy(&buffer[si],&edp->cn,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->gq,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->dgarxf,sizeof(int),&si);
      Mpscpy(&buffer[si],&edp->dgarsz,sizeof(int),&si);
      Mpscpy(&buffer[si],&gl,sizeof(int),&si); //boundaries
      Mpscpy(&buffer[si],&gu,sizeof(int),&si); //boundaries
      Mpscpy(&buffer[si],&edp->guyf,sizeof(Guy),&si);
      Mpscpy(&buffer[si],&edp->rndpmt[0],sizeof(sizeof(int)*NNGUYS),&si);
      for(gi=gl;gi<gu;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         gyp=&edp->popa[pi]->guys[gy];
         Mpscpy(&buffer[si],&gyp->gen[aiv],sizeof(int)*(biv-aiv),&si);
         Mpscpy(&buffer[si],&gyp->gen[  0],sizeof(int)*(GNHSZ+OXARSQ),&si);
      }
      rc=MPI_Send(buffer,*buflen1,MPI_BYTE,ei,1,MPI_COMM_WORLD);
   }
}
else {
   if (0==0) { // to keep aligned
      si=0;
      rc=MPI_Recv(buffer,*buflen1,MPI_BYTE,0,1,MPI_COMM_WORLD,&stat);
      Mprcpy(&edp->cn,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->gq,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->dgarxf,&buffer[si],sizeof(int),&si);
      Mprcpy(&edp->dgarsz,&buffer[si],sizeof(int),&si);
      Mprcpy(&gl,&buffer[si],sizeof(int),&si); //boundaries
      Mprcpy(&gu,&buffer[si],sizeof(int),&si); //boundaries
      Mprcpy(&edp->guyf,&buffer[si],sizeof(Guy),&si);
      Mprcpy(&edp->rndpmt[0],&buffer[si],sizeof(sizeof(int)*NNGUYS),&si);
      for(gi=gl;gi<gu;gi++) {
         pi=gi/POPXSZ; gy=gi%POPXSZ;
         gyp=&edp->popa[pi]->guys[gy];
         Mprcpy(&gyp->gen[aiv],&buffer[si],sizeof(int)*(biv-aiv),&si);
         Mprcpy(&gyp->gen[  0],&buffer[si],sizeof(int)*(GNHSZ+OXARSQ),&si);
      }
   }
}
#endif
GTLEBB:cvar=cvar;

if(nr!=3) goto GTLEDD;
thid=Getthid(&edp);
bdv=NNGUYS/(double)NCORES;
#if(MYMPI==0)
// consolidates pop
for(ei=1;ei<NCORES;ei++) {
   gl=(int)(bdv*ei); gu=(int)(bdv*(ei+1));
   if (ei==NCORES-1) gu=NNGUYS;
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      exbd[ 0]->popa[pi]->guys[gy].shad=
      exbd[ei]->popa[pi]->guys[gy].shad;
      exbd[ 0]->popa[pi]->guys[gy].mfit=
      exbd[ei]->popa[pi]->guys[gy].mfit;
      #if(MOCDEV==YA)
      memcpy(&exbd[0]->dharal[gi][0],&exbd[ei]->dharal[gi][0],
         sizeof(Cge)*DHARLS);
      exbd[0]->dhnral[gi]=exbd[ei]->dhnral[gi];
      #endif
      // frgenes
      memcpy(&exbd[ 0]->frgenesc[gi][0],&exbd[ei]->frgenesc[gi][0],
         sizeof(Dgx)*(DGEVXX*ASMAX0));
      // frgenes_end
   }
}
#endif
#if(MYMPI==1) // sendrec_3
gl=(int)(bdv*thid); gu=(int)(bdv*(thid+1));
if (thid==NCORES-1) gu=NNGUYS;
//aiv=(sizeof(int)*(gu-gl)*DHARLS*ASMAX0);
//biv=(sizeof(int)*(gu-gl));
if (thid!=0) {
   si=0;
   Mpscpy(&buffer[si],&gl,sizeof(int),&si); // boundaries
   Mpscpy(&buffer[si],&gu,sizeof(int),&si); // boundaries
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      gyp=&edp->popa[pi]->guys[gy];
      Mpscpy(&buffer[si],&gyp->shad,sizeof(float),&si);
      Mpscpy(&buffer[si],&gyp->mfit,sizeof(float),&si);
      #if(MOCDEV==YA)
      Mpscpy(&buffer[si],&edp->dharal[gi][0],sizeof(Cge)*DHARLS,&si);
      Mpscpy(&buffer[si],&edp->dhnral[gi],sizeof(int),&si);
      #endif
      // frgenes
      Mpscpy(&buffer[si],&edp->frgenesc[gi][0],sizeof(Dgx)*(DGEVXX*ASMAX0),&si);
   }
   rc=MPI_Send(buffer,*buflen3,MPI_BYTE,0,3,MPI_COMM_WORLD);
}
else for(ei=1;ei<NCORES;ei++) { // ACHTUNG: deve ricevere da qlq processo!
   si=0;
   rc=MPI_Recv(buffer,*buflen3,MPI_BYTE,MPI_ANY_SOURCE,3,MPI_COMM_WORLD,&stat);
   Mprcpy(&gl,&buffer[si],sizeof(int),&si); // boundaries
   Mprcpy(&gu,&buffer[si],sizeof(int),&si); // boundaries
   for(gi=gl;gi<gu;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      gyp=&edp->popa[pi]->guys[gy];
      Mprcpy(&gyp->shad,&buffer[si],sizeof(float),&si);
      Mprcpy(&gyp->mfit,&buffer[si],sizeof(float),&si);
      #if(MOCDEV==YA)
      Mprcpy(&edp->dharal[gi][0],&buffer[si],sizeof(Cge)*DHARLS,&si);
      Mprcpy(&edp->dhnral[gi],&buffer[si],sizeof(int),&si);
      #endif
      // frgenes
      Mprcpy(&edp->frgenesc[gi][0],&buffer[si],sizeof(Dgx)*(DGEVXX*ASMAX0),&si);
   }
   cvar=cvar;
}
#endif
GTLEDD:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Calcfit(int thid) {
char  cvar=0;
int   gi,pi,gy,di,dj,ord[NPOPS],pres,pj,mosr[ASMAX0],moss[ASMAX0],dgarszx;
int   riv,siv,ii,bsxpos[NPOPS];
float eh,dh,sh,mh,fitmix,shad,mfit; Dgx **dgarh;
Exbd  *edp=exbd[thid];

float  bsooar[NPOPS]; // serial, only exbd[0]. used
Guy    *bsguys[NPOPS],ordgys[NPOPS]; // serial, only exbd[0]. used

dgarh=(Dgx**)malloc(sizeof(Dgx*)*NNGUYS);
for(ii=0;ii<NNGUYS;ii++) dgarh[ii]=(Dgx*)malloc(sizeof(Dgx)*DGARSZ);

// assigns gaft
for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   shad=edp->popa[pi]->guys[gy].shad;
   mfit=edp->popa[pi]->guys[gy].mfit;
   edp->popa[pi]->guys[gy].gaft=shad;
   #if(MNETON==YA)
   fitmix=(float)FITMIX;
   edp->popa[pi]->guys[gy].gaft=shad*(1-fitmix)+mfit*fitmix;
   #endif
}

// temporary crowning (each pop)
for(pi=0;pi<NPOPS;pi++) { bsooar[pi]=-1; bsguys[pi]=NULL; }
for(pi=0;pi<NPOPS;pi++)
for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   if(bsooar[pi]< edp->popa[pi]->guys[gy].gaft) {
      bsooar[pi]= edp->popa[pi]->guys[gy].gaft;
      bsguys[pi]=&edp->popa[pi]->guys[gy];
      bsxpos[pi]=gy;
   }
}

// Transplants best guys in pos 0 of pops in decreasing order
for(pi=0;pi<NPOPS;pi++) ord[pi]=pi;
Mysortxxxx(&bsooar[0],NPOPS,0,&ord[0]);
for(pi=0;pi<NPOPS;pi++)
   memcpy(&ordgys[pi],bsguys[ord[pi]],sizeof(Guy));
for(pi=0;pi<NPOPS;pi++) {
   memcpy(&edp->popa[pi]->guys[0],&ordgys[pi],sizeof(Guy));
   // TAGCHK ----------------------------------------------
   memcpy(&edp->frgenesc[pi*POPXSZ+0][0],&edp->frgenesc[bsxpos[ord[pi]]][0],
      sizeof(Dgx)*(DGEVXX*ASMAX0));
   edp->ancestc[pi*POPXSZ+0]=edp->ancestc[bsxpos[ord[pi]]];
   edp->ftevalc[pi*POPXSZ+0]=edp->ftevalc[bsxpos[ord[pi]]];
   // TAGCHK_end ------------------------------------------
}

if(NICHEX==NO) goto EOFCT;

for(pi=0;pi<NPOPS;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);
   for(di=0;di<edp->dgarsz;di++)
      memcpy(&dgarh[gi][di],&edp->dgar[di],sizeof(Dgx));
}

// ET-based niching
for(pi=1;pi<NPOPS;pi++) {
   bsooar[pi]=-1; bsguys[pi]=NULL;
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) { //skips 1st pop
      mh=0;
      for(pj=0;pj<pi;pj++) {
         // now compares 2 dgar
         eh=0; dgarszx=0;
         //for(di=0;di<dgarsz;di++) {
         for(di=edp->frz[edp->gq].xf;di<edp->frz[edp->gq].xe;di++) {
            if(memcmp(&dgarh[pi*edp->popa[pi]->popsz+gy][di].mos[0],
               &edp->moc0,sizeof(int)*ASMAX0)) {
               dgarszx++; pres=NO;
               //for(dj=0;dj<dgarsz;dj++) {
               for(dj=edp->frz[edp->gq].xf;dj<edp->frz[edp->gq].xe;dj++) {
                  riv=pi*edp->popa[pi]->popsz+gy;
                  siv=pj*edp->popa[pj]->popsz+ 0;
                  //mosr=&dgarh[pi*edp->popa[pi]->popsz+gy][di].mos[0];
                  //moss=&dgarh[pj*edp->popa[pj]->popsz+ 0][dj].mos[0];
                  memcpy(&mosr[0],&dgarh[riv][di].mos[0],
                     sizeof(int)*ASMAX0);
                  memcpy(&moss[0],&dgarh[siv][dj].mos[0],
                     sizeof(int)*ASMAX0);
                  if((memcmp(mosr,moss,sizeof(int)*ASMAX0))==0) pres=YA;
               }
               if(pres==YA) eh++;
            }
         }
         eh/=dgarszx;                            // eh: % equal
         dh=1-eh;                                // dh: % different
         sh=1-(float)pow(dh/NICHESS,NICHEA);     // sh: % equal
         mh+=(sh);                               // normalise
      }
      #if(MNETON==NO)
      edp->popa[pi]->guys[gy].gaft=edp->popa[pi]->guys[gy].shad/(mh+1);
      #endif
      #if(MNETON==YA)
      fitmix=(float)FITMIX;
      shad=edp->popa[pi]->guys[gy].shad;
      mfit=edp->popa[pi]->guys[gy].mfit;
      edp->popa[pi]->guys[gy].gaft=(shad*(1-fitmix)+mfit*fitmix)/(mh+1);
      #endif
      // final crowning
      if(bsooar[pi]< edp->popa[pi]->guys[gy].gaft) {
         bsooar[pi]= edp->popa[pi]->guys[gy].gaft;
         bsguys[pi]=&edp->popa[pi]->guys[gy];
      }
   }
   // final crowning
   ord[pi]=pi; Mysortxxxx(&bsooar[0],NPOPS,0,&ord[0]);
   memcpy(&ordgys[pi],bsguys[ord[pi]],sizeof(Guy));
   memcpy(&edp->popa[pi]->guys[0],&ordgys[pi],sizeof(Guy));
}

for(ii=0;ii<NNGUYS;ii++) free(dgarh[ii]);
free(dgarh);

EOFCT:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Showres(int thid,FILE *fptr00,char *atmpstr) {
int   gi,pi,gy,ii,nshowed,*ord;
float *par,shad,gaft,mfit;
float gaftavg[NPOPS],shadavg[NPOPS],mfitavg[NPOPS],shadbst;
Exbd  *edp=exbd[thid];

ord=( int *)malloc(sizeof( int )*edp->popa[0]->popsz);
par=(float*)malloc(sizeof(float)*edp->popa[0]->popsz);

nshowed=SHOWED;
for(pi=0;pi<NPOPS;pi++) {
   for(gy=0;gy<edp->popa[pi]->popsz;gy++)
      par[gy]=edp->popa[pi]->guys[gy].gaft;
   Mysortxxxx(&par[0],edp->popa[pi]->popsz,0,&ord[0]);
   for(ii=0;ii<nshowed;ii++) {
      gaft=edp->popa[pi]->guys[ord[ii]].gaft*100;
      shad=edp->popa[pi]->guys[ord[ii]].shad*100;
      mfit=edp->popa[pi]->guys[ord[ii]].mfit*100;
      if(pi==0)if(ii==0) shadbst=shad;
      strcpy(atmpstr,
         "\nBEST %3d) (%3d) gaft: %5.2f shad: %5.2f mfit: %5.2f ");
      fprintf(stdout,atmpstr,ii,ord[ii],gaft,shad,mfit);
      fprintf(fptr00,atmpstr,ii,ord[ii],gaft,shad,mfit);
   }
   // avg
   gaftavg[pi]=0; shadavg[pi]=0; mfitavg[pi]=0;
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
      gaftavg[pi]+=edp->popa[pi]->guys[gy].gaft;
      shadavg[pi]+=edp->popa[pi]->guys[gy].shad;
      mfitavg[pi]+=edp->popa[pi]->guys[gy].mfit;
   }
   gaftavg[pi]=gaftavg[pi]*100/POPXSZ;
   shadavg[pi]=shadavg[pi]*100/POPXSZ;
   mfitavg[pi]=mfitavg[pi]*100/POPXSZ;
   strcpy(atmpstr,"   AVG gaft: %5.2f shad: %5.2f mfit: %5.2f ");
   fprintf(stdout,atmpstr,gaftavg[pi],shadavg[pi],mfitavg[pi]);
   fprintf(fptr00,atmpstr,gaftavg[pi],shadavg[pi],mfitavg[pi]);
}

// History
if(edp->cn%HSTSTP==0) {
   for(gi=0;gi<NNGUYS;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      edp->shdhst[edp->cn/HSTSTP][gi]=edp->popa[pi]->guys[gy].shad;
      edp->fithst[edp->cn/HSTSTP][gi]=edp->popa[pi]->guys[gy].gaft;
   }
}

free(ord);
free(par);

}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
Body::Body(void) {}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
void  Body::Bodinit(int ei) {
char  cvar=0;
int   gi,pi,di,vx,vy,vz,cx,qr,ii,ki,si,hi,nx,ny,nz,rrdivrest,ri,ci,ce;
int   val,aa,bb,cc,xx,yy,sr;
float afv; FILE  *fp;
Exbd  *edp=exbd[ei];

// mnet,oxarsz
edp->oxarsz=OXARSZ;  // init

// frz
double geara[NAMSO]=AMSGEA,xfara[NAMSO]=AMSXFA,xeara[NAMSO]=AMSXEA;
double dpara[NAMSO]=AMSLSA,upara[NAMSO]=AMSUSA,dlara[NAMSO]=AMSDLA;
double fsara[NAMSO]=AMSFSA;
double gearb[NAMSO]=AMSGEB,xfarb[NAMSO]=AMSXFB,xearb[NAMSO]=AMSXEB;
double dparb[NAMSO]=AMSLSB,uparb[NAMSO]=AMSUSB,dlarb[NAMSO]=AMSDLB;
double fsarb[NAMSO]=AMSFSB;
double gearc[NAMSO]=AMSGEC,xfarc[NAMSO]=AMSXFC,xearc[NAMSO]=AMSXEC;
double dparc[NAMSO]=AMSLSC,uparc[NAMSO]=AMSUSC,dlarc[NAMSO]=AMSDLC;
double fsarc[NAMSO]=AMSFSC;
double geard[NAMSO]=AMSGED,xfard[NAMSO]=AMSXFD,xeard[NAMSO]=AMSXED;
double dpard[NAMSO]=AMSLSD,upard[NAMSO]=AMSUSD,dlard[NAMSO]=AMSDLD;
double fsard[NAMSO]=AMSFSD;
for(ii=0;ii<NAMS;ii++) {
   if(ii>=0*NAMSO)if(ii<1*NAMSO) {
      edp->frz[ii].ge =(int)(geara[ii-0*NAMSO]*1000*AMSGECOE);
      edp->frz[ii].xf =(int) xfara[ii-0*NAMSO];
      edp->frz[ii].xe =(int) xeara[ii-0*NAMSO];
      edp->frz[ii].ls =(int) dpara[ii-0*NAMSO];
      edp->frz[ii].us =(int) upara[ii-0*NAMSO];
      edp->frz[ii].dl =(int) dlara[ii-0*NAMSO];
      edp->frz[ii].fs =(int) fsara[ii-0*NAMSO];
   }
   if(ii>=1*NAMSO)if(ii<2*NAMSO) {
      edp->frz[ii].ge =(int)(gearb[ii-1*NAMSO]*1000*AMSGECOE);
      edp->frz[ii].xf =(int) xfarb[ii-1*NAMSO];
      edp->frz[ii].xe =(int) xearb[ii-1*NAMSO];
      edp->frz[ii].ls =(int) dparb[ii-1*NAMSO];
      edp->frz[ii].us =(int) uparb[ii-1*NAMSO];
      edp->frz[ii].dl =(int) dlarb[ii-1*NAMSO];
      edp->frz[ii].fs =(int) fsarb[ii-1*NAMSO];
   }
   if(ii>=2*NAMSO)if(ii<3*NAMSO) {
      edp->frz[ii].ge =(int)(gearc[ii-2*NAMSO]*1000*AMSGECOE);
      edp->frz[ii].xf =(int) xfarc[ii-2*NAMSO];
      edp->frz[ii].xe =(int) xearc[ii-2*NAMSO];
      edp->frz[ii].ls =(int) dparc[ii-2*NAMSO];
      edp->frz[ii].us =(int) uparc[ii-2*NAMSO];
      edp->frz[ii].dl =(int) dlarc[ii-2*NAMSO];
      edp->frz[ii].fs =(int) fsarc[ii-2*NAMSO];
   }
   if(ii>=3*NAMSO)if(ii<NAMS) {
      edp->frz[ii].ge =(int)(geard[ii-3*NAMSO]*1000*AMSGECOE);
      edp->frz[ii].xf =(int) xfard[ii-3*NAMSO];
      edp->frz[ii].xe =(int) xeard[ii-3*NAMSO];
      edp->frz[ii].ls =(int) dpard[ii-3*NAMSO];
      edp->frz[ii].us =(int) upard[ii-3*NAMSO];
      edp->frz[ii].dl =(int) dlard[ii-3*NAMSO];
      edp->frz[ii].fs =(int) fsard[ii-3*NAMSO];
   }
}

#if(DEBUG0==YA)
if(ei==0) {
   printf("\n");
   for(ii=0;ii<NAMS-1;ii++) { printf("%2d ",edp->frz[ii].dl); }
   printf("\n");
}
#endif

// xqar
for(di=0;di<DGARSZ;di++) {
   val=di;
   for(ii=-1;ii<NAMS-1;ii++) {
      if(ii==-1) { aa=0;               bb=edp->frz[0].xe;    }
      else       { aa=edp->frz[ii].xe; bb=edp->frz[ii+1].xe; }
      if(((aa<=val)&&(val<bb))) { edp->xqar[di]=ii+1; break; }
   }
}

// dgarsz,cn,cn0,clarf
edp->dgarsz=DGARSZ;
edp->cn=0; edp->cn0=0;
FORVXYZ Clsrinit(&edp->clarf[vx][vy][vz],CLNOCEL);

// fithst,zyg
int zygsss[12]=ZYGSSS;
for(ii=0;ii<FITHST;ii++) for(gi=0;gi<NNGUYS;gi++) {
   edp->shdhst[ii][gi]=0;
   edp->fithst[ii][gi]=0;
}

for(ii=0;ii<4;ii++) {
   edp->zygx[ii]=zygsss[3*ii+0];
   edp->zygy[ii]=zygsss[3*ii+1];
   edp->zygz[ii]=zygsss[3*ii+2];
}

// Exdp various
FORVXYZ Clsrinit(&edp->clar [vx][vy][vz],CLNOCEL);
//FORVXYZ Clsrinit(&edp->claro[vx][vy][vz],CLNOCEL);
for(cx=0;cx<DHARLS;cx++) Clsrinit(&edp->clard[cx],CLNOCEL);
for(qr=0;qr<8;qr++) for(cx=0;cx<DPVMAX;cx++)
   Clsrinit(&edp->clarq[qr][cx],CLNOCEL);
Clsrinit(&edp->moclp,CLNOCEL);
for(di=0;di<edp->dgarsz;di++) {
   memcpy(&edp->dgar  [di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->dgare [di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->dgaro [di],&edp->dgx0,sizeof(Dgx));
}

// Mnet ---------------------------------------------------------------------
for(ce=0;ce<DHARLS;ce++) memcpy(&edp->mtar[ce],&edp->mcl0,sizeof(Mcl));
// Mnet-end -----------------------------------------------------------------

// rrorder
//if (ei!=0) goto GTLKKK;
for(nx=0;nx<1;nx++) for(ny=0;ny<1;ny++) for(nz=0;nz<1;nz++) FORVXYZ {
//for(nx=0;nx<3;nx++) for(ny=0;ny<3;ny++) for(nz=0;nz<3;nz++) FORVXYZ {
   edp->rrorder[nx][ny][nz][vx+GRIDXX*vy+(GRIDXX*GRIDYY)*vz].xx=0;
   edp->rrorder[nx][ny][nz][vx+GRIDXX*vy+(GRIDXX*GRIDYY)*vz].yy=0;
   edp->rrorder[nx][ny][nz][vx+GRIDXX*vy+(GRIDXX*GRIDYY)*vz].zz=0;
}
for(nx=0;nx<1;nx++) for(ny=0;ny<1;ny++) for(nz=0;nz<1;nz++) { // ACHTUNG!!
//for(nx=0;nx<3;nx++) for(ny=0;ny<3;ny++) for(nz=0;nz<3;nz++) {
   #if(DEBUG0==YA)
   printf(" %4d %4d %4d",nx,ny,nz);
   #endif
   // reads rord (to speed-up)
   fp=fopen(XRORDFN,"r");
   if(fp!=NULL) {
      for(ii=0;ii<(GRIDXX*GRIDYY*GRIDZZ);ii++)
         sr=fscanf(fp," %d %f %d %d %d\n",&cc,&afv,
            &edp->rrorder[nx][ny][nz][ii].xx,
            &edp->rrorder[nx][ny][nz][ii].yy,
            &edp->rrorder[nx][ny][nz][ii].zz);
      fclose(fp);
      goto GTLHHH;
   }
   // reads rord (to speed-up)_end
   FORVXYZ edp->rrodist[nx][ny][nz][vx+GRIDXX*vy+(GRIDXX*GRIDYY)*vz]
      =(float)Distance(nx,ny,nz,vx,vy,vz);
   for(ii=0;ii<(GRIDXX*GRIDYY*GRIDZZ);ii++) edp->rrord[ii]=ii;
   Mysortxxxx(edp->rrodist[nx][ny][nz],(GRIDXX*GRIDYY*GRIDZZ),1,
      edp->rrord);
   #if(DEBUG0==YA)
   printf("after sort\n");
   #endif
   for(ii=0;ii<(GRIDXX*GRIDYY*GRIDZZ);ii++) {
      edp->rrorder[nx][ny][nz][ii].zz=edp->rrord[ii]/(GRIDXX*GRIDYY);
      rrdivrest                      =edp->rrord[ii]%(GRIDXX*GRIDYY);
      edp->rrorder[nx][ny][nz][ii].yy=rrdivrest/(GRIDXX);
      edp->rrorder[nx][ny][nz][ii].xx=rrdivrest%(GRIDXX);
   }
   // writes rord (to speed-up)
   fp=fopen(XRORDFN,"w");
   if(fp!=NULL) {
      for(ii=0;ii<(GRIDXX*GRIDYY*GRIDZZ);ii++)
         fprintf(fp," %6d %6f %6d %6d %6d\n",edp->rrord[ii],
            edp->rrodist[nx][ny][nz][edp->rrord[ii]],
            edp->rrorder[nx][ny][ny][ii].xx,
            edp->rrorder[nx][ny][ny][ii].yy,
            edp->rrorder[nx][ny][ny][ii].zz);
      fclose(fp); }
   if((nx==0)&&(ny==0))fp=fopen(XDISTFN,"w");
   if(fp!=NULL) {
      for(yy=GRIDYY-1;yy>=0;yy--) {
         for(xx=0;xx<GRIDXX;xx++) {
            afv=(float)Distance(nx,ny,nz,xx,yy,0); fprintf(fp," %6f",afv); }
         fprintf(fp,"\n"); }
      fclose(fp);
   }
   // writes rord (to speed-up)_end
   GTLHHH:cvar=cvar;
}
//GTLKKK:cvar=cvar;
/*memcpy(&exbd[ei]->rrorder[1][1][1][0],&exbd[0]->rrorder[1][1][1][0],
   sizeof(Coord)*GRIDXX*GRIDYY*GRIDZZ);
memcpy(&exbd[ei]->rrodist[1][1][1][0],&exbd[0]->rrodist[1][1][1][0],
   sizeof(float)*GRIDXX*GRIDYY*GRIDZZ);
memcpy(&exbd[ei]->rrord[0],&exbd[0]->rrord[0],
   sizeof( int )*GRIDXX*GRIDYY*GRIDZZ);*/

// inits frgenes
for(gi=0;gi<NNGUYS;gi++) for(di=0;di<(DGEVXX*ASMAX0);di++) {
   memcpy(&edp->frgenesa[gi][di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->frgenesb[gi][di],&edp->dgx0,sizeof(Dgx));
   memcpy(&edp->frgenesc[gi][di],&edp->dgx0,sizeof(Dgx));
}
// inits hstgenes
for(ii=0;ii<10000;ii++)
 { memcpy(&edp->hstgenes[ii].dgx,&edp->dgx0,sizeof(Dgx));
   edp->hstgenes[ii].actgen=-1; // -1 indicates array position is free
   edp->hstgenes[ii].copies=-1; }
edp->hgnr=0;
// inits ancest and tagcnt
for(gi=0;gi<NNGUYS;gi++)
 { edp->ancesta[gi]=-1;
   edp->ancestb[gi]=-1;
   edp->ancestc[gi]=-1; }
for(ri=0;ri<ASMAX;ri++) for(ci=0;ci<ASMAX;ci++) edp->tagcnt[ri][ci]=0;

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Initlocv (int thid) {
int  ii,hi,si;
Exbd *edp=exbd[thid];

// Inits et0
for(hi=0;hi<ASMAX0;hi++) edp->moc0[hi]=-1;

// Inits cgo0
edp->dgo0.ms0=-1; edp->dgo0.conr=-1;
for(ii=0;ii<2;ii++) {
   edp->dgo0.dpl[ii].xx=-1;
   edp->dgo0.dpl[ii].yy=-1;
   edp->dgo0.dpl[ii].zz=-1;
}

// Inits dgx0
edp->dgx0.exord=-1;
edp->dgx0.on   =-1;
edp->dgx0.timer=-1;
edp->dgx0.arpos=-1;
for(ii=0;ii<3;ii++) edp->dgx0.dhnrx[ii]=-1;
for(hi=0;hi<ASMAX0;hi++) edp->dgx0.mos[hi]=-1;
memcpy(&edp->dgx0.dgo,&edp->dgo0,sizeof(Dgo));

// Inits guy0
edp->guy0.neugy=YA; edp->guy0.gaft=0; edp->guy0.shad=-1;
memset(&edp->guy0.gen,0,sizeof(int)*GENXSZ);

// Inits dpel0
edp->dpel0.d0=-1; edp->dpel0.e0=-1;

// Inits cl0
edp->cl0=new Cell(NULL,&edp->moc0[0],CLNOCEL);

// Inits cs0
Lwriter(Lxxx,&edp->cs0,-1,-1,CLNOCEL,-1);
edp->cs0.dhnrc3=65535;
edp->cs0.marko=-1;
#if(MNETON==YA)
edp->cs0.mclnr=-1;
#endif

// Inits cge0
memcpy(&edp->cge0.dgx,&edp->dgx0,sizeof(Dgx));
for(hi=0;hi<ASMAX0;hi++) edp->cge0.moc[hi]=-1;
edp->cge0.ncells=0; edp->cge0.asval=-1;

// Inits mcl0
for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++) edp->mcl0.iosmsk[ii][si]=0;
for(si=0;si<OXARSZ;si++) edp->mcl0.oxarap[si]=0;
edp->mcl0.olrxxx=-1; edp->mcl0.set=0;

}


//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Envinit(int thid,int opt) {
char cvar=0;
int  as,vx,vy,vz;
Exbd *edp=exbd[thid];

if(opt==0) {
   if   (thid==00) edp->envr.ooacooodpagrid
      =(Dpel****)malloc(sizeof(Dpel***)*ASMAX );
   for(as=0;as<ASMAX;as++) {
      if(ISGRID!=1) goto GTL000;
      if(as  ==00) edp->envr.etisooodp0grid
      =(int  ***)malloc(sizeof(int  **)*GRIDXX);
      if(as  ==00) edp->envr.cdisooodp0grid
      =(int  ***)malloc(sizeof(int  **)*GRIDXX);
      GTL000:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid
      =(int  ***)malloc(sizeof(int  **)*GRIDXX);
      if(thid==00) edp->envr.ooacooodpagrid[as]
      =(Dpel ***)malloc(sizeof(Dpel **)*GRIDXX);
   }
   for(as=0;as<ASMAX;as++) for(vx=0;vx<GRIDXX;vx++) {
      if(ISGRID!=1) goto GTL001;
      if(as  ==00) edp->envr.etisooodp0grid    [vx]
      =(int   **)malloc(sizeof(int   *)*GRIDYY);
      if(as  ==00) edp->envr.cdisooodp0grid    [vx]
      =(int   **)malloc(sizeof(int   *)*GRIDYY);
      GTL001:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid    [vx]
      =(int   **)malloc(sizeof(int   *)*GRIDYY);
      if(thid==00) edp->envr.ooacooodpagrid[as][vx]
      =(Dpel  **)malloc(sizeof(Dpel  *)*GRIDYY);
   }
   for(as=0;as<ASMAX;as++) for(vx=0;vx<GRIDXX;vx++) for(vy=0;vy<GRIDYY;vy++){
      if(ISGRID!=1) goto GTL002;
      if(as  ==00) edp->envr.etisooodp0grid    [vx][vy]
      =(int    *)malloc(sizeof(int    )*GRIDZZ);
      if(as  ==00) edp->envr.cdisooodp0grid    [vx][vy]
      =(int    *)malloc(sizeof(int    )*GRIDZZ);
      GTL002:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid    [vx][vy]
      =(int    *)malloc(sizeof(int    )*GRIDZZ);
      if(thid==00) edp->envr.ooacooodpagrid[as][vx][vy]
      =(Dpel   *)malloc(sizeof(Dpel   )*GRIDZZ);
   }
}

// Inits
if(opt==0) {
   for(as=0;as<ASMAX;as++) FORVXYZ {
      if(ISGRID!=1) goto GTL003;
      if(as  ==00) edp->envr.etisooodp0grid[vx][vy][vz]=0;      // ACHTUNG
      if(as  ==00) edp->envr.cdisooodp0grid[vx][vy][vz]=0;      // ACHTUNG
      GTL003:cvar=cvar;
      if(as  ==00) edp->envr.cdtgooodplgrid[vx][vy][vz]=0;      // ACHTUNG
      if(thid==00) memcpy(&edp->envr.ooacooodpagrid[as][vx][vy][vz],
         &edp->dpel0,sizeof(Dpel));
   }
}

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Loadgrid(int thid,char *file,int opt,char *file2) {
int  vx,vy,vz,val,ii,si,sr; FILE *fp;
Exbd *edp=exbd[thid];

#if(NDIMS==2)
// opt=0: IS,opt=1: TG
strcpy(tmpstr,"File not found");
if((fp=fopen(file,"r"))==NULL) Leavexec(tmpstr);
if(0==0) {
   if(opt!=2) for(vx=-1;vx<GRIDXX;vx++) fscanf(fp,"%d",&val);
   for(vy= 0;vy<GRIDYY;vy++) {
      if(opt!=2) fscanf(fp,"%d",&val);
      for(vx=0;vx<GRIDXX;vx++) {
         fscanf(fp,"%d",&val);
         if(opt==0) edp->envr.etisooodp0grid[vx][GRIDYY-1-vy][0]=val;
         if(opt==1) edp->envr.cdisooodp0grid[vx][GRIDYY-1-vy][0]=val;
         if(opt==2) edp->envr.cdtgooodplgrid[vx][GRIDYY-1-vy][0]=val;
      }
   }
}
fclose(fp);
#endif

#if(NDIMS==3)
if((fp=fopen(file,"r"))==NULL) Leavexec("File not found");
ii=0;
for(vz=0;vz<GRIDZZ;vz++) for(vy=0;vy<GRIDYY;vy++) for(vx=0;vx<GRIDXX;vx++) {
   if((ii==0)||((ii+0)%GRIDXX==0))
      sr=fscanf(fp,"\n (vz:%d vy:%d vx:%d)",&val,&val,&val);
   sr=fscanf(fp," %d",&val); ii++;
   if(opt==0) edp->envr.etisooodp0grid[vx][vy][vz]=val;
   if(opt==1) edp->envr.cdisooodp0grid[vx][vy][vz]=val;
   if(opt==2) edp->envr.cdtgooodplgrid[vx][vy][vz]=val;
}
fclose(fp);
#endif

#if(MNETON==YA)
if((fp=fopen(file2,"r"))==NULL) Leavexec("File not found");
// Loads target inputs
fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].xx);
fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].yy);
fscanf(fp," %d",&edp->envr.mtv.iopar[0][0].zz);
for(ii=0;ii<EXARSZ;ii++)
   for(si=0;si<SZSUSP;si++) fscanf(fp," %f",&edp->envr.mtv.iotar[0][ii][si]);
// Loads target outputs
fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].xx);
fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].yy);
fscanf(fp," %d",&edp->envr.mtv.iopar[1][0].zz);
for(ii=0;ii<EXARSZ;ii++)
   for(si=0;si<SZSUSP;si++) fscanf(fp," %f",&edp->envr.mtv.iotar[1][ii][si]);
fclose(fp);
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Loaddvar(int thid,char *file,Dgx dgar[],char *atmpstr) {
int  di,hi,svo,sr; FILE *fp;
Exbd *edp=exbd[thid];

strcpy(atmpstr,"File not found");
if((fp=fopen(file,"r"))==NULL) Leavexec(atmpstr);
for(di=0;di<DGARSZ;di++) {
   sr=fscanf(fp,"%d)",&svo);
   sr=fscanf(fp,"%d", &dgar[di].arpos);
   sr=fscanf(fp,"%d", &dgar[di].exord);
   sr=fscanf(fp,"%d", &dgar[di].on);
   for(hi=0;hi<ASMAX0;hi++) sr=fscanf(fp,"%d",&dgar[di].mos[hi]);
   sr=fscanf(fp,"%d", &dgar[di].timer);
   sr=fscanf(fp,"%d", &dgar[di].dgo.ms0);
   sr=fscanf(fp,"%d", &dgar[di].dgo.ms1);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dpl[0].xx);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dpl[0].yy);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dpl[0].zz);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dpl[1].xx);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dpl[1].yy);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dpl[1].zz);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[0]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[1]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[2]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[3]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[4]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[5]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[6]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[7]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.dgd[8]);
   sr=fscanf(fp,"%d", &dgar[di].dgo.conr);
   sr=fscanf(fp,"%d", &dgar[di].dgo.c2nr);
   sr=fscanf(fp,"\n");
}
fclose(fp);
}
