
#include "danxincl.h"

// Global var
extern Exbd *exbd[NCORES]; extern char cvar;
#if(DEBUG0==YA)
double voxgrid[GRIDX][GRIDY][GRIDZ];
int    ordar[DHARLS];
float  dstar[DHARLS];
#endif

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Calcfit(int thid) {
int   gi,pi,gy,di,dj,ord[NPOPUL],pres,pj,resa[CLKMAX],resb[CLKMAX],dgarszx;
int   riv,siv,ii,bsxpos[NPOPUL];
float eh,dh,sh,mh,fitmix,shad,mfit; Dgx **dgarh;
float bsooar[NPOPUL]; // serial, only exbd[0]. used
Guy   *bsguys[NPOPUL],*ordgys[NPOPUL]; // serial, only exbd[0]. used
Exbd  *edp=exbd[thid];

dgarh=(Dgx**)malloc(sizeof(Dgx*)*NNGUYS);
for(ii=0;ii<NNGUYS;ii++) dgarh [ii]=(Dgx*)malloc(sizeof(Dgx)*DGARSZ);
for(pi=0;pi<NPOPUL;pi++) ordgys[pi]=(Guy*)malloc(sizeof(Guy)*NPOPUL);

// assigns gaft
for(pi=0;pi<NPOPUL;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   shad=edp->popa[pi]->guys[gy].shad;
   mfit=edp->popa[pi]->guys[gy].mfit;
   edp->popa[pi]->guys[gy].gaft=shad;
   #if(MNETON==YA)
   fitmix=(float)FITMIX;
   edp->popa[pi]->guys[gy].gaft=shad*(1-fitmix)+mfit*fitmix;
   #endif
}

// temporary crowning (each pop)
for(pi=0;pi<NPOPUL;pi++) { bsooar[pi]=-1; bsguys[pi]=NULL; }
for(pi=0;pi<NPOPUL;pi++)
for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   if(bsooar[pi]< edp->popa[pi]->guys[gy].gaft) {
      bsooar[pi]= edp->popa[pi]->guys[gy].gaft;
      bsguys[pi]=&edp->popa[pi]->guys[gy];
      bsxpos[pi]=gy;
   }
}

// Transplants best guys in pos 0 of pops in decreasing order
for(pi=0;pi<NPOPUL;pi++) ord[pi]=pi;
Mysortxxxx(&bsooar[0],NPOPUL,0,&ord[0]);
for(pi=0;pi<NPOPUL;pi++)
   memcpy(ordgys[pi],bsguys[ord[pi]],sizeof(Guy));
for(pi=0;pi<NPOPUL;pi++) {
   memcpy(&edp->popa[pi]->guys[0],ordgys[pi],sizeof(Guy));
   #if(TAGCHK==YA)
   memcpy(&edp->frgenesc[pi*POPXSZ+0][0],&edp->frgenesc[bsxpos[ord[pi]]][0],
      sizeof(Dgx)*(DGEVXX*CLKMAX));
   #endif
}

if(NICHEX==NO) goto GTLEOF;

for(pi=0;pi<NPOPUL;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);
   for(di=0;di<edp->dgarsz;di++) memcpy(&dgarh[gi][di],&edp->dgar[di],sizeof(Dgx));
}

// ET-based niching
for(pi=1;pi<NPOPUL;pi++) {
   bsooar[pi]=-1; bsguys[pi]=NULL;
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) { //skips 1st pop
      mh=0;
      for(pj=0;pj<pi;pj++) {
         // now compares 2 dgar
         eh=0; dgarszx=0;
         //for(di=0;di<dgarsz;di++) {
         for(di=edp->frz[edp->gq].xf;di<edp->frz[edp->gq].xe;di++) {
            if(memcmp(&dgarh[pi*edp->popa[pi]->popsz+gy][di].res[0],
               &edp->moc0,sizeof(int)*CLKMAX)) {
               dgarszx++; pres=NO;
               //for(dj=0;dj<dgarsz;dj++) {
               for(dj=edp->frz[edp->gq].xf;dj<edp->frz[edp->gq].xe;dj++) {
                  riv=pi*edp->popa[pi]->popsz+gy;
                  siv=pj*edp->popa[pj]->popsz+ 0;
                  memcpy(&resa[0],&dgarh[riv][di].res[0],sizeof(int)*CLKMAX);
                  memcpy(&resb[0],&dgarh[siv][dj].res[0],sizeof(int)*CLKMAX);
                  if((memcmp(resa,resb,sizeof(int)*CLKMAX))==0) pres=YA;
               }
               if(pres==YA) eh++;
            }
         }
         eh/=dgarszx;                            // eh: % equal
         dh=1-eh;                                // dh: % different
         sh=1-(float)pow(dh/NICHESS,NICHEA);     // sh: % equal
         mh+=(sh);                               // normalise
      }
      #if(MNETON==NO)
      edp->popa[pi]->guys[gy].gaft=edp->popa[pi]->guys[gy].shad/(mh+1);
      #endif
      #if(MNETON==YA)
      fitmix=(float)FITMIX;
      shad=edp->popa[pi]->guys[gy].shad;
      mfit=edp->popa[pi]->guys[gy].mfit;
      edp->popa[pi]->guys[gy].gaft=(shad*(1-fitmix)+mfit*fitmix)/(mh+1);
      #endif
      // final crowning
      if(bsooar[pi]< edp->popa[pi]->guys[gy].gaft) {
         bsooar[pi]= edp->popa[pi]->guys[gy].gaft;
         bsguys[pi]=&edp->popa[pi]->guys[gy];
      }
   }
   // final crowning
   ord[pi]=pi; Mysortxxxx(&bsooar[0],NPOPUL,0,&ord[0]);
   memcpy(ordgys[pi],bsguys[ord[pi]],sizeof(Guy));
   memcpy(&edp->popa[pi]->guys[0],ordgys[pi],sizeof(Guy));
}

for(ii=0;ii<NNGUYS;ii++) free(dgarh[ii]);
free(dgarh);
for(pi=0;pi<NPOPUL;pi++) free(ordgys[pi]);

GTLEOF:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Showres(int thid,FILE *fptr00,char *atmpstr) {
int   gi,pi,gy,ii,nshowed,*ord;
float *par,shad,gaft,mfit;
float gaftavg[NPOPUL],shadavg[NPOPUL],mfitavg[NPOPUL],shadbst;
Exbd  *edp=exbd[thid];

ord=( int *)malloc(sizeof( int )*edp->popa[0]->popsz);
par=(float*)malloc(sizeof(float)*edp->popa[0]->popsz);

nshowed=SHOWED;
for(pi=0;pi<NPOPUL;pi++) {
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) par[gy]=edp->popa[pi]->guys[gy].gaft;
   Mysortxxxx(&par[0],edp->popa[pi]->popsz,0,&ord[0]);
   for(ii=0;ii<nshowed;ii++) {
      gaft=edp->popa[pi]->guys[ord[ii]].gaft*100;
      shad=edp->popa[pi]->guys[ord[ii]].shad*100;
      mfit=edp->popa[pi]->guys[ord[ii]].mfit*100;
      if(pi==0)if(ii==0) shadbst=shad;
      strcpy(atmpstr,"\nBEST %3d) (%3d) gaft: %5.2f shad: %5.2f mfit: %5.2f ");
      fprintf(stdout,atmpstr,ii,ord[ii],gaft,shad,mfit);
      fprintf(fptr00,atmpstr,ii,ord[ii],gaft,shad,mfit);
   }
   // avg
   gaftavg[pi]=0; shadavg[pi]=0; mfitavg[pi]=0;
   for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
      gaftavg[pi]+=edp->popa[pi]->guys[gy].gaft;
      shadavg[pi]+=edp->popa[pi]->guys[gy].shad;
      mfitavg[pi]+=edp->popa[pi]->guys[gy].mfit;
   }
   gaftavg[pi]=gaftavg[pi]*100/POPXSZ;
   shadavg[pi]=shadavg[pi]*100/POPXSZ;
   mfitavg[pi]=mfitavg[pi]*100/POPXSZ;
   strcpy(atmpstr,"   AVG gaft: %5.2f shad: %5.2f mfit: %5.2f ");
   fprintf(stdout,atmpstr,gaftavg[pi],shadavg[pi],mfitavg[pi]);
   fprintf(fptr00,atmpstr,gaftavg[pi],shadavg[pi],mfitavg[pi]);
}

// History
if((edp->cn-1)%HSTSTP==0) {
   for(gi=0;gi<NNGUYS;gi++) {
      pi=gi/POPXSZ; gy=gi%POPXSZ;
      edp->shdhst[(edp->cn-1)/HSTSTP][gi]=edp->popa[pi]->guys[gy].shad;
      edp->fithst[(edp->cn-1)/HSTSTP][gi]=edp->popa[pi]->guys[gy].gaft;
   }
}

free(ord);
free(par);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Loadmemo(int thid) {
int  pi,gy,bi,ii,aiv,sr,gi; FILE *fp; float afv;
Exbd *edp=exbd[thid];

// HSTFN
fp=fopen(HSTXFN,"r"); if(fp!=NULL) {
   for(ii=0;ii<FITHST;ii++) {
      sr=fscanf(fp,"%d",&aiv);
      for(gi=0;gi<NNGUYS;gi++) sr=fscanf(fp,"%f",&edp->shdhst[ii][gi]);
   }
   for(ii=0;ii<FITHST;ii++) {
      sr=fscanf(fp,"%d",&aiv);
      for(gi=0;gi<NNGUYS;gi++) sr=fscanf(fp,"%f",&edp->fithst[ii][gi]);
   }
}
if(fp!=NULL) fclose(fp);

// Genome
fp=fopen(GENXFN,"r"); if(fp!=NULL) {
   sr=fscanf(fp,"\nCYCLE %d\n",&edp->cn0);
   // for(ii=0;ii<2;ii++) fgets(buf,200,fp);
   for(pi=0;pi<NPOPUL;pi++) {
      for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
         sr=fscanf(fp,"%d)",&aiv);
         sr=fscanf(fp,"%f", &afv); edp->popa[pi]->guys[gy].shad=afv;
         sr=fscanf(fp,"%f", &afv); edp->popa[pi]->guys[gy].gaft=afv;
         // metabolism operators
         for(bi=0;bi<(GHDRSZ+OXARSQ);bi++) {
            if((bi-GHDRSZ)%OXRXSQ==0)
               sr=fscanf(fp," \n(%d)",&aiv);
            sr=fscanf(fp,"%d",&aiv); edp->popa[pi]->guys[gy].gen[bi]=aiv;
         }
         // developmental genes
         for(bi=BEGNSQ;bi<GENXSZ;bi++) {
            if((bi-BEGNSQ)%DGENSQ==0) sr=fscanf(fp," \n[%d]",&aiv);
            if(GRNMODE==NO) {
               sr=fscanf(fp,"%d",&aiv); edp->popa[pi]->guys[gy].gen[bi]=aiv; }
            if(GRNMODE==YA) if((bi-BEGNSQ)%DGENSQ<SGENSQ) {
               sr=fscanf(fp,"%d",&aiv); edp->popa[pi]->guys[gy].gen[bi]=aiv; }
         }
      }
   }
}
if(fp!=NULL) fclose (fp);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Savememo(int thid) {
char  *filename,cn[10];
int   gi,pi,gy,vx,vy,vz,ii,bi,hi,ri,ci,ce,lht,fn,aiv,biv,civ,us;
float cval,tval,dstmax,qrda,qrdb,afv,bfv,cfv;
FILE  *fp; Dgx *dgx; Dgo *dgr;
Exbd  *edp=exbd[thid];

// HSTXFN
fp=fopen(HSTXFN,"w"); if(fp!=NULL) {
   for(ii=0;ii<FITHST;ii++) {
      fprintf(fp," %4d",ii);
      for(gi=0;gi<NNGUYS;gi++) fprintf(fp," %6.3f",edp->shdhst[ii][gi]);
      fprintf(fp,"\n");
   }
   for(ii=0;ii<FITHST;ii++) {
      fprintf(fp," %4d",ii);
      for(gi=0;gi<NNGUYS;gi++) fprintf(fp," %6.3f",edp->fithst[ii][gi]);
      fprintf(fp,"\n");
   }
}
if(fp!=NULL) fclose(fp);

#if(TAGCHK==YA)
// TAG2FN
fp=fopen(TAG2FN,"w"); if(fp!=NULL) {
   fprintf(fp," %4d]",-1);
   for(ri=0;ri<CLKMAX;ri++) fprintf(fp," %5d",ri);
   fprintf(fp," avg_se count\n");
   for(ri=0;ri<320;ri++) {
      fprintf(fp," %4d)",ri);
      for(ci=0;ci<CLKMAX;ci++) fprintf(fp," %5.2f",edp->taghst[ri][ci]);
      afv=edp->taghst[ri][CLKMAX+0];
      bfv=edp->taghst[ri][CLKMAX+1];
      if(bfv!=0) cfv=afv/bfv; else cfv=-1;
      fprintf(fp," %5.2f %5.2f\n",cfv,bfv);
   }
}
if(fp!=NULL) fclose(fp);

// TAG3FN
fp=fopen(TAG3FN,"w"); if(fp!=NULL) {
   fprintf(fp,"%6s%3s%5s%5s","   nr);","timer;","actgn;","cpies;");
   fprintf(fp,"\n");
   for(ii=0;ii<edp->hgnr;ii++) {
      fprintf(fp," %4d)",ii);
      fprintf(fp," %5d",edp->hstgenes[ii].dgx.timer);
      fprintf(fp," %5d",edp->hstgenes[ii].actgen);
      fprintf(fp," %5d",edp->hstgenes[ii].copies);
      for(hi=0;hi<CLKMAX;hi++) fprintf(fp," %5d",edp->hstgenes[ii].dgx.res[hi]);
      fprintf(fp,"\n");
   }
}
if(fp!=NULL) fclose(fp);
#endif

// FILE
lht = strlen(OUTDIRN)+25; filename = (char *)malloc(lht);
strcpy(filename,OUTDIRN); strcat(filename,"bxgen_");
if(edp->cn<100000) strcat(filename,"0");
sprintf(cn, "%d", edp->cn); strcat(filename,cn); strcat(filename,".txt");
aiv=0;
//for(ii=1;ii<=10;ii++) if(abs(edp->cn-1000*AMSGECOE*5*ii)<=SHOWPACE) aiv=1;
if((edp->cn-1)%25000==0) aiv=1;
if(aiv==0) fp=fopen(GENXFN,"w"); if(aiv==1) fp=fopen(filename,"w");
if(fp!=NULL) {
   fprintf(fp,"\nCYCLE %6d\n",edp->cn);
   for(pi=0;pi<NPOPUL;pi++) {
      for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
         fprintf(fp,"%4d) %9.6f %9.6f ",
            gy,edp->popa[pi]->guys[gy].shad,edp->popa[pi]->guys[gy].gaft);
         // metabolic operators
         for(bi=0;bi<(GHDRSZ+OXARSQ);bi++) {
            if((bi-GHDRSZ)%OXRXSQ==0)
               fprintf(fp," \n(%3d)",(bi-GHDRSZ)/OXRXSQ);
            fprintf(fp," %4d",(int)edp->popa[pi]->guys[gy].gen[bi]);
         }
         // dev. genes
         for(bi=BEGNSQ;bi<GENXSZ;bi++) {
            if((bi-BEGNSQ)%DGENSQ==0) fprintf(fp," \n[%3d]",(bi-BEGNSQ)/DGENSQ);
            if(GRNMODE==NO)
               fprintf(fp," %4d",(int)edp->popa[pi]->guys[gy].gen[bi]);
            if(GRNMODE==YA) if((bi-BEGNSQ)%DGENSQ<SGENSQ)
               fprintf(fp," %4d",(int)edp->popa[pi]->guys[gy].gen[bi]);
         }
         fprintf(fp," \n");
      }
   }
}
if(fp!=NULL) fclose(fp);
free(filename);

// FILE
for(ii=0;ii<2;ii++) {
   if(ii==0) fp=fopen(DGARFN,"w"); if(ii==1) fp=fopen(DHLSFN,"w");
   fprintf(fp,"%7s","nr) ;");
   if(ii==1) {
      fprintf(fp," xx xx xx ; xx ; ais ; act ;");
      fprintf(fp,"%7s%7s%7s%7s%7s","d0 ;","d1 ;","d2 ;","d3 ;","d4 ;");
      for(hi=0;hi<CLKMAX;hi++) fprintf(fp," hi%2d ;",hi); }
   if(ii==0) {
      fprintf(fp,"%8s%8s%8s%8s","arpos ;","swc ;","exord ;","ds ;");
      for(hi=0;hi<CLKMAX;hi++) fprintf(fp,"  hi%2d ;",hi);
      fprintf(fp,"%3s%3s","ms0 ;","ms1 ;");
      fprintf(fp,"%7s%7s%7s","[0]x ;","[0]y ;","[0]z ;");
      fprintf(fp,"%7s%7s%7s","[7]x ;","[7]y ;","[7]z ;");
      fprintf(fp,"%8s%8s%8s","tr0  ;","tr1  ;","tr2  ;");
      fprintf(fp,"%8s%8s%8s","tr3  ;","tr4  ;","tr5  ;");
      fprintf(fp,"%8s%8s%8s","tr6  ;","tr7  ;","tr8  ;");
      fprintf(fp,"%8s%8s","conr ;","c2nr ;"); }
   for(pi=0;pi<1;pi++) for(gy=0;gy<1;gy++) {
      gi=pi*POPXSZ+gy;
      fprintf(fp,"\n %4d ; %4d",pi,gy);
      edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);
      fprintf(fp,"\n stepeval: %d\n",edp->stepeval);
      for(ce=0;ce<edp->dgarsz;ce++)
         edp->par[ce]=(float)edp->dgar[ce].arpos/edp->dgarsz;
      Mysortxdgx(0,edp->par,edp->dgarsz,1,edp->dgar,edp->dgar);
      edp->dhnro=edp->dhnr0; edp->dharo=edp->dhar0;
      #if(MOCDEV==YA)
      edp->dhnro=edp->dhnral[gi]; edp->dharo=edp->dharal[gi];
      #endif
      if(ii==0) aiv=edp->dgarsz-1; if(ii==1) aiv=edp->dhnro;
      for(ce=0;ce<=aiv;ce++) {
         fprintf(fp,"\n%4d) ;",ce);
         // dummies, to keep aligned
         if(ii==1) {
            fprintf(fp,"%3d"  ,edp->dharo[ce].cd.x);
            fprintf(fp,"%3d"  ,edp->dharo[ce].cd.y);
            fprintf(fp,"%3d ;",edp->dharo[ce].cd.z);
            fprintf(fp,"%3d ;",edp->dharo[ce].clr);
            fprintf(fp,"%4d ;",edp->dharo[ce].lcrstp);
            fprintf(fp,"%4d ;",edp->dharo[ce].actstp);
            for(hi=0;hi<5;hi++) fprintf(fp," %4d ;",edp->dharo[ce].depend[hi]);
            for(hi=0;hi<CLKMAX;hi++) fprintf(fp," %4d ;",edp->dharo[ce].moc[hi]); }
         // dgx
         if(ii!=0) goto GLTEOC;
         dgx=&edp->dgar[ce]; dgr=&edp->dgar[ce].dgo;
         fprintf(fp," %5d ; %5d ;",dgx->arpos,dgx->swc);
         fprintf(fp," %5d ; %5d ;",dgx->exord,dgx->timer);
         for(hi=0;hi<CLKMAX;hi++) fprintf(fp," %5d ;",dgx->res[hi]);
         fprintf(fp," %2d ; %2d ;",dgr->ms0,dgr->ms1);
         for(hi=0;hi<=7;hi+=7) fprintf(fp," %4d ; %4d ; %4d ;",
            dgx->dgo.dpl[hi].x,
            dgx->dgo.dpl[hi].y,
            dgx->dgo.dpl[hi].z);
         for(hi=0;hi<9;hi++) fprintf(fp," %5.2f ;",dgx->dgo.tr[hi]);
         fprintf(fp," %5d ; %5d ;",dgx->dgo.conr,dgx->dgo.c2nr);
         GLTEOC:cvar=cvar;
      }
   }
   fclose(fp);
}

// Actual, as grid
#if(CFLAG7==1)
for(fn=0;fn<2;fn++) {
   ii=0;
   if(fn==0) fp=fopen(ETACFN,"w");
   if(fn==1) fp=fopen(CDACFN,"w");
   for(vz=0;vz<GRIDZ;vz++)for(vy=0;vy<GRIDY;vy++)for(vx=0;vx<GRIDX;vx++) {
      if(fn==0) aiv=edp->envr.ooacooodpagrid[CLKMAX-1][vx][vy][vz].d0;
      if(fn==1) aiv=edp->envr.ooacooodpagrid[CLKMAX-1][vx][vy][vz].e0;
      if((ii==0)||((ii+0)%(GRIDX)==0))
         fprintf(fp,"\n (vz:%3d vy:%3d vx:%3d)",vz,vy,vx);
      fprintf(fp," %2d",aiv); ii++;
   }
   fclose(fp);
}
#endif

// Actual, as grids
#if(CFLAG7==1)
for(ii=0;ii<2;ii++) {
   if(ii==0) fp=fopen(ASAD0FN,"w");
   if(ii==1) fp=fopen(ASAE0FN,"w");
   if(fp!=NULL) {
      for(hi=0;hi<CLKMAX;hi++) {
         if(hi==0) fprintf(fp,"\n");
         else      fprintf(fp,"\n\n");
         fprintf(fp,"%5d hi = %5d\n",-1,hi);
         fprintf(fp,"\n");
         for(vx=-1;vx<GRIDX;vx++) fprintf(fp,"%5d ",vx);
         for(vy=GRIDY-1;vy>=0;vy--) {
            fprintf(fp,"\n");
            fprintf(fp,"%5d ",vy);
            for(vx=0;vx<GRIDX;vx++) {
               if(ii==0) aiv=edp->envr.ooacooodpagrid[hi][vx][vy][0].d0;
               if(ii==1) aiv=edp->envr.ooacooodpagrid[hi][vx][vy][0].e0;
               fprintf(fp,"%5d ",aiv);
            }
         }
      }
   }
   if(fp!=NULL) fclose(fp);
}
#endif

#if(MNETON==YA)
int ei,ki,si,ox,ndrv,sj;
// writes to file 'substance concentrations'
ndrv=0;
fp=fopen(MNET0FN, "w");
fprintf(fp,"%7s","xxxx ;");
for(si=0;si<SZSUSP;si++) fprintf(fp," (%2d) ;",si);
fprintf(fp,"\n");
for(ei=0;ei<EXARSZ;ei++) {
   fprintf(fp,"ex=%d\n",ei);
   for(ki=0;ki<DHARLS;ki++) {
      if(edp->extsc0[ei][ki][0]!=-1) {
         ndrv=ki;
         fprintf(fp," %3d) ;",ki);
         fprintf(fp," %2.0f) ;",edp->lrordk[ki]);
         for(si=0;si<SZSUSP;si++)
            fprintf(fp," %1.2f ;",edp->extsc0[ei][ki][si]);
         fprintf(fp,"\n");
      }
   }
}
fclose(fp);
ndrv+=1;

// writes to file 'operators' activations'
fp=fopen(MNET1FN, "w");
fprintf(fp,"%7s","xxxx ;");
//fprintf(fpa,"%7s","xxxx ;");
for(ox=0;ox<OXARSZ;ox++) fprintf(fp,"<%2d>;",ox);
fprintf(fp,"\n");
for(ki=0;ki<DHARLS;ki++) if(edp->oxarp0[ki][0]!=-1) {
   fprintf(fp," %3d) ;",ki);
   //fprintf(fp," %3d) ;",edp->lrordk[ki]);
   for(ox=0;ox<OXARSZ;ox++)
      fprintf(fp," %2d ;",edp->oxarp0[ki][ox]);
   fprintf(fp,"\n");
}
fclose(fp);

// writes to file i/o comparison
fp=fopen(MNET2FN, "w");
fprintf(fp,"%7s","xxxx ;");
for(si=0;si<SZSUSP;si++) fprintf(fp," (%2d) ;",si);
fprintf(fp,"\n");
for(ei=0;ei<EXARSZ;ei++) {
   fprintf(fp,"ex=%d\n",ei);
   fprintf(fp,"i-tgt: ");
   for(si=0;si<SZSUSP;si++)
      fprintf(fp," %1.2f ;",edp->envr.mtv.iotar[0][ei][si]);
   fprintf(fp,"\n");
   fprintf(fp,"o-tgt: ");
   for(si=0;si<SZSUSP;si++)
      fprintf(fp," %1.2f ;",edp->envr.mtv.iotar[1][ei][si]);
   fprintf(fp,"\n");
   fprintf(fp,"o-act: ");
   for(si=0;si<SZSUSP;si++)
      fprintf(fp," %1.2f ;",edp->extsc0[ei][ndrv-1][si]);
   fprintf(fp,"\n");
}
fclose(fp);

// Graphical concentrations
#if(DEBUG0==YA)
hi=ASFITX; ei=3;
for(si=0;si<SZSUSP;si++) {
   FORVXYZ voxgrid[vx][vy][vz]=(double)edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0;
   FORVXYZ edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0=-1;
   for(ki=0;ki<DHARLS;ki++) if(edp->extsc0[ei][ki][si]!=-1) {
      vx=edp->dvcdk0[ki].x;
      vy=edp->dvcdk0[ki].y;
      vz=edp->dvcdk0[ki].z;
      edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0=(int)(edp->extsc0[ei][ki][si]*15);
   }
   FORVXYZ if (voxgrid[vx][vy][vz]!=-1) {
      for(ki=0;ki<DHARLS;ki++) dstar[ki]=1;
      dstmax=-1;
      for(ki=0;ki<DHARLS;ki++) if(edp->extsc0[ei][ki][si]!=-1) {
         dstar[ki]=(float)pow(
            pow(abs(vx-edp->dvcdk0[ki].x),(float)2)+
            pow(abs(vy-edp->dvcdk0[ki].y),(float)2)+
            pow(abs(vz-edp->dvcdk0[ki].z),(float)2),(float)0.5);
         if (dstmax<dstar[ki]) dstmax=dstar[ki];
      }
      for(ki=0;ki<DHARLS;ki++) if(edp->extsc0[ei][ki][si]!=-1) dstar[ki]/=dstmax;
      Mysortxxxx(dstar,ndrv,1,ordar);
      if (0==0) {
         tval=0;
         for(ii=0;ii<3;ii++)
            tval+=pow(1-dstar[ordar[ii]],2);
         cval=0;
         for(ii=0;ii<3;ii++)
            cval+=pow(1-dstar[ordar[ii]],2)/tval*(float)edp->extsc0[ei][ordar[ii]][si];
      }
      edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0=(int)(cval*15);
      // distance with all substances
      qrdb=0;
      for(sj=0;sj<SZSUSP;sj++) {
         qrda=0;
         for(ii=0;ii<3;ii++)
            qrda+=pow(1-dstar[ordar[ii]],2)/tval*(float)edp->extsc0[ei][ordar[ii]][sj];
         qrdb+=pow(qrda-edp->envr.mtv.iotar[1][ei][sj],2);
      }
      qrdb=pow(qrdb/8,(float)0.5);
      edp->envr.ooacooodpagrid[hi][vx][vy][vz].e0=(int)(qrdb*15);
   }

   lht = strlen(VTKFILE)+14;
   tmpfilename = (char *)malloc(lht);
   strcpy(tmpfilename,VTKFILE);
   if (hi<10) strcat(tmpfilename, "0");
   sprintf(str,"%d",hi); strcat(tmpfilename, str);
   strcat(tmpfilename, "_cnc");
   sprintf(str,"%d",si); strcat(tmpfilename, str);
   strcat(tmpfilename, ".vtk");
   Savevtk(thid,hi,tmpfilename);
   free(tmpfilename);
}
#endif

#endif

}

#define SPEC_SHAPE0 0
#define SPEC_SHAPE1 0
//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Savegrid(int thid,int opt,int hi) {
char  *filename,str[5];
int   vx,vy,vz,ii,aiv,biv,civ,lht,bb;
FILE  *fp;
Exbd  *edp=exbd[thid];

lht = strlen(GRDFILE)+14;
filename = (char *)malloc(lht);
strcpy(filename,GRDFILE);

if(opt==0) {
   sprintf(str,"%d",hi);
   if(hi <1000) strcat(filename,"0");
   if(hi  <100) strcat(filename,"0");
   if(hi   <10) strcat(filename,"0");
   strcat(filename, str);
   strcat(filename,".txt");
}

if(opt==1) {
   bb=edp->pnr;
   //bb=(edp->pnr/(NSTEPS)+1)*NSTEPS-edp->pnr%NSTEPS;
   //if(edp->pnr%NSTEPS==0) bb=edp->pnr;
   if(bb <1000) strcat(filename,"0");
   if(bb  <100) strcat(filename,"0");
   if(bb   <10) strcat(filename,"0");
   sprintf(str,"%d",bb);
   strcat(filename, str);
   strcat(filename,".txt");
   printf("\n%4d %4d",edp->pnr,bb);
   edp->pnr++;
}

fp=fopen(filename,"w");
fprintf(fp,"%3d %3d %3d\n",GRIDX,GRIDY,GRIDZ);
ii=0;
for(vz=0;vz<GRIDZ;vz++) for(vy=0;vy<GRIDY;vy++) for(vx=0;vx<GRIDX;vx++) {
   aiv=edp->envr.oocurdsgrid[vx][vy][vz].d0; 
   biv=edp->envr.oocurdsgrid[vx][vy][vz].e0;
   #if(VTKOPT==0)
   if (aiv==-1)    civ=-1; // empty cells
   if (aiv!=-1)    civ=+1; // normal cells +1
   if (aiv>=30000) civ=+2; // new normal cells +2
   if (aiv>=60000) civ=+3; // driver cells
   if (aiv==-2)    civ=+4; // new holes
   #endif
   #if(VTKOPT==1)
   civ=biv;
   if (biv>=15)    civ=14;
   if (aiv>=30000) civ=15; // new normal cells +2
   if (aiv>=60000) civ=14; // driver cells
   #endif
   #if(DEBUG7==YA)
   //if(vx==19) if(vy==87) if(vz==46) aiv=4;
   #endif
   if((ii==0)||((ii+0)%(GRIDX)==0))
      fprintf(fp,"\n (vz:%3d vy:%3d vx:%3d)",vz,vy,vx);
   fprintf(fp," %2d",civ); ii++;
}

if(fp!=NULL) fclose(fp);
free(filename);

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Prexline(int thid) {
int   gi,pi,gy,bi,bo,bx,ii,di,*gen,aiv,biv,val,found,aa,bb,tmry,add;
float afv;
Dgx   curdgx;
Exbd *edp=exbd[thid];

for(pi=0;pi<NPOPUL;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   gen=edp->popa[pi]->guys[gy].gen;

   #if(PGFREEZE==NO)
   // initialize stepeval
   if(edp->cn==0) {
      edp->stepeval=0; /*printf(" ekkor ");*/
      Cvint2base(&gen[3],&edp->stepeval,CLKMAX,4,&aiv);
   }
   #endif

   if(gi==0) goto GTLEOC;
   // cyc on dev genes
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);

   #if(PGFREEZE==NO)
   // mutation to stepeval
   afv=Rnd1(1001)/(float)1000;
   if (afv<=PLSTEVAL) { 
      bb=Rnd1(2); add=1*Intpower(-1,bb); }
   else add=0;
   edp->stepeval+=add;
   if(edp->stepeval<0) edp->stepeval=0;
   if(edp->stepeval>CLKMAX-1) edp->stepeval=CLKMAX-1;
   Cvint2base(&gen[3],&edp->stepeval,XTMRSQ,4,&aiv);
   #endif

   for(di=edp->dgarxf;di<edp->dgarsz;di++) {
      // xxxx
      memcpy(&curdgx,&edp->dgar[di],sizeof(Dgx));
      bo=BEGNSQ+(curdgx.arpos*DGENSQ); //bi=bx+bj
      #if(PGFREEZE==YA)
      // xxxx
      bx=1;
      found=0;
      // determines xq
      val=di;
      for(ii=-1;ii<NAMS-1;ii++) {
         if(ii==-1) { aa=0; bb=edp->frz[0].xe; }
         else { aa=edp->frz[ii].xe; bb=edp->frz[ii+1].xe; }
         if(((aa<=val)&&(val<bb))) { edp->xq=ii+1; break; }
      }
      val=curdgx.exord;
      if(!((aa<=val)&&(val<bb))) found=1;
      if(found==1) {
         if(edp->xq==0) { aa=0; bb=edp->frz[0].xe; }
         else {
            aa= edp->frz[edp->xq-1].xe;
            bb=(edp->frz[edp->xq]  .xe-edp->frz[edp->xq-1].xe); }
         curdgx.exord=aa+Rnd1(bb);
         #if(DEBUG0==YA)
         if((XORDSQ==4)&&(di>=255)) curdgx.exord=255;
         #endif
         //curdvx.exord=34;
         Cvint2base(&gen[(bo+bx)],&curdgx.exord,XORDSQ,4,&aiv);
      }
      #endif
      #if(PGFREEZE==YA)
      // Sets lower limit for curdgx.as (>=edp->frz[xq].ls)
      tmry=0;
      if(curdgx.timer<=edp->frz[edp->gq].fs) tmry=1;
      curdgx.timer=edp->frz[edp->xq].ls;
      #endif
      #if(EVFTEVAL==YA)
      tmry=1; if (PLGENETM==0) tmry=0;
      afv=Rnd1(1001)/(float)1000;
      if (afv<=PLGENETM) { bb=Rnd1(2); add=1*Intpower(-1,bb); }
      else add=0;
      curdgx.timer+=add;
      if(curdgx.timer<0) curdgx.timer=0;
      if(curdgx.timer>(CLKMAX-1)) curdgx.timer=(CLKMAX-1);
      #endif
      if(tmry==1) {
         Varrescale(&curdgx.timer,CLKMAX,(int)Intpower(4,XTMRSQ));
         bo=BEGNSQ+(curdgx.arpos*DGENSQ);
         bx=(1+XORDSQ); aiv=1;
         Cvint2base(&gen[(bo+bx)],&curdgx.timer,XTMRSQ,4,&aiv);
      }
   }
   GTLEOC:cvar=cvar;
   #if(DEBUG0==YA)
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);
   cvar=0;
   #endif
}

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Germline(int thid) {
int   gi,pi,gy,ii,di,hi,ordy,tmry,mocy,n0,n1,sva,svb,rnok,cnt,nr;
int   aiv,biv,val,aa,bb,cc,tmr,bo,bx,bj,*gen,add,lcrstp,pos;
Dgx   curdgx; Dse (*dharap)[DHARLS]; Sgen cursgn;
Exbd *edp=exbd[thid];

for(pi=0;pi<NPOPUL;pi++) for(gy=0;gy<edp->popa[pi]->popsz;gy++) {
   gi=pi*POPXSZ+gy;
   #if  (MOCDEV==NO)
   aiv=edp->dhnr0;
   dharap=edp->dharaz; pos=0;
   #elif(MOCDEV==YA)
   aiv=edp->dhnral[gi]; if(aiv==1) aiv=0; // ACHTUNG: ad-hoc!!!
   dharap=edp->dharal; pos=gi;
   #endif

   if(gi==0) goto GTLEOC;
   edp->popa[pi]->Gendecoder(0,edp->popa[pi]->guys[gy].gen,NULL,1);

   for(di=edp->dgarxf;di<edp->dgarsz;di++) {
      nr=0;
      memcpy(&curdgx,&edp->dgar[di],sizeof(Dgx));
      memcpy(&cursgn,&edp->sgar[di],sizeof(Sgen));
      // checks whether sequence matches any MOC in MOC array
      mocy=0; biv=NO;
      for(ii=0;ii<=aiv;ii++) {
         #if  (GRNMODE==NO)
         biv=Mocmatch(&curdgx.res[0],
            &dharap [pos][ii].moc[0],NAPMIN,FSCMAX,&sva,&svb);
         #elif(GRNMODE==YA)
         for(hi=0;hi<CLKMAX;hi++)
            if(cursgn.ifp==dharap[pos][ii].moc[hi]) biv=YA;
         #endif
         if (biv==YA) mocy=1;
      }
      if((mocy==0)&&(nr<=nr)) {
         // selects randomly existing moc
         rnok=NO; cnt=0;
         do {
            n0=Rnd1(aiv+1); if(n0>aiv) n0=aiv; cnt++;
            if(dharap[pos][n0].moc[0]!=-1) {
               rnok=YA; lcrstp=dharap[pos][n0].lcrstp;
               if(lcrstp>=edp->frz[edp->gq].us) rnok=NO;
            }
         }  while((rnok==NO)&&(cnt<50));
         #if(AUTOGP==YA)
         // semi-automatic
         if((edp->gq>=0)&&(edp->gq<=27)) { n0=edp->tcvltr[Rnd1(tptr)]; }
         #endif
         #if  (GRNMODE==NO)
         for(hi=0;hi<CLKMAX;hi++) curdgx.res[hi]=dharap[pos][n0].moc[hi];
         #elif(GRNMODE==YA)
         n1=Rnd1(CLKMAX); cursgn.ifp=dharap[pos][n0].moc[hi];
         #endif
      }
      gen=&edp->popa[pi]->guys[gy].gen[0];
      if((mocy==0)&&(nr<=nr)&&(rnok==YA)) {
         #if  (GRNMODE==NO)
         bo=BEGNSQ+(curdgx.arpos*DGENSQ); bx=0;
         // sets activation to off
         if(gy==0) gen[bo+bx]=0;
         // sets res
         bx=(1+XORDSQ+XTMRSQ+1); bj=0;
         for(hi=0;hi<CLKMAX;hi++)
            Cvint2base(&gen[(bo+bx+bj)],&curdgx.res[hi],XRESSQ,4,&bj);
         // sets masking bits to active
         bx=(1+XORDSQ+XTMRSQ+1)+(XRESSQ*CLKMAX);
         for(bj=0;bj<CLKMAX;bj++) gen[bo+bx+bj]=3;
         nr++;
         #elif(GRNMODE==YA)
         bo=BEGNSQ+(curdgx.arpos*DGENSQ); bx=0;
         // sets activation to off
         if(gy==0) gen[bo+bx]=0;
         // sets ifp
         bx=SGSCSQ; bj=0;
         Cvint2base(&gen[(bo+bx+bj)],&cursgn.ifp,SGIFSQ,4,&bj);
         nr++;
         #endif
      }
   }
   GTLEOC:cvar=cvar;
}

#if(DEBUG7==YA)
Gpstatsx(this);
#endif

}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
void Body::Moveclsr(int thid,Clsr *csd,Clsr *css) {
Exbd *edp=exbd[thid];
memcpy(csd,css,sizeof(Clsr));
#if(MNETON==YA)
csd->mclnr=css->mclnr;
#endif
memcpy(css,&edp->cs0,sizeof(Clsr));
#if(MNETON==YA)
css->mclnr=edp->cs0.mclnr;
#endif
}

//!--------------------------------------------------------------------------
//! FCT
//!--------------------------------------------------------------------------
void Body::Copyclsr(Clsr *csd,Clsr *css) {
memcpy(csd,css,sizeof(Clsr));
#if(MNETON==YA)
csd->mclnr=css->mclnr;
#endif
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
float Body::Mnetcalc(int thid,int gi) {
float mfit=0;
#if(MNETON==YA)
int   vx,vy,vz,ex,ey,ez,fx,fy,fz,lr,ivarp,ndrv,ki,kj,ox,ii,ei,si,pi,gy;
double dst,dste,dsto,dstmax,dstmin,ha,hb,hc,adv,bdv,cdv,ddv,edv,fdv,*ept,*ipt;
double coe,coe2,mfitex[EXARSZ];
Oxr   *curoxr;
Mcl   *mclvar;
Exbd  *edp=exbd[thid];

pi=gi/POPXSZ; gy=gi%POPXSZ;

// alloc drvdst
ivarp=edp->dhnr+1;
edp->drvdst=(double**)malloc(sizeof(double*)*ivarp);
for(ii=0;ii<ivarp;ii++) edp->drvdst[ii]=(double*)malloc(sizeof(double)*ivarp);

// Compiles drv array
ex=edp->envr.mtv.iopar[0][0].x;
ey=edp->envr.mtv.iopar[0][0].y;
ez=edp->envr.mtv.iopar[0][0].z;
fx=edp->envr.mtv.iopar[1][0].x;
fy=edp->envr.mtv.iopar[1][0].y;
fz=edp->envr.mtv.iopar[1][0].z;
dstmax=-8888;
dstmin=+8888;
ndrv=0;
#if(DEBUG0==YA)
if(gi==0)
   cvar=cvar;
#endif
FORVXYZ {
   if((Lreader(Lcnd,&edp->clar[vx][vy][vz])==CLALIVE)||
      (Lreader(Lcnd,&edp->clar[vx][vy][vz])==CLSLEEP))
   //if (edp->mtar[edp->clar[vx][vy][vz].mclnr].olrxxx!=-1)
   if (Lreader(Ldrv,&edp->clar[vx][vy][vz])==1) {
      edp->drvarh[ndrv]=&edp->clar[vx][vy][vz];
      dste=(double)(abs(vx-ex)+abs(vy-ey)+abs(vz-ez));
      dsto=(double)(abs(vx-fx)+abs(vy-fy)+abs(vz-fz));
      dst=dste-dsto;
      if(dst>dstmax) dstmax=dst;
      if(dst<dstmin) dstmin=dst;
      edp->lrordh[ndrv]=(float)dst;
      edp->drvcdh[ndrv].x=vx;
      edp->drvcdh[ndrv].y=vy;
      edp->drvcdh[ndrv].z=vz;
      ndrv++;
   }
}

// normalise
if(dstmin<0) {
   for(ki=0;ki<ndrv;ki++) edp->lrordh[ki]-=(float)dstmin;
   dstmax-=dstmin;
}
cvar=0;//anchor
if(dstmax>1)
   for(ki=0;ki<ndrv;ki++) edp->lrordh[ki]/=(float)dstmax;
// sorts
Mysortlrxx(thid,edp->lrordh,ndrv,1,edp->drvark,edp->drvarh);
for(ki=0;ki<ndrv;ki++) {
   memcpy(&edp->lrordk[ki],&edp->lrordh[edp->auxarr[ki]],sizeof(double));
   memcpy(&edp->drvcdk[ki],&edp->drvcdh[edp->auxarr[ki]],sizeof(Coord));
}

// calc dst
dstmax=-1;
for(ki=0;ki<ndrv;ki++) for(kj=0;kj<ndrv;kj++) {
   edp->drvdst[ki][kj]=(double)
      abs(edp->drvcdk[ki].x-edp->drvcdk[kj].x)+
      abs(edp->drvcdk[ki].y-edp->drvcdk[kj].y)+
      abs(edp->drvcdk[ki].z-edp->drvcdk[kj].z);
   if(dstmax<edp->drvdst[ki][kj])
      dstmax=edp->drvdst[ki][kj];
}
// normalise
if(dstmax>1) for(ki=0;ki<ndrv;ki++) for(kj=0;kj<ndrv;kj++)
   edp->drvdst[ki][kj]/=dstmax;

// xxxx
ha=0; hb=1; hc=(hb-ha)/2;
for(ki=0;ki<ndrv;ki++) {
   if((edp->lrordk[ki]>=(ha+hc*0))&&(edp->lrordk[ki]< (ha+hc*1))) edp->lrordk[ki]=1; else
   if((edp->lrordk[ki]>=(ha+hc*1))&&(edp->lrordk[ki]< (ha+hc*2))) edp->lrordk[ki]=2;
}
edp->lrordk[0]=0; edp->lrordk[ndrv-1]=3;

// xxxx
if(gi==0) {
   for(ei=0;ei<EXARSZ;ei++)
   for(ki=0;ki<DHARLS;ki++) for(si=0;si<SZSUSP;si++)
      edp->extsc0[ei][ki][si]=-1;
   for(ki=0;ki<DHARLS;ki++) for(ox=0;ox<OXARSZ;ox++)
      edp->oxarp0    [ki][ox]=-1;
}

mfit=0;
if(ndrv<2) goto EOFCTX;

// xxxx
edv=0;
for(ei=0;ei<EXARSZ;ei++) {
   // inits subst. arrays of all cells
   for(ki=0;ki<ndrv;ki++) {
      for(si=0;si<SZSUSP;si++) edp->intsbc[ki][si]=0;
      for(si=0;si<SZSUSP;si++) edp->extsbc[ki][si]=0;
   }
   // inits extsbc of input cell
   for(si=0;si<SZSUSP;si++) edp->extsbc[0][si]=edp->envr.mtv.iotar[0][ei][si];

   for(ki=0;ki<ndrv;ki++) {
      mclvar=&edp->mtar[edp->drvark[ki]->mclnr];
      // uploads clscnc from extcnc
      for(si=0;si<SZSUSP;si++) {
         coe=0;
         if(mclvar->iosmsk[0][si]==0) coe=(double)+0.00;
         if(mclvar->iosmsk[0][si]==1) coe=(double)+0.33;
         if(mclvar->iosmsk[0][si]==2) coe=(double)+0.66;
         if(mclvar->iosmsk[0][si]==3) coe=(double)+1.00;
         ipt=&edp->intsbc[ki][si]; *ipt += coe*edp->extsbc[ki][si];
         if(*ipt<0) *ipt=0;
         if(*ipt>1) *ipt=1;
      }
      // does calc within the cell
      for(lr=0;lr<3;lr++) for(ox=0;ox<OXARSZ;ox++) { // achtung: 3 layers!!
         curoxr=&edp->oxar[ox];
         if((mclvar->oxarap[ox]!=0)&&(curoxr->lrxx==lr)) {
            for(ii=0;ii<MAXIPS;ii++)
               curoxr->ival[ii]=edp->intsbc[ki][curoxr->isui[ii]];
            curoxr->oval=Forward(curoxr); // oval between -1 and +1
            ept=&edp->intsbc[ki][curoxr->osui]; *ept+=curoxr->oval;
            if(*ept<0) *ept=0;
            if(*ept>1) *ept=1;
         }
      }
      // downloads intsbc into extsbc, of ALL successive cells
      for(kj=ki;kj<ndrv;kj++) for(si=0;si<SZSUSP;si++) {
         coe=0;
         if(mclvar->iosmsk[1][si]==0) coe=(double)-1.00;
         if(mclvar->iosmsk[1][si]==1) coe=(double)-0.00;
         if(mclvar->iosmsk[1][si]==2) coe=(double)-0.00;
         if(mclvar->iosmsk[1][si]==3) coe=(double)+1.00;
         coe2=edp->drvdst[kj][ki];
         ept=&edp->extsbc[kj][si]; *ept+=coe*coe2*edp->intsbc[ki][si];
         if(*ept<0) *ept=0;
         if(*ept>1) *ept=1;
      }
      cvar=0;//anchor
   }
   // updates extsc0 and oxarp0
   if(gi==0) for(ki=0;ki<ndrv;ki++) {
      mclvar=&edp->mtar[edp->drvark[ki]->mclnr];
      for(si=0;si<SZSUSP;si++)
         edp->extsc0[ei][ki][si]=edp->extsbc[ki][si];
      for(ox=0;ox<OXARSZ;ox++)
         edp->oxarp0    [ki][ox]=mclvar->oxarap[ox];
   }
   ddv=0;
   for(si=0;si<SZSUSP;si++) {
      adv=edp->envr.mtv.iotar[1][ei][si];
      bdv=edp->extsbc[ndrv-1][si];
      cdv=pow((fabs(adv-bdv)),2);
      ddv+=cdv;
   }
   ddv=pow(ddv,0.5);
   ddv/=SZSUSP;
   edv+=ddv;
}
edv/=EXARSZ;
edv=pow(edv,1.15);
mfit=(float)(1-edv/0.1425);
if (mfit<0) mfit=0;

// frees memory
ivarp=edp->dhnr+1;
for(ii=0;ii<ivarp;ii++) free(edp->drvdst[ii]);
free(edp->drvdst);

EOFCTX: cvaro=cvaro;
#endif
return mfit;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
double Body::Forward(Oxr *oxr) {
int ii; double xx,yy;

xx=oxr->whts[MAXIPS];
for(ii=0;ii<MAXIPS;ii++) {
   //val0 = (((float)val / 100) - 0.5) *2;
   //a += memo.inar[nd].par0 * val0;
   xx+=oxr->whts[ii]*oxr->ival[ii];
}
yy=Sigmoid0((float)xx,2);
//res=Sigmoid1((int)(aa*100));

return yy;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Tagchck2(int thid) {
#if(TAGCHK==YA)
int   hi,pi,gy,presacta,presactb,ga,gb,gc,ca,cb,cc;
float *par=NULL,afv;
Exbd *edp=exbd[thid];

if ((edp->cn-1)%TAGPACE!=0) goto MARCOS;

for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*CLKMAX);cc++) { // only activated genes
   if (edp->frgenesc[gc][cc].timer!=-1) {
      presactb=0;
      for(gb=0;gb<NNGUYS;gb++) for(cb=0;cb<(DGEVXX*CLKMAX);cb++) {
         if (edp->frgenesc[gc][cc].timer==edp->frgenesb[gb][cb].timer)
         if (memcmp(
            &edp->frgenesc[gc][cc].res[0],
            &edp->frgenesb[gb][cb].res[0],sizeof(int)*CLKMAX)==0) {
            presactb=1; goto JONBBB;
         }
      }
      JONBBB:cvar=cvar;
      if (presactb==0) goto PESCOS;
      presacta=0;
      for(ga=0;ga<NNGUYS;ga++) for(ca=0;ca<(DGEVXX*CLKMAX);ca++) {
         if (edp->frgenesc[gc][cc].timer==edp->frgenesa[ga][ca].timer)
         if (memcmp(
            &edp->frgenesc[gc][cc].res[0],
            &edp->frgenesa[ga][ca].res[0],sizeof(int)*CLKMAX)==0) {
            presacta=1; goto JONAAA;
         }
      }
      JONAAA:cvar=cvar;
      if (presacta==1) goto PESCOS;
      // presacta=0 and presactb=1: accepted gene
      afv=1;
      pi=gc/POPXSZ; gy=gc%POPXSZ;
      //afv=edp->popa[pi]->guys[gy].gaft;
      edp->taghst[(edp->cn-1)/SHOWPACE][edp->frgenesc[gc][cc].timer]+=afv;
      edp->taghst[(edp->cn-1)/SHOWPACE][CLKMAX+0]+=(float)edp->frgenesc[gc][cc].stepeval;
      edp->taghst[(edp->cn-1)/SHOWPACE][CLKMAX+1]+=1;
      PESCOS:cvar=cvar;
   }
}

MARCOS:cvar=cvar;
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Tagchck3(int thid) {
#if(TAGCHK==YA)
int   pres,gc,cc,ii,si,ox,aiv;
float *par=NULL;
Dgx   *dgxp;
Exbd *edp=exbd[thid];

if ((edp->cn-1)%TAGPACE!=0) goto GTLYYY;

// assigns std values to var excluded from comparison
for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*CLKMAX);cc++) {
   dgxp=&edp->frgenesc[gc][cc];
   for(ii=0;ii<3;ii++) dgxp->dhnrx[ii]=-2;
   dgxp->arpos=-2;
   dgxp->exord=-2;
   dgxp->dhptx=-2;
   dgxp->napos=-2;
   dgxp-> fsc =-2;
   dgxp->exeas=-2;
   dgxp->dgo.ms1 =-2;
   dgxp->dgo.c2nr=-2;
   if((MNETON==NO)||(FITMIX==0.00)) {
      dgxp->dgo.olrxxx=-2;
      for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++) dgxp->dgo.iosmsk[ii][si]=-2;
      for(ox=0;ox<OXRCHD;ox++) dgxp->dgo.oxrchd[ox]=-2;
   }
}

// are old genes still present?
for(ii=0;ii<edp->hgnr;ii++) {
   edp->hstgenes[ii].copies=0;
   pres=0;
   for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*CLKMAX);cc++) {
      if (memcmp(&edp->frgenesc[gc][cc],&edp->hstgenes[ii].dgx,sizeof(Dgx))==0) {
         edp->hstgenes[ii].copies++; if (pres==0) edp->hstgenes[ii].actgen++;
         pres=1;
      }
   }
   if (pres==0) { // position is freed
      //memcpy(&edp->hstgenes[ii].dgx,&edp->dgx0,sizeof(Dgx));
      edp->hstgenes[ii].actgen=-1;
      edp->hstgenes[ii].copies=-1;
   }
}

// are there new genes?
for(gc=0;gc<NNGUYS;gc++) for(cc=0;cc<(DGEVXX*CLKMAX);cc++) {
   if (edp->frgenesc[gc][cc].res[0]==-1) goto GTLAAA;
   pres=0; aiv=-1;
   for(ii=0;ii<edp->hgnr;ii++) {
      if (edp->hstgenes[ii].actgen!=-1) // position occupied
      if (memcmp(&edp->frgenesc[gc][cc],&edp->hstgenes[ii].dgx,sizeof(Dgx))==0) {
         pres=1; break; // if pres is 1 aiv is not used anyway
      }
      if (edp->hstgenes[ii].actgen==-1) // position free
      if (aiv==-1) aiv=ii;              // assigns only once
   }
   if(pres==0) {
      if(aiv==-1) { aiv=edp->hgnr; edp->hgnr++; }
      memcpy(&edp->hstgenes[aiv].dgx,&edp->frgenesc[gc][cc],sizeof(Dgx));
      edp->hstgenes[aiv].actgen=0;
      edp->hstgenes[aiv].copies=0;
   }
   GTLAAA:cvar=cvar;
}

// sort
Ftsortxdgf(thid,par,edp->hgnr,1,edp->hstgenes);

GTLYYY:cvar=cvar;
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Grncalc(int thid) {
int   ii,hi,it,rn,sn,moc[CLKMAX],cdn,csn,vx,vy,vz,oiv;
double dgf[9],x0,y0,x1,y1,msf,conf,gasf,adv;
Dgo  *dgo;
Exbd *edp=exbd[thid];

for(ii=0;ii<DHARLS;ii++) if(edp->drvaro[ii].x!=-1) {
   vx=edp->drvaro[ii].x; vy=edp->drvaro[ii].y; vz=edp->drvaro[ii].z;
   oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
   memcpy(&moc[0],&edp->dhar[oiv].moc,sizeof(int)*CLKMAX);
   dgo=&edp->dhar[oiv].dgo;
   // xxxx
   for(sn=0;sn<DGARSZ;sn++) edp->sgar[sn].act=0;
   // gene activation as a result of MOC
   for(hi=0;hi<CLKMAX;hi++) {
      if(moc[hi]!=0) {
         for(sn=0;sn<DGARSZ;sn++) {
            if(edp->sgar[sn].ifp==moc[hi])
               edp->sgar[sn].act=1;
         }
      }
   }
   // gene activation as a result of other genes' products
   for(it=0;it<3;it++) {
      for(rn=0;rn<DGARSZ;rn++) {
         if(edp->sgar[rn].act==1) {
            for(sn=0;sn<DGARSZ;sn++) {
               if(edp->sgar[sn].ifp==edp->sgar[rn].thp)
                  edp->sgar[rn].act=2;
                  edp->sgar[sn].act=1;
            }
         }
      }
   }
   // tempor dgo assignment
   for(hi=0;hi<9;hi++) dgf[hi]=0;
   x0=0; y0=0;
   x1=0; y1=0;
   msf=0; conf=0; gasf=0;
   for(rn=0;rn<DGARSZ;rn++) {
      cdn=edp->sgar[rn].cdn; csn=edp->sgar[rn].csn;
      if(cdn==10) x0      +=(0.25)*csn;
      if(cdn==11) y0      +=(0.25)*csn;
      if(cdn==12) x1      +=(0.25)*csn;
      if(cdn==13) y1      +=(0.25)*csn;
      if(cdn==14) msf     +=(0.05)*csn;
      if(cdn==15) conf    +=(0.25)*csn;
      if(cdn==16) gasf    +=(0.25)*csn;
      if(cdn<= 9) dgf[cdn]+=(0.05)*csn;
   }
   // sanity check
   adv=(float)edp->frz[0].dl; // ACHTUNG!!!
   Sanchkdob(&x0,0,adv); Sanchkdob(&y0,0,adv);
   Sanchkdob(&x1,0,adv); Sanchkdob(&y1,0,adv);
   Sanchkdob(&msf,0,1);  Sanchkdob(&conf,0,15);
   Sanchkdob(&gasf,0,1);
   for(hi=0;hi<9;hi++) Sanchkdob(&dgf[hi],0,1);
   // final dgo assignment
   dgo->dpl[0].x=(int)x0; dgo->dpl[0].y=(int)y0;
   dgo->dpl[1].x=(int)x1; dgo->dpl[1].y=(int)y1;
   dgo->ms0=(int)msf; dgo->conr=(int)conf;
   dgo->gas=(int)gasf;
   for(hi=0;hi<9;hi++) dgo->tr[hi]=dgf[hi];
}

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Dsload(int thid) {
char   *filename,str[5];
int    pnr,ii,ri,ci,lht,aiv;
FILE   *fp;
Exbd *edp=exbd[thid];

for(ii=0;ii<2;ii++) {
   for(pnr=0;pnr<100;pnr++) {
      lht = strlen(ASMBFN)+10;
      filename = (char *)malloc(lht);
      //printf("\npnr=%d",pnr);
      if(ii==0) strcpy(filename,ASMBFN);
      if(ii==1) strcpy(filename,BSMBFN);
      if(pnr  <100) strcat(filename,"0");
      if(pnr   <10) strcat(filename,"0");
      sprintf(str,"%d",pnr);
      strcat(filename,str);
      strcat(filename,".txt");
      fp=fopen(filename,"r"); if(fp==NULL) goto GTLEOF;

      for(ri=0;ri<16;ri++) for(ci=0;ci<16;ci++) { 
         fscanf(fp,"%d",&aiv);
         edp->neuralds[ii][ri*16+ci]=aiv; 
      }   
      fclose(fp);
   }
}

GTLEOF:cvar=cvar;
}
