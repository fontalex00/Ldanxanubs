
#include "danxincl.h"

// Global var
extern Exbd *exbd[NCORES]; extern char cvar;

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Disrupt(int thid,int gi,int as) {
int  vx,vy,vz,ii,it,lcrmin,cut;
int  cllist[200],ptr,ptr0,ri,si,dep,pres,mother,cnd,asmin,aiv,biv,civ,oiv;
Coord cd;
Exbd  *edp=exbd[thid];

#if(CFLAG7==YA)
// insert drivers
int moc[CLKMAX];
if(as==0) {
   for(ii=0;ii<CLKMAX;ii++) moc[ii]=0; edp->smocnew=SMOCMA;
   cd.x=19; cd.y=67; cd.z=21;
   edp->moclp.dhnrc3=0; // should be -1, but unsigned short
   Dharupd (thid,gi,as,-1,YA,as,&moc[0], 0,&cd);
   Daughter(thid,gi,as,-1,YA,as,CLALIVN,-1,&cd);
   Dthrmnet(thid,gi,as,-1,YA,as,CLALIVN,-1,&cd);
   edp->clar[cd.x][cd.y][cd.z].col=7;
   edp->dhar[0].actstp=0;
   edp->dhar[0].dltcrt=0;
   edp->dhar[0].actdrv=1;
}
#endif

#if(CFLAG0==YA)
// random cut
if(as==REGFDS) {
   FORVXYZ {
      cnd=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
      cut=NO;
      if(vy>=250) cut=YA;              // tail
      if((vy<= 80)&&(vz>= 85)) cut=YA; // head
      if((vx<= 60)&&(vy>=180)) cut=YA; // posterior limb, right
      if((vx>=160)&&(vy>=180)) cut=YA; // posterior limb, left
      if(0.00*(vx-160)+0.50*(vy-100)+0.85*(vz-10)<=0) cut=YA; // anterior limbs
      if(cut==YA) if((cnd==CLALIVN)||(cnd==CLALIVE)) {
         biv=Lreader(Ldrv,&edp->clar[vx][vy][vz]);
         oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
         // updates drvaro
         if(biv==1) {
            edp->drvaro[oiv].x=-1;
            edp->cndaro[oiv]=CLNOCEL; }
         // updates drvaro_end
         mother= edp->clar[vx][vy][vz].mother;
         memcpy(&edp->clar[vx][vy][vz],&edp->cs0,sizeof(Clsr));
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,CLDESTR,-1);
         edp->clar[vx][vy][vz].mother=mother;
      }
   }
}
#endif

#if(CFLAG0==YA)
// remove debris
if(as==REGFDS+1) {
   ptr=0;
   FORVXYZ {
      if(Lreader(Lcnd,&edp->clar[vx][vy][vz])==CLDESTR) {
         mother=edp->clar[vx][vy][vz].mother;
         pres=NO;
         for(si=0;si<ptr;si++) if(mother==cllist[si]) pres=YA;
         if(pres==NO) cllist[ptr++]=mother;
      }
   }
   do {
      ptr0=ptr;
      for(ii=0;ii<ptr;ii++)
      for(ri=0;ri<edp->dhar[cllist[ii]].ndep;ri++) {
         dep=edp->dhar[cllist[ii]].depend[ri];
         pres=NO;
         for(si=0;si<ptr;si++) if(dep==cllist[si]) pres=YA;
         if(pres==NO) cllist[ptr++]=dep;
      }
   } while (ptr>ptr0);
   // calc asmin
   asmin=8888;
   for(ii=0;ii<ptr;ii++)
      if(asmin>edp->dhar[cllist[ii]].actstp)
         asmin=edp->dhar[cllist[ii]].actstp;
   // removal
   FORVXYZ {
      for(ii=0;ii<ptr;ii++) {
         if(edp->clar[vx][vy][vz].mother==cllist[ii]) {
            biv=Lreader(Ldrv,&edp->clar[vx][vy][vz]);
            oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
            // updates drvaro
            if(biv==1) {
               edp->drvaro[oiv].x=-1;
               edp->cndaro[oiv]=CLNOCEL; }
            // updates drvaro_end
            memcpy(&edp->clar[vx][vy][vz],&edp->cs0,sizeof(Clsr));
            Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,CLNOCEL,-1);
         }
      }
   }
   // reactivation
   lcrmin=8888;
   for(it=0;it<2;it++) {
      for(ii=0;ii<ptr;ii++) {
         FORVXYZ {
            //if(edp->dhar[edp->clar[vx][vy][vz].dhnrc3].actstp==asmin)
            if(edp->clar[vx][vy][vz].dhnrc3==cllist[ii]) { // it's mother, impacted
             //biv=Lreader(Ldrv,&edp->clar[vx][vy][vz]);
               civ=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
               oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
               if(civ==CLALIVE) {
                  aiv=edp->dhar[oiv].lcrstp;
                  if(it==0) if(aiv<lcrmin) lcrmin=aiv;
                  if(it==1) {
                     //edp->dhar[oiv].lcrstp=as;
                     edp->dhar[oiv].lcrstp+=(as-lcrmin);
                     edp->dhar[oiv].dltcrt+=(as-lcrmin);
                     edp->dhar[oiv].actdrv= 1;
                     edp->dhar[oiv].actstp=-1; // otherw. actstp < lcrstp+dltcrt !!!
                     edp->dhar[oiv].sigstp=-1; // otherw. sigstp < lcrstp+dltcrt !!!
                  }
               }
            }
         }
      }
   }
}
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Dgarprep(int thid,int gi,int as,int ss) {
int    vx,vy,vz,di,ii,ntypes,result,res1,nap,fsc,aiv,biv,oiv,cnd,dltmin,dltmax;
double adv; Coord cd;
Exbd   *edp=exbd[thid];

for(ii=0;ii<DHARLS;ii++) {
   if(edp->cndaro[ii]==CLCHOLN) edp->cndaro[ii]=CLCHOLE;
   if(edp->cndaro[ii]==CLALIVN) edp->cndaro[ii]=CLALIVE;
}
for(ii=0;ii<DHARLS;ii++) {
   memcpy(&edp->drvar1[ii],&edp->drvaro[ii],sizeof(Coord));
   memcpy(&edp->cndar1[ii],&edp->cndaro[ii],sizeof(int));
}

// Inits --------------------------------------------------------------------
for(di=0;di<edp->dgarsz;di++) memcpy(&edp->dgare[di],&edp->dgx0,sizeof(Dgx));
for(di=0;di<edp->dgarsz;di++) edp->scorar[di]=-1;
for(ii=0;ii<DHARLS;ii++) edp->auxarp[ii]=-1;
if(as==ss) for(ii=0;ii<DHARLS;ii++) {
   edp->drvaro[ii].x=-1;
   edp->drvaro[ii].y=-1;
   edp->drvaro[ii].z=-1;
}
if(as==ss) for(ii=0;ii<DHARLS;ii++) edp->cndaro[ii]=CLNOCEL;

oiv=1; //if((PGFREEZE==NO)&&(as>0)&&(edp->evtnr[as-1]==0)) oiv=0;
if (oiv==1)
FORVXYZ {
   if(edp->clar[vx][vy][vz].dhnrc3!=65535) {
      cnd=Lreader(Lcnd,&edp->clar[vx][vy][vz]);
      if(cnd==CLALIVN)
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,CLALIVE,-1);
      if(cnd==CLCHOLN)
         Lwriter(Lxxx,&edp->clar[vx][vy][vz],-1,-1,CLCHOLE,-1);
         //edp->clar[vx][vy][vz].dhnrc3=65535;
      if(as!=ss) goto GTLEOB;
      if((cnd==CLALIVN)||(cnd==CLALIVE))
      if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==1) {
         oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
         edp->drvaro[oiv].x=vx;
         edp->drvaro[oiv].y=vy;
         edp->drvaro[oiv].z=vz;
         edp->cndaro[oiv]=CLALIVE;
      }
      GTLEOB:cvar=cvar;
   }
}

// calc dltcrt
dltmin=8888; dltmax=0;
for(ii=0;ii<DHARLS;ii++) if(edp->drvaro[ii].x!=-1) {
   vx=edp->drvaro[ii].x;
   vy=edp->drvaro[ii].y;
   vz=edp->drvaro[ii].z;
   oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
   if(dltmax < edp->dhar[oiv].dltcrt)
      dltmax = edp->dhar[oiv].dltcrt;
   if(dltmin > edp->dhar[oiv].dltcrt)
      dltmin = edp->dhar[oiv].dltcrt;
}

// Sorts by exord
adv=(float)Intpower(4,XORDSQ)-1;
for(di=0;di<edp->dgarsz;di++)
   edp->par[di]=(float)edp->dgar[di].exord/(float)adv;
Mysortxdgx(thid,edp->par,edp->dgarsz,1,edp->dgare,edp->dgar);
edp->dgarsze=edp->dgarsz;

// eliminates inactive, undue & "colour" genes
memcpy(&edp->dgaro[0],&edp->dgare[0],sizeof(Dgx)*edp->dgarsz);
edp->dgarszo=edp->dgarsze; edp->dgarsze=0;
aiv=edp->frz[edp->gq].fs;
for(di=0;di<edp->dgarszo;di++) {
   biv=as-edp->dgaro[di].timer;
   if((edp->dgaro[di].swc!=-1)&&(edp->dgaro[di].swc!=0))
   if((edp->dgaro[di].timer==-1)||((biv>=dltmin)&&(biv<=dltmax)))
   if((as-edp->frz[edp->xqar[edp->dgaro[di].arpos]].us<=dltmax)||(as>aiv))
   if((edp->dgaro[di].dgo.ms0>=0)&&(edp->dgaro[di].dgo.ms0<=MS0MAX))
      memcpy(&edp->dgare[edp->dgarsze++],&edp->dgaro[di],sizeof(Dgx));
}

// dgar for colouring
for(di=0;di<edp->dgarsze;di++)
   memcpy(&edp->dgarr[di],&edp->dgare[di],sizeof(Dgx));
edp->dgarszr=edp->dgarsze;

cvar=cvar;//anchor
ntypes=0;
for(ii=0;ii<DHARLS;ii++) if(edp->drvaro[ii].x>=0) edp->auxarp[ntypes++]=ii;
cvar=cvar;//anchor

#if(DEBUG0==YA)
for(ii=0;ii<DHARLS;ii++) {
   if(as!=ss) if((edp->drvar1[ii].x!=-1)||(edp->drvaro[ii].x!=-1))
   if((edp->drvar1[ii].x!=edp->drvaro[ii].x)||
      (edp->drvar1[ii].y!=edp->drvaro[ii].y)||
      (edp->drvar1[ii].z!=edp->drvaro[ii].z))    printf("cxxxo");
   if(as!=ss) if(edp->cndar1[ii]!=edp->cndaro[ii]) printf("cxxx1");
}
#endif

//$ implements logics: genes with stronger match with any moc take precedence
for(di=0;di<edp->dgarsze;di++) {
   edp->dgare[di].dhptx=0; edp->scorar[di]=0;
   //sorts out moc for which gene has stronger match & puts score in scar[di]
   for(ii=0;ii<ntypes;ii++) {
      result=Mocmatch(&edp->dgare[di].res[0],&edp->dhar[edp->auxarp[ii]].moc[0],
         NAPMIN,FSCMAX,&nap,&fsc);
      if(result==YA) {
         // if it finds better-matching moc for gene, records the moc's dhnrx
         if((float)(nap-fsc)>edp->scorar[di]) edp->scorar[di]=(float)(nap-fsc);
         edp->dgare[di].dhnrx[edp->dgare[di].dhptx]=edp->auxarp[ii];
         edp->dgare[di].dhptx++;
      }
   }
}

memcpy(&edp->dgaro[0],&edp->dgare[0],sizeof(Dgx)*edp->dgarsz);
edp->dgarszo=edp->dgarsze;
// normalise (useless when ETONE==YA)
for(di=0;di<edp->dgarsze;di++) edp->scorar[di]/=CLKMAX;
for(di=0;di<edp->dgarsze;di++) edp->scord [di]=di;
Mysortxxxx(&edp->scorar[0],edp->dgarsze,0,&edp->scord[0]);
edp->dgarsze=0;
for(di=0;di<edp->dgarszo;di++) if(edp->scorar[edp->scord[di]]>0)
   memcpy(&edp->dgare[edp->dgarsze++],&edp->dgaro[edp->scord[di]],sizeof(Dgx));
//$ implements logic_end ----------------------------------------------------

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Shaper(int thid,int gi,int as,int us) {
char  str[20];
int   vx,vy,vz,di,evtnr,matched,ri,si,ii,oiv,zi,aiv,biv,civ,pres;
double hex,hey,hez,max,min,coe; Dgo *dgo;
Coord *dpla; Clsr curcl;
dimensc *dd,*ee,*ff;
Exbd  *edp=exbd[thid];

strcpy(str,"ahi ahi restore");

#if(ZSTEPS==YA)
if(gi==0) if(thid==0) {
   dd = new dimensc[GRIDX]; edp->bstepsgrid=dd;
   ee = new dimensc[GRIDX]; edp->estepsgrid=ee;
   ff = new dimensc[GRIDX]; edp->xstepsgrid=ff;
}

if(gi==0) if(thid==0) {
   Gridupd(thid,gi,as,us,0);
   FORVXYZ {
      edp->bstepsgrid[vx][vy][vz].d0=edp->envr.oocurdsgrid[vx][vy][vz].d0;
      edp->bstepsgrid[vx][vy][vz].e0=edp->envr.oocurdsgrid[vx][vy][vz].e0;
   }
}
#endif

edp->cgok=1; evtnr=0; // change event nr

// the limit evtnr<DGEVXX is put here because some x could be discarded
// because ko
for(di=0;((di<edp->dgarsze)&&(evtnr<DGEVXX));di++)
//for(zi=0;(zi<edp->dgare[di].dhptx);zi++) {
for(zi=0;zi<1;zi++) {
   if(edp->dgare[di].dgo.ms0==0) goto GTLXXX;
   //edp->cgok=1;
   matched=NO;
   // scans the grid
   for(ri=0;ri<DHARLS;ri++) {
      if(edp->drvaro[ri].x==-1) goto GPTEOB;
      memset(&curcl,0,sizeof(Clsr));
      //memcpy(&curcl,&edp->clar[vx][vy][vz],sizeof(Clsr));
      Lwriter(Lxxx,&curcl,ri,+1,edp->cndaro[ri],-1);
      vx=edp->drvaro[ri].x;
      vy=edp->drvaro[ri].y;
      vz=edp->drvaro[ri].z;
      if(NDIMS==2) if(vz!=0) printf(" z error");
      #if(GRNMODE==NO)
      if((Lreader(Lcnd,&curcl)!=CLALIVE)||
         (Lreader(Ldrv,&curcl)!=1)) goto GPTEOB;
      if((edp->cgok!=1)||(evtnr>evtnr)) goto GPTEOB;
      //  ACHTUNG: with Matchet it can match more cells,with dhnrx JUST ONE!!
      //if(((Matchet(&edp->dgare[di].res[0],&moc[0],
      //  NAPMIN,FSCMAX,&sva,&svb)==NO)))
      // goto EOBCL;
      oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
      aiv=edp->dhar[oiv].dltcrt;
      if (edp->dhar[oiv].actdrv!=1) goto GPTEOB;
      if (edp->dgare[di].dhnrx[zi]!=Lreader(Ldhn,&curcl)) goto GPTEOB;
      if((edp->dgare[di].timer!=-1)&&
         (edp->dgare[di].timer!=as-aiv)) goto GPTEOB;
      if((edp->dgare[di].dvfrd==0)&&(as>=REGFDS)) goto GPTEOB;
      edp->clok=1; matched=YA;
      #endif

      #if(GRNMODE==NO)
      dgo=&edp->dgare[di].dgo;
      #endif
      #if(GRNMODE==YA)
      dgo=&edp->dhar [ri].dgo;
      if(edp->dhar[ri].dgo.gas==0) goto GPTEOB;
      #endif

      // Calc geometry
      // coordinates are relative ((vx,vy) is in (0,0)),
      // movement of pts makes a "z"
      //dpla=&dgo->dpl[0];
      //Setedges(&dpla[0],&dpla[1],&edp->dpl[0]);
      memcpy(&edp->actdgr.dpl[0],&dgo->dpl[0],sizeof(Coord)*8);
      // compiles ellissoid parameters
      hex=(double)abs((edp->actdgr.dpl[7].x-edp->actdgr.dpl[0].x))/2;
      hey=(double)abs((edp->actdgr.dpl[7].y-edp->actdgr.dpl[0].y))/2;
      hez=(double)abs((edp->actdgr.dpl[7].z-edp->actdgr.dpl[0].z))/2;
      // max,min
      max=(hex>=hey) ? hex : hey; max=(max>=hez) ? max : hez;
      min=(hex<=hey) ? hex : hey; min=(min<=hez) ? min : hez;
      coe=(min/max);
      // compiles transformation matrix
      //for(ii=0;ii<9;ii++) edp->tr[ii]=(((double)dgo->dgz[ii]/63)-0.5)*2;
      for(ii=0;ii<9;ii++) edp->actdgr.tr[ii]=dgo->tr[ii];
      //edp->tr[0]=1; edp->tr[4]=1; edp->tr[8]=1;
      /*th=((double)edp->dgare[di].dgo.dgd[0]/63)*2*3.14159;
      ph=((double)edp->dgare[di].dgo.dgd[1]/63)*2*3.14159;
      ps=((double)edp->dgare[di].dgo.dgd[2]/63)*2*3.14159;
      edp->tr[0]=+cos(th)*cos(ps);
      edp->tr[1]=-cos(ph)*sin(ps) +sin(ph)*sin(th)*cos(ps);
      edp->tr[2]=+sin(ph)*sin(ps) +cos(ph)*sin(th)*cos(ps);
      edp->tr[3]=+cos(th)*sin(ps);
      edp->tr[4]=+cos(ph)*cos(ps) +sin(ph)*sin(th)*sin(ps);
      edp->tr[5]=-sin(ph)*cos(ps) +cos(ph)*sin(th)*sin(ps);
      edp->tr[6]=-sin(th);
      edp->tr[7]=+sin(ph)*cos(th);
      edp->tr[8]=+cos(ph)*cos(th);*/
      #if(SPHERE==1)
      edp->tr[0]=1; edp->tr[1]=0; edp->tr[2]=0; // no rot
      edp->tr[3]=0; edp->tr[4]=1; edp->tr[5]=0; // no rot
      edp->tr[6]=0; edp->tr[7]=0; edp->tr[8]=1; // no rot
      #endif
      // calc for remred
      //ax=vx+(int)(edp->rt[0]*bx+edp->rt[1]*by+edp->rt[2]*bz);
      //ay=vy+(int)(edp->rt[3]*bx+edp->rt[4]*by+edp->rt[5]*bz);
      //az=vz+(int)(edp->rt[6]*bx+edp->rt[7]*by+edp->rt[8]*bz);

      // Checks coordinates?

      //$ clok check --------------------------------------------------------
      if(edp->clok==0) goto GPTEOB;
      // ex geometric calcul ------------------------------------------------
      // New moc's are numbered consecutively following a 'z'

      // Copies mother into tmp var
      memcpy(&edp->moclp,&edp->clar[vx][vy][vz],sizeof(Clsr));
      #if(MNETON==YA)
      aiv=edp->clar[vx][vy][vz].mclnr;
      memcpy(&edp->momcl,&edp->mtar[aiv],sizeof(Mcl));
      #endif

      #if(CFLAG0==YA)
      biv=Lreader(Ldhn,&edp->moclp);
      edp->dhar[biv].actstp=as;
      edp->dhar[biv].sigstp=as;
      aiv=edp->moclp.mother;
      if(aiv!=-1) {
         pres=NO;
         for(ii=0;ii<edp->dhar[aiv].ndep;ii++)
            if (biv==edp->dhar[aiv].depend[ii]) pres=YA;
         if(pres==NO) {
            edp->dhar[aiv].depend[edp->dhar[aiv].ndep++]=biv;
            if(edp->dhar[aiv].ndep>=50) Leavexec("\ndepend overflow\n");
         }
      }
      #endif

      if(edp->dgare[di].dgo.ms0==1) Remred(thid,gi,as,di,vx,vy,vz,0);
      Brush(thid,gi,as,di,vx,vy,vz);
      Clset(thid,gi,as,di,vx,vy,vz);
      evtnr++;
      if(edp->dgare[di].dgo.ms0==1) Remred(thid,gi,as,di,vx,vy,vz,1);
      // deactivates mother
      edp->dhar[oiv].actdrv=0;

      #if(CFLAG0==YA)
      // mothers of apoptosis events aren't put back
      if(NOCANC==0) if(edp->dgare[di].dgo.ms0==2) goto GTLPBM; 
      #endif

      // Puts back mother
      memcpy(&edp->clar[vx][vy][vz],&edp->moclp,sizeof(Clsr));
      #if(MNETON==YA)
      memcpy(&edp->mtar[aiv],&edp->momcl,sizeof(Mcl));
      #endif
      // updates array of drivers (it could have been deleted during the event)
      oiv=Lreader(Ldhn,&edp->clar[vx][vy][vz]);
      edp->drvaro[oiv].x=vx;
      edp->cndaro[oiv]=CLALIVE;
      // Puts back mother_end
      GTLPBM:cvar=cvar;

      // updates dvfrd
      edp->dgar[edp->dgare[di].arpos].dvfrd=1;
      #if(TAGCHK==YA)
      // updates frgenesc
      if(as<=edp->stepeval) {
         memcpy(&edp->frgenesc[gi][(DGEVXX*as)+evtnr-1],&edp->dgare[di],sizeof(Dgx));
         edp->frgenesc[gi][(DGEVXX*as)+evtnr-1].exeas=as;
         edp->frgenesc[gi][(DGEVXX*as)+evtnr-1].stepeval=edp->stepeval;
      }
      #endif
      GPTEOB:cvar=cvar;
   }
   //$ edp->dgare[di] processing_end ----------------------------------------
   if(GRNMODE==YA) goto GTLARF; // does cycle on drivers just once
   cvar=cvar;//anchor
   // Movie steps
   GTLXXX:cvar=cvar;
}

GTLARF:cvar=cvar;

Movie(thid,gi,as,us,evtnr);

// influences on cells after creation (colouring)
/*for(di=0;(di<edp->dgarszr);di++) {
   if(edp->dgarr[di].dgo.ms0==0) {
      int cnt=0;
      FORVXYZ {
         if(edp->clar[vx][vy][vz].dhnrc2!=-1)
         if(Lreader(Ldhn,&edp->clar[ax][ay][az])==edp->dgare[di].dhnrx) {
       //if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==0) {
            Lwriter(Lxxx,&edp->clar[ax][ay][az],-1,-1,-1,
               edp->dgare[di].dgo.conr);
            cnt++;
         }
      }
      if(cnt>0) cgevnr++;
   }
}
*/

#if(MNETON==YA)
// influences on cells after creation (metabol. only)
/*for(di=0;(di<edp->dgarszr);di++) {
   if(edp->dgarr[di].dgo.ms0==0) {
      FORVXYZ {
         if (edp->clar[vx][vy][vz].dhnrc2!=-1) {          // Achtung dhnrx[0]
            if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==0) // non driver!!!
            if(Lreader(Ldhn,&edp->clar[vx][vy][vz])==edp->dgarr[di].dhnrx[0]){
               for(mz=vz-1;mz<=vz+1;mz++)
               for(mx=vx-1;mx<=vx+1;mx++)
               for(my=vy-1;my<=vy+1;my++) {
                  if(Lreader(Ldrv,&edp->clar[vx][vy][vz])==1) {
                     Dthrmnet(thid,cve,gi,di,mx,my,mz,0,-1,-1,-1);
                  }
               }
            }
         }
      }
   }
}*/
#endif

edp->evtnr[as]=evtnr;
if(gi==0) 
   if(thid==0) edp->evtnr0[as]=evtnr;

#if(DEBUG0==YA)
if(edp->cgok!=1) {
   printf(" gi: %d dhnr: %d",gi,edp->dhnr); Leavexec(str); }
#endif

#if(ZSTEPS==YA)
if(gi==0) if(thid==0) {
   delete dd;
   delete ee;
   delete ff;
}
#endif

cvar=cvar;//anchor for debugger
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Movie(int thid,int gi,int as,int us,int cgevnr) {
#if(ZSTEPS==YA)
int   act,nbs,vx,vy,vz,qx,qy,qz,xiv,yiv,ziv,pi,qi,tmp,cc,aiv,biv;
long  zpts,zptstot,zptsres,cfound,cfoundmax;
double zprob,rprob,adv;
char  cvar=0;
Exbd  *edp=exbd[thid];

if((gi!=0)||(thid!=0)) goto GTLZZZ;

Gridupd(thid,gi,as,us,0);
FORVXYZ {
   edp->estepsgrid[vx][vy][vz].d0=edp->envr.oocurdsgrid[vx][vy][vz].d0;
   edp->estepsgrid[vx][vy][vz].e0=edp->envr.oocurdsgrid[vx][vy][vz].e0;
}

//Calcolo different points
for(pi=0;pi<DVPTSMAX;pi++) edp->divpar[pi]=0;
zptstot=0;
FORVXYZ {
   act=NO;
   #if  (VTKOPT==0)
   aiv=edp->estepsgrid[vx][vy][vz].d0;
   biv=edp->bstepsgrid[vx][vy][vz].d0;
   if (aiv!=biv)
    { act=YA;
      if((aiv==-1)&&(biv!=-1)) edp->divpar[zptstot]=1;   // first absent, last present
      if((aiv!=-1)&&(biv==-1)) edp->divpar[zptstot]=2; } // first present, last absent
   #elif(VTKOPT==1)
   aiv=edp->estepsgrid[vx][vy][vz].e0;
   biv=edp->bstepsgrid[vx][vy][vz].e0;
   if (aiv!=biv)
    { act=YA;
      if((aiv==-1)&&(biv!=-1)) edp->divpar[zptstot]=1;   // first absent, last present
      if((aiv!=-1)&&(biv==-1)) edp->divpar[zptstot]=2;   // first present, last absent
      if((aiv!=-1)&&(biv!=-1)) edp->divpar[zptstot]=3; } // both present, diff colours
   #endif
   if(act==YA) {
      edp->divpts[zptstot].x=vx;
      edp->divpts[zptstot].y=vy;
      edp->divpts[zptstot].z=vz;
      zptstot++;
   }
}
zpts=zptstot/NSTEPS;

FORVXYZ {
   edp->xstepsgrid[vx][vy][vz].d0 =edp->bstepsgrid[vx][vy][vz].d0;
   edp->xstepsgrid[vx][vy][vz].e0 =edp->bstepsgrid[vx][vy][vz].e0;
}

if(zptstot>0)
for(qi=0;qi<(NSTEPS-1);qi++) {
   // calc probs
   cfoundmax=0;
   for(pi=0;pi<zptstot;pi++) if(edp->divpar[pi]!=-1) {
      cfound=0; nbs=1;
      vx=edp->divpts[pi].x;
      vy=edp->divpts[pi].y;
      vz=edp->divpts[pi].z;
      for(qz=vz-nbs;qz<=vz+nbs;qz++)
      for(qx=vx-nbs;qx<=vx+nbs;qx++)
      for(qy=vy-nbs;qy<=vy+nbs;qy++)
         if(qx>=0)if(qx<GRIDX)if(qy>=0)if(qy<GRIDY)if(qz>=0)if(qz<GRIDZ)
         if(edp->xstepsgrid[qx][qy][qz].e0!=-1) cfound++;
      if(cfound>cfoundmax) cfoundmax=cfound;
   }

   zptsres=zpts; pi=0; cc=0;
   while((zptsres>=0)&&(cc<100)) {
      if(edp->divpar[pi]!=-1) {
         cfound=0; nbs=1;
         vx=edp->divpts[pi].x;
         vy=edp->divpts[pi].y;
         vz=edp->divpts[pi].z;
         for(qz=vz-nbs;qz<=vz+nbs;qz++)
         for(qx=vx-nbs;qx<=vx+nbs;qx++)
         for(qy=vy-nbs;qy<=vy+nbs;qy++)
            if(qx>=0)if(qx<GRIDX)if(qy>=0)if(qy<GRIDY)if(qz>=0)if(qz<GRIDZ)
            if(edp->xstepsgrid[qx][qy][qz].e0!=-1) cfound++;
         adv=cfound/(double)cfoundmax;
         if(edp->divpar[pi]==1) zprob=0+adv; // if full,  dense volume is privileged
         if(edp->divpar[pi]==2) zprob=1-adv; // if hole, sparse volume is privileged
         if(edp->divpar[pi]==3) zprob=0+adv; // if none,  dense volume is privileged
         rprob=Rnd1(100)/(double)100;
         if(rprob<zprob) {
            xiv=edp->divpts[pi].x;
            yiv=edp->divpts[pi].y;
            ziv=edp->divpts[pi].z;
            edp->xstepsgrid[xiv][yiv][ziv].d0 =
            edp->estepsgrid[xiv][yiv][ziv].d0;
            edp->xstepsgrid[xiv][yiv][ziv].e0 =
            edp->estepsgrid[xiv][yiv][ziv].e0;
            edp->divpar[pi]=-1;
            zptsres--;
            //printf("%d ",zptsres);
         }
      }
      pi++; if(pi>=zptstot) { pi=0; cc++; }
   }

   FORVXYZ {
      edp->envr.oocurdsgrid[vx][vy][vz].d0=edp->xstepsgrid[vx][vy][vz].d0;
      edp->envr.oocurdsgrid[vx][vy][vz].e0=edp->xstepsgrid[vx][vy][vz].e0;
   }
   Savegrid(thid,1,as);
}

// End-of-step snapshot
Gridupd(thid,gi,as,us,0);
Savegrid(thid,1,as);
if(as==(CLKMAX-1)) exit(0);

GTLZZZ: cvar=cvar;
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Body::Brush(int thid,int gi,int as,int di,int vx,int vy,int vz) {
int   bx,by,bz,dx,dy,dz,kx,ky,kz,aiv,oiv,dltcrt,a,b;
double hex,hey,hez,fvx,fvy,fvz; Dgo *dgo;
Exbd  *edp=exbd[thid];

oiv=Lreader(Ldhn,&edp->moclp);
dltcrt=edp->dhar[oiv].dltcrt;

#if(GRNMODE==NO)
dgo=&edp->dgare[di].dgo;
#endif
#if(GRNMODE==YA)
dgo=&edp->dhar[oiv].dgo;
#endif

#if  (DOPNEW==NO)
aiv=1;
#elif(DOPNEW==YA)
if(as-dltcrt==1) aiv=1; else aiv=0;
#endif

// ellissoid: semi-axes, centre and displacement
hex=(double)abs((edp->actdgr.dpl[7].x-edp->actdgr.dpl[0].x))/2;
hey=(double)abs((edp->actdgr.dpl[7].y-edp->actdgr.dpl[0].y))/2;
hez=(double)abs((edp->actdgr.dpl[7].z-edp->actdgr.dpl[0].z))/2;
kx=2*DPLMAX/2; dx=(int)hex+edp->actdgr.dpl[0].x;
ky=2*DPLMAX/2; dy=(int)hey+edp->actdgr.dpl[7].y;
kz=2*DPLMAX/2; dz=(int)hez+edp->actdgr.dpl[0].z;
// xxxx
fvx=1; //fvx=(1.00+(0.33*(double)edp->dgare[di].dgo.dgd[7]/63));
fvy=1; //fvy=(1.00+(0.33*(double)edp->dgare[di].dgo.dgd[7]/63));
fvz=1; //fvz=(1.00+(0.33*(double)edp->dgare[di].dgo.dgd[7]/63));

// for speed
if(NDIMS==2) { a=-1; b=-1; hez=1; kz=0; dz=0; }
if(NDIMS==3) { a=+1; b=+1; }

// xxxx
for(bz=(kz-(int)hez-a);bz<=(kz+(int)hez+b);bz++)
for(by=(ky-(int)hey-1);by<=(ky+(int)hey+1);by++)
for(bx=(kx-(int)hex-1);bx<=(kx+(int)hex+1);bx++) {
   edp->buf0[bx][by][bz]=6; // no signal
   // ellissoid
   if((pow((bx-kx)/(hex*fvx),2)+
       pow((by-ky)/(hey*fvy),2)+
       pow((bz-kz)/(hez*fvz),2))<=1) {
      if((dgo->ms0==1)||(dgo->ms0==3))
         edp->buf0[bx][by][bz]=7; // normal signal
      if( dgo->ms0==2)
         edp->buf0[bx][by][bz]=8; // delete signal
      if((dgo->ms0==1)||(dgo->ms0==3)) if(aiv==1)
      if((bx%N2DRAT==0)&&(by%N2DRAT==0)&&(bz%N2DRAT==0))
         edp->buf0[bx][by][bz]=9; // driver signal
      cvar=0;
   }
}

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Clset(int thid,int gi,int as,int di,int vx,int vy,int vz) {
int   ax,ay,az,bx,by,bz,kx,ky,kz,dx,dy,dz,qx,qy,qz,dhor,oiv;
int   done,clcnd,bufval,first,mocmother[CLKMAX],ix,iy,iz,civ,a,b;
double hex,hey,hez,tr[9],xd,yd,zd,ii;
double rx,ry,rz,ix0,ix1,iy0,iy1,iz0,iz1;
Coord cd,cdx,cdy,cdz,*tp;
Exbd *edp=exbd[thid];

Moccopy(&mocmother[0],&edp->dhar[Lreader(Ldhn,&edp->moclp)].moc[0]);
edp->smocnew=0; done=NO;
dhor=edp->dhnr+1;
memcpy(&tr[0],&edp->actdgr.tr[0],sizeof(double)*9);
qx=0; qy=0; qz=0; // to avoid warning
oiv=Lreader(Ldhn,&edp->moclp);
edp->dltcrt=edp->dhar[oiv].dltcrt;
xd=-1; yd=-1; zd=-1;

// ellissoid: semi-axes, centre and displacement
hex=(double)abs((edp->actdgr.dpl[7].x-edp->actdgr.dpl[0].x))/2;
hey=(double)abs((edp->actdgr.dpl[7].y-edp->actdgr.dpl[0].y))/2;
hez=(double)abs((edp->actdgr.dpl[7].z-edp->actdgr.dpl[0].z))/2;
kx=2*DPLMAX/2; dx=(int)hex+edp->actdgr.dpl[0].x;
ky=2*DPLMAX/2; dy=(int)hey+edp->actdgr.dpl[7].y;
kz=2*DPLMAX/2; dz=(int)hez+edp->actdgr.dpl[0].z;

// for speed
if(NDIMS==2) { a=-1; b=-1; hez=1; kz=0; dz=0; }
if(NDIMS==3) { a=+1; b=+1; }

// xxxx
for(ix=0;ix<2;ix++) for(iy=0;iy<2;iy++) for(iz=0;iz<2;iz++)
for(bz=(kz-(int)hez-1);bz<=(kz+(int)hez+1);bz++)
for(by=(ky-(int)hey-1);by<=(ky+(int)hey+1);by++)
for(bx=(kx-(int)hex-1);bx<=(kx+(int)hex+1);bx++) {
   first=NO;
   if((bx==(kx-(int)hex-1))&&(ix==0)&&
      (by==(ky-(int)hey-1))&&(iy==0)&&
      (bz==(kz-(int)hez-1))&&(iz==0)) first=YA;
   bufval=edp->buf0[bx][by][bz];
   if(bufval!=6) {
      rx=(tr[0]*(bx-kx)+tr[1]*(by-ky)+tr[2]*(bz-kz));
      ry=(tr[3]*(bx-kx)+tr[4]*(by-ky)+tr[5]*(bz-kz));
      rz=(tr[6]*(bx-kx)+tr[7]*(by-ky)+tr[8]*(bz-kz));

      // to make nore robust: if difference is too big, takes the other boundary
      ix0=floor(rx); //if(fabs(ix0-rx)>0.98) ix0=ceil (rx);
      ix1=ceil (rx); //if(fabs(ix1-rx)>0.98) ix1=floor(rx);
      iy0=floor(ry); //if(fabs(iy0-ry)>0.98) iy0=ceil (ry);
      iy1=ceil (ry); //if(fabs(iy1-ry)>0.98) iy1=floor(ry);
      iz0=floor(rz); //if(fabs(iz0-rz)>0.98) iz0=ceil (rz);
      iz1=ceil (rz); //if(fabs(iz1-rz)>0.98) iz1=floor(rz);

      if(ix==0) ax=vx+dx+(int)ix0;
      if(ix==1) ax=vx+dx+(int)ix1;
      if(iy==0) ay=vy+dy+(int)iy0;
      if(iy==1) ay=vy+dy+(int)iy1;
      if(iz==0) az=vz+dz+(int)iz0;
      if(iz==1) az=vz+dz+(int)iz1;
      if(NDIMS==2) az=0;
      if((ax<0)||(ax>=GRIDX)||(ay<0)||(ay>=GRIDY)||(az<0)||(az>=GRIDZ))
         goto GTLBBB;
      if(xd<abs(ax-vx)) { xd=abs(ax-vx); cdx.x=ax; cdx.y=ay; cdx.z=az; }
      if(yd<abs(ay-vy)) { yd=abs(ay-vy); cdy.x=ax; cdy.y=ay; cdy.z=az; }
      if(zd<abs(az-vz)) { zd=abs(az-vz); cdz.x=ax; cdz.y=ay; cdz.z=az; }
      if((bufval==7)||(bufval==8)) {        //normal (7) or delete (8) signal
         if(bufval==7) { Moccopy(&edp->mocnew[0],&mocmother[0]); clcnd=CLALIVN; }
         if(bufval==8) { Moccopy(&edp->mocnew[0],&edp->moc0[0]); clcnd=CLCHOLN; }
         if(done==YA) goto GTLAAA;
         if(bufval==7) { edp->smocnew=+1; }                         // normal
         if(bufval==8) { edp->smocnew=-1; }                         // delete
         cd.x=ax; cd.y=ay; cd.z=az;
         edp->isval=0;
         Dharupd (thid,gi,as,di,NO,clcnd,1,&cd);
         done=YA;
         GTLAAA:cvar=cvar;
         #if(NOCANC==1)
         civ=Lreader(Lcnd,&edp->clar[ax][ay][az]);
         if(bufval==7)
         if((civ==CLALIVE)||(civ==CLALIVN)) goto GTLCCC;
         #endif
         #if(NOCANC==2)
         civ=Lreader(Lcnd,&edp->clar[ax][ay][az]);
         if((bufval==7)||(bufval==8))
         if((civ==CLALIVE)||(civ==CLALIVN)) goto GTLCCC;
         #endif
         cd.x=ax; cd.y=ay; cd.z=az;
         Daughter(thid,gi,as,di,NO,clcnd,dhor,&cd);
         Dthrmnet(thid,gi,as,di,NO,clcnd,dhor,&cd);
         GTLCCC:cvar=cvar;
      }
      if((ix==1)&&(iy==1)&&(iz==1)) // last cycle to avoid drv get cancelled
      if((bufval==9)||(first==YA)) {         // driver signal
         edp->smocnew++; clcnd=CLALIVN;      // also on mother pos, just once
         Moccopy(&edp->mocnew[0],&mocmother[0]);
         cd.x=ax; cd.y=ay; cd.z=az;
         edp->isval=0;
         Dharupd (thid,gi,as,di,YA,clcnd, 1,&cd);
         if(bufval==9) { qx=ax; qy=ay; qz=az; }
         if(first==YA) { qx=vx; qy=vy; qz=vz; }
         cd.x=ax; cd.y=ay; cd.z=az;
         Daughter(thid,gi,as,di,YA,clcnd,-1,&cd);
         Dthrmnet(thid,gi,as,di,YA,clcnd,-1,&cd);
      }
      GTLBBB:cvar=cvar;
   }
}

#if(DOPNEW==YA)
#if(CFLAG7==YA)
if (xd!=-1) if (yd!=-1) if (zd!=-1)
if((edp->dgare[di].dgo.ms0==1)||(edp->dgare[di].dgo.ms0==3)) {
   edp->smocnew++; clcnd=CLALIVN;
   Dharupd (thid,gi,as,di,YA,dltcrt,&moc[0],1,&cdx);
   Daughter(thid,gi,as,di,YA,dltcrt,clcnd, -1,&cdx);
   Dthrmnet(thid,gi,as,di,YA,dltcrt,clcnd, -1,&cdx);
   edp->dhar[edp->dhnr].sigsrc=as;
   edp->smocnew++; clcnd=CLALIVN;
   Dharupd (thid,gi,as,di,YA,dltcrt,&moc[0],1,&cdy);
   Daughter(thid,gi,as,di,YA,dltcrt,clcnd, -1,&cdy);
   Dthrmnet(thid,gi,as,di,YA,dltcrt,clcnd, -1,&cdy);
   edp->dhar[edp->dhnr].sigsrc=as;
   edp->smocnew++; clcnd=CLALIVN;
   Dharupd (thid,gi,as,di,YA,dltcrt,&moc[0],1,&cdz);
   Daughter(thid,gi,as,di,YA,dltcrt,clcnd, -1,&cdz);
   Dthrmnet(thid,gi,as,di,YA,dltcrt,clcnd, -1,&cdz);
   edp->dhar[edp->dhnr].sigsrc=as;
}
#endif
#endif

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Dharupd(int thid,int gi,int as,int di,int drv,int clcnd,int clr,Coord *cd) {
int  hi,si,ii,smocmax,aiv,biv,pres;
Dgx *dgx;
Exbd *edp=exbd[thid];

dgx=&edp->dgare[di]; if (di==-1) dgx=&edp->dgx0;

#if(CFLAG0==YA)
edp->mocnew[as-edp->dltcrt]=edp->smocnew;
#endif

aiv=1;
if(edp->dhnr>=0)
   aiv=memcmp(&edp->dhar[edp->dhnr].moc[0],&edp->mocnew[0],sizeof(int)*CLKMAX);

if(aiv) {
   if((edp->dhnr+1)<=(DHARLS-1)) {
      edp->dhnr++;
      for(hi=0;hi<CLKMAX;hi++) edp->dhar[edp->dhnr].moc[hi]=edp->mocnew[hi];
      edp->dhar[edp->dhnr].clr=clr;
      edp->dhar[edp->dhnr].lcrstp=as;
      edp->dhar[edp->dhnr].lcrisc=edp->isval;
      edp->dhar[edp->dhnr].dltcrt=edp->dltcrt;
      edp->dhar[edp->dhnr].actdrv= (drv==1)? 1:0;
      memcpy(&edp->dhar[edp->dhnr].cd,cd,sizeof(Coord));
      #if(NEWCODE==YA)
      for(si=0;si<NMORPH;si++) edp->infmoth[si]=-1;
      if((clr==2)||(clr==3)) {
         for(si=0;si<NMORPH;si++) {
            edp->dhar[edp->dhnr].infmoth[si]=edp->infmoth[si];
            aiv=edp->infmoth[si]; biv=edp->nfdmoth;
            if(aiv>=0)  if(edp->dhar[aiv].actstp<=edp->dhar[biv].actstp) {
               pres=NO;
               for(ii=0;ii<edp->dhar[aiv].ndep;ii++)
                  if (biv==edp->dhar[aiv].depend[ii]) pres=YA;
               if(pres==NO) {
                  edp->dhar[aiv].depend[edp->dhar[aiv].ndep++]=biv;
                  if(edp->dhar[aiv].ndep>=50) Leavexec("\ndepend overflow\n");
               }
            }
         }
      }
      #endif
   }
   else edp->cgok=0;
}

if(clr==1) smocmax=SMOCMA;
else       smocmax=SMOCMB;
if(edp->smocnew>smocmax) {
   printf("smocmax %d %d %d %d %d",thid,gi,as,clr,edp->smocnew); edp->cgok=0; }

}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Daughter(int thid,int gi,int as,int di,int drv,int clcnd,int dhnrnor,Coord *cd) {
int  ax,ay,az,aiv,biv,civ,oiv,conr;
Exbd *edp=exbd[thid];

ax=cd->x; ay=cd->y; az=cd->z;

if(NDIMS==2) { if(az!=0) printf(" z error"); az=0; }

conr=edp->dgare[di].dgo.conr;
aiv=Lreader(Lcol,&edp->clar[ax][ay][az]);    // previous colour
biv=Lreader(Ldrv,&edp->clar[ax][ay][az]);    // previous driver status
civ=Lreader(Lcnd,&edp->clar[ax][ay][az]);    // previous cnd
oiv=Lreader(Ldhn,&edp->clar[ax][ay][az]);    // previous dhn

#if(CFLAG0==YA)
if((civ==CLALIVE)||(civ==CLALIVN)) {
   if(NOCANC==1) if(edp->dhar[oiv].sigstp!=-1) 
      goto GTLEOF; // mothers can't be deleted
   if(NOCANC==2) 
      goto GTLEOF; // all alive cells can't be deleted
}
if(clcnd==CLCHOLN)if(civ==CLNOCEL) clcnd=CLNOCEL;
#endif

// updates drvaro -----------------------------------------
if(biv==1) {
   oiv=Lreader(Ldhn,&edp->clar[ax][ay][az]);
   if(edp->drvaro[oiv].x==ax)
   if(edp->drvaro[oiv].y==ay)
   if(edp->drvaro[oiv].z==az) {
      edp->drvaro[oiv].x=-1;
      edp->cndaro[oiv]=CLNOCEL;
   }
}
// updates drvaro_end -------------------------------------

if (drv==0) Lwriter(Lxxx,&edp->clar[ax][ay][az],dhnrnor,0,clcnd,-1);
if (drv==1) Lwriter(Lxxx,&edp->clar[ax][ay][az],edp->dhnr,1,clcnd,-1);
if (di!=-1) Lwriter(Lxxx,&edp->clar[ax][ay][az],-1,-1,-1,conr);
else        Lwriter(Lxxx,&edp->clar[ax][ay][az],-1,-1,-1,aiv);

#if(CFLAG0==YA)
if(edp->moclp.dhnrc3!=65535)
   edp->clar[ax][ay][az].mother=edp->moclp.dhnrc3;
#endif

// updates drvaro -----------------------------------------
if(drv==1)if(clcnd==CLALIVN) {
   oiv=edp->dhnr;
   edp->drvaro[oiv].x=ax;
   edp->drvaro[oiv].y=ay;
   edp->drvaro[oiv].z=az;
   edp->cndaro[oiv]=CLALIVN;
}
// updates drvaro_end -------------------------------------

GTLEOF:cvar=cvar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Body::Dthrmnet(int thid,int gi,int as,int di,int drv,int clcnd,int dhnrnor,Coord *cd) {
#if(MNETON==YA)
char cvar=0;
int  *ivard,ii=0,si,ox,mclnr,ax,ay,az;
Clsr *neucl; Mcl mclold;
Exbd *edp=exbd[thid];

ax=cd->x; ay=cd->y; az=cd->z;

if (di==-1) memcpy(&mclold,&edp->mtar[edp->clar[ax][ay][az].mclnr],sizeof(Mcl));
edp->clar[ax][ay][az].mclnr=edp->dhnr;
mclnr=edp->clar[ax][ay][az].mclnr; // tmp var
if (di==-1) memcpy(&edp->mtar[edp->clar[ax][ay][az].mclnr],&mclold,sizeof(Mcl));
if (di==-1) edp->mtar[mclnr].set=0;
neucl=&edp->clar[ax][ay][az];

if (edp->mtar[mclnr].set==0) if((drv==1)||(edp->dhnr==dhnrnor)) {
   // olrxxx
   if(di!=-1) {
      edp->mtar[mclnr].olrxxx=edp->dgare[di].dgo.olrxxx;
      // inherits from mother and applies changes encoded by devgene ----------
      // oxarap - inherits mother's        // from metabol.
      for(ox=0;ox<OXARSZ;ox++) edp->mtar[mclnr].oxarap[ox]=edp->momcl.oxarap[ox];
      // oxarap - introduces changes
      for(ii=0;ii<OXRCHD;ii++) if(di!=-1) {
         if(edp->dgare[di].dgo.oxrchd[ii]<OXARSZ) {
            ivard=&edp->mtar[mclnr].oxarap[edp->dgare[di].dgo.oxrchd[ii]];
            if(*ivard==0) *ivard=1;
            else          *ivard=0;
         }
      }
      // iosmsk
      for(ii=0;ii<2;ii++) for(si=0;si<SZSUSP;si++)
         edp->mtar[mclnr].iosmsk[ii][si]=
         (di!=-1) ? edp->dgare[di].dgo.iosmsk[ii][si] : -1;
      // inherits from mother and applies changes encoded by devgene_end ------
   }
   else edp->mtar[mclnr].olrxxx=-1; // doping-generated drivers are marked
   edp->mtar[mclnr].set=1;
}
#endif

}

