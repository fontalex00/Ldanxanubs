
#include "danxparx.h"

// Include generic
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include <float.h>
//#include <conio.h>  // HINT UNIX
#if(MYOMP==1)
#include <omp.h>
#endif
#if(MYMPI==1)
#include <mpi.h>
#endif

// Include specific
#include "danxopro.h"

