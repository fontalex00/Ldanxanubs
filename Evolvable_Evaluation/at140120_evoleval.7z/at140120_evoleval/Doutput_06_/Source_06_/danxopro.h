
// Fwd declarations
class Pop; class Cell; class Body;

typedef unsigned char uchar;

typedef struct {
   int x,y,z;
}  Coord;

typedef struct {
   uchar neugy;
   int   gen[GENXSZ],parents[2]; // parents
   float gaft,shad,mfit;        // gaft: GA fitness, shad: shape adherence
}  Guy;

typedef struct {
   int bval; int flag;
}  Gnpbase;

typedef struct {
   int d0,e0; //int d0,dd,ds,e0,ee,ms;
}  Dpel;

typedef int  dimensa[GRIDY][GRIDZ];

typedef Dpel dimensb[GRIDX][GRIDY][GRIDZ];

typedef Dpel dimensc[GRIDY][GRIDZ];

typedef struct {
   Coord  dpl[8]; double tr[9];
   int ms0,ms1,conr,c2nr,gas; // gas: GRN activity status
   int olrxxx,iosmsk[2][SZSUSP],oxrchd[OXRCHD];//metab
}  Dgo; // developmental gene's output

typedef struct {
   int exord,swc,timer,res[CLKMAX],dhnrx[3],dhptx,arpos,napos,fsc,exeas,dvfrd;
   int stepeval;
   Dgo dgo;
}  Dgx; // developmental gene

typedef struct {
   int actgen,copies;
   Dgx dgx;
}  Dgf; // developmental gene frozen

typedef struct {
   Coord cd; Dgo dgo; // dgo for grn
   int moc[CLKMAX],clr;
   int lcrstp,lcrisc,actstp,sigstp,dltcrt,actdrv; // lcrstp = last creation step
   int depend[50],ndep,infmoth[NMORPH]; // actstp is the activation step
}  Dse; // driver set element

typedef struct {
   int ge,xf,xe,ls,us,dl,fs; // up: upper phase
}  Frz;

// Mnet ---------------------------------------------------

typedef struct {
   int   act,oxarpos;
   int   isui[MAXIPS],osui; // i/osui: i/o substance identifier
   double whts[MAXIPS+1],ival[MAXIPS],oval;
   int   lrxx; int cndx; int oxcd;
}  Oxr; // cndx:=-1 if never evolved, =0 if not active, =1 if active

typedef struct {
   int   olrxxx,oxarap[OXARSZ],iosmsk[2][SZSUSP],set; //outside lr, i/o sub. mask
}  Mcl; // Mcl: metabolic cell.         // oxar act. pat.

typedef struct {
   Coord iopar[2][1]; // point coords in whose nbhood drivers must be searched
   Coord iodar[2][1]; // point coords in which closest drivers are
   float iotar[2][EXARSZ][SZSUSP];
}  Mtv; // Mtv: metabolic target values

// Mnet_end -----------------------------------------------

typedef struct {
   unsigned short dhnrc3; //unsigned dhnrc3;
   unsigned char drv,cnd,col;
   #if(MNETON==YA)
   int mclnr; // sostituire con mclnr (int): posizione in mxxxar
   #endif
   unsigned mother;
}  Clsr; // Cell struct

typedef struct {
   // Target
   dimensa * etisooodp0grid;
   dimensa * cdisooodp0grid;
   dimensa * cdtgooodplgrid;
   // Actual, as grids
   dimensc * oocurdsgrid;
   Mtv  mtv;
}  Envir;

typedef struct {
   int   mphval[NMORPH],cntdrv[NMORPH],close,surfc,mother;
   float dst; Coord cd;
}  Aposel;

typedef struct {
   int   mphval[NMORPH],cntdrv[NMORPH],mother,ptr,sza,onr;
   float dst; Coord *cds;
}  Ntpel;

typedef struct {
   int smocnu,mother; Coord cd;
}  Pmocel;

typedef struct {
   int   crtpnr,sigdlt,sigtyp,morphx[NMORPH]; Coord cd;
}  Sigel;

typedef struct {
   int   swc,ifp,thp,cdn,csn; // decoded csn: contribution sign
   int   act;
}  Sgen;

typedef struct {
   // --- xxxxxxxx ----------------------------------------------------------
   Pop    *popa[NPOPUL];
   Envir  envr;
   Clsr   clar [GRIDX][GRIDY][GRIDZ],clarq[8][DPVMAX],clard[DHARLS],moclp;
   Clsr   clar0[GRIDX][GRIDY][GRIDZ];
   Coord  clardcd[DHARLS];
   Dse    dhar[DHARLS];
   int    dhnr;
   // --- Dvarprep & chx sort -----------------------------------------------
   Dgx    dgar[DGARSZ],dgaro[DGARSZ],dgare[DGARSZ],dgarr[DGARSZ];
   int    dgarxf,dgarsz,dgarszo,dgarsze,dgarszr;
   int    ordaux[DGARSZ],auxarp[DHARLS],scord[DGARSZ];
   float  scorar[DGARSZ],par[DGARSZ];
   int    stepeval,stepevly,stepevlz;
   // step at which fitness is evaluated, under genetic control
   // Cvare
   Dgo    actdgr; // active dg right part
   int    cgok,clok,bci[8],rci[8],uui[8];
   int    buf0[2*DPLMAX][2*DPLMAX][2*DPLMAX];
   int    dltcrt,smocnew,mocnew[CLKMAX];
   // Cvare_end
   // --- arrays of drivers -------------------------------------------------
   Coord  drvaro[DHARLS],drvar1[DHARLS];
   int    cndaro[DHARLS],cndar1[DHARLS];
   int    clarcnd[GRIDX][GRIDY][GRIDZ];
   // --- movie -------------------------------------------------------------
   dimensc *bstepsgrid,*estepsgrid,*xstepsgrid;
   int    *divpar; Coord *divpts;
   // --- initial values ----------------------------------------------------
   int    moc0[CLKMAX]; Coord cd0; Dgo dgo0; Dgx dgx0; Dse dse0; Guy guy0;
   Cell   *cl0; Clsr cs0; Dpel dpel0; Aposel aposel0; Sigel sigel0;
   // --- rrord
   Coord  rrorder[1][1][1][GRIDX*GRIDY*GRIDZ];             // use: freq rd
   float  rrodist[1][1][1][GRIDX*GRIDY*GRIDZ];             // use: freq rd
   int    rrord           [GRIDX*GRIDY*GRIDZ];             // use: freq rd
   // --- xxxxxxxx ----------------------------------------------------------
   Frz    frz[NAMS];
   int    zygx[4],zygy[4],zygz[4],ausdr,cn,cn0,gq,xq,fset,xqar[DGARSZ],fdone;
   int    tcvltr[DHARLS],tcvlts[DHARLS];
   int    pnr;
   int    rndpmt[NNGUYS];
   // --- Calcfit
   float  shdhst[FITHST][NNGUYS],fithst[FITHST][NNGUYS];
   // --- 0's and first -----------------------------------------------------
   int    dhnr0,dhnro,stepeval0;
   Dse    dharaz[1][DHARLS];
   #if(MOCDEV==YA)
   Dse    dharal[NNGUYS][DHARLS],dharaltemp[DHARLS];
   int    dhnral[NNGUYS],dhnraltemp;
   #endif
   Dse    dhar0 [DHARLS],*dharo;                              // use: freq wr
   Dgx    dgar0 [DGARSZ];
   Coord  drvar0[DHARLS];
   int    evtnr0[CLKMAX],evtnr[CLKMAX];
   int    dhnrf;
   Clsr   clarf[GRIDX][GRIDY][GRIDZ];
   Dse    dharf[DHARLS];
   Guy    guyf;
   // --- Other -------------------------------------------------------------
   #if(TAGCHK==YA)
   // Tagcheck  -------------------------------------------------------------
   Dgx   frgenesa[NNGUYS][DGEVXX*CLKMAX];//int ancesta[NNGUYS],ftevala[NNGUYS];
   Dgx   frgenesb[NNGUYS][DGEVXX*CLKMAX];//int ancestb[NNGUYS],ftevalb[NNGUYS];
   Dgx   frgenesc[NNGUYS][DGEVXX*CLKMAX];//int ancestc[NNGUYS],ftevalc[NNGUYS];
   Dgx   frgentmp[DGEVXX*CLKMAX];
   Dgf   hstgenes[50000];
   int   hgnr;
   //int   tagcnt[CLKMAX][CLKMAX];
   float taghst[320][CLKMAX+2];
   int   tcount;
   #endif
   // Aux-morphogens  -------------------------------------------------------
   int    ss,sstmp,ps,infmoth[NMORPH],nfdmoth,isval;
   Pmocel pmocs[2000];
   Sigel  sigcells[1000];
   float  fcoef,fdecl,fshad,fmfit;
   Ntpel  ntpdir[NTPDIRSZ];
   Aposel aposar[APOSARSZ];
   // Mnet ------------------------------------------------------------------
   //#if(MNETON==YA)
   int    oxarsz;
   Oxr    oxar  [OXARSZ]; // operational vs of oxar
   Mcl    mtar[DHARLS],mtarf[DHARLS]; // metabolic cell array
   Clsr  *drvarh[DHARLS],*drvark[DHARLS]; // ar of drivers (ptr)
   float  lrordh[DHARLS], lrordk[DHARLS]; // 'layer' parameters and aux ar
   Coord  drvcdh[DHARLS], drvcdk[DHARLS],dvcdk0[DHARLS];
   int    auxarr[DHARLS]; // lr sort
   double **drvdst;
   Mcl    momcl,mcl0;
   double intsbc[DHARLS][SZSUSP],extsbc[DHARLS][SZSUSP]; // int & ext sub cnc
   double extsc0[EXARSZ][DHARLS][SZSUSP]; // external subst. concentrations
   int    oxarp0[DHARLS][OXARSZ]; // operators' activations
   //#endif
   // Grn -------------------------------------------------------------------
   int    sgarsz;
   Sgen   sgar[DGARSZ];
   // Neural ----------------------------------------------------------------
   int    neuralds[2][256];
}  Exbd; // Ex body functions (global BUT PRIVATE: each process has a copy)

// AUX FCTS
void   set_fpu (unsigned int mode);
int    Intpower(int bb,int ee);
int    Rnd1(int rnmax);
int    Rnds(int rnmax);
float  Sigmoid0(float xx,float ss);
void   Mysortxxxx(float par[],int szar,int opt,int ord[]);
void   Mysortxdgx(int thid,float par[],int szar,int opt,Dgx *ard,Dgx *ars);
void   Ftsortxdgx(int thid,float par[],int szar,int opt,Dgx *ard,Dgx *ars);
void   Ftsortxdgf(int thid,float par[],int szar,int opt,Dgf *cfardst);
void   Fsortsigca(int thid,int szar,Sigel *sigcar);
void   Fsortntpdr(int thid,int szar,Ntpel *ntpar);
void   Mysortlrxx(int thid,float par[],int szar,int opt,Clsr *ard[],Clsr *ars[]);
void   Gencpy(int gen1[],int gen0[],int b0,int ncopied);
void   Leavexec(char *str);
void   Cvbase2int(int basear[],int   *ndec0,int szar,int base,int *arind);
void   Cvint2base(int basear[],int   *ndec0,int szar,int base,int *arind);
void   Cvbase2flt(int basear[],float *nflt0,int szar,int base,int *arind);
void   Varrescale(int *var,int scale0,int scale1);
int    Mocmatch (int *res,int *moc,int naposmin,int fscmax,int *napos,int *fsc);
void   Moccopy(int mocd[],int mocs[]);
double Distance(int nx,int ny,int nz,int xx,int yy,int zz);
double Dopdst(Coord *aa,Coord *bb);
double Dopdxt(Coord *aa,Coord *bb,int sw);
void   Gpstatsx(Body *bdp);
void   Setbitmask(void);
int    Lreader(int par,Clsr *clp);
void   Lwriter(int par,Clsr *clp,int dhnneu,int drvneu,int cndneu,int colneu);
double Max3(double d0,double d1,double d2);
int    Surfint(int as,Coord *cd,Exbd *edp); // surface interior
void   Setedges(Coord *e0,Coord *e7,Coord e[]);
int    Getthid(Exbd **edpp);
void   Mpscpy(char *sndbuf, void *srcdat, int size, int *cnt);
void   Mprcpy(void *dstdat, char *recbuf, int size, int *cnt);
void   Avgcd(Coord cdar[],int szar,Coord *avgcd);
void   Printf3(FILE *fptr, char *fmt);
void   Sanchkdob(double *var,double aa,double bb);
// Aux fcts: debug & temporary

//!--------------------------------------------------------------------------
//! header
//!--------------------------------------------------------------------------
class Pop {
/*VARS*/ public:
Body    *popbdp;
int     dnaxf,dnasz,popsz,spopsz0,spopsz1,nkids0,nkids1;
Gnpbase dnp[GENXSZ];
Guy     guys[POPXSZ],*chmp;
/*FCTS*/ public:
void Genrnd(int thid,int ngen);
void Reproduction(int thid,int sons);
void Decimation(int thid,int ndeads, uchar deathtype);
void Crossover(int thid,float pcross);
void Mutation(int thid,float pcmutx,float maxpercmut);
void Gycp (int opt,Guy gard[],Guy gars[],int gd,int gs,int n);
void Galoop(int thid,int opt);
Pop (int thid,Body * bdp);
virtual void Gendecoder(int thid,int gen[],Guy *gyp,int opt);
//virtual void Genoocoder(int gen[]);
virtual uchar Genvalid(int thid,int gen[],Guy *gyp);
virtual void Cons(int thid,Body * _popbdp);
};

//!--------------------------------------------------------------------------
//! header
//!--------------------------------------------------------------------------
class Body { // all these vars are (should be) shared by all threads
/*Vars*/ public:

/*FCTS*/ public:
// FILE 1: high-level
Body(void);
int  main(int argc, char *argv[], char *env[]);
void Baseloop(int opt,Body *bdp);
void Initlocv(int thid);
void Envinit (int thid,int opt);
void Bodinit (int thid);
void Loadgrid(int thid,char *file,int opt,char *file2);
void Sendrec0(int nr,char *buffer,long *buflen0);
void Sendrecv(int nr,char *buffer,long *buflen1,long *buflen3);
// File 2: geometry-related
void Disrupt (int thid,int gi,int as);
void Dgarprep(int thid,int gi,int as,int ss); // ss: start step
void Shaper  (int thid,int gi,int as,int us);
void Movie   (int thid,int gi,int as,int us,int cgevnr);
void Brush   (int thid,int gi,int as,int di,int vx,int vy,int vz);
void Clset   (int thid,int gi,int as,int di,int vx,int vy,int vz);
void Dharupd (int thid,int gi,int as,int di,int drv,int clcnd,int clr,Coord *cd);
void Daughter(int thid,int gi,int as,int di,int drv,int clcnd,int dhnrnor,Coord *cd);
void Dthrmnet(int thid,int gi,int as,int di,int drv,int clcnd,int dhnrnor,Coord *cd);
// File 3
void Dopernew(int thid,int gi,int as,int is,int op);
void Doper2  (int thid,int gi,int as);
void Closedr (int thid,int gi,int ex,int ey,int ez,int ii,int*moc);
void Remred  (int thid,int gi,int as,int di,int lx,int ly,int lz,int it);
void Gridinit(int thid,int gi,int as);
void Gridupd (int thid,int gi,int as,int us,int ff);
float Fitbox (int thid,int gi,int lx,int ly,int lz,int ux,int uy,int uz,float *shas);
// File 4
void Calcfit (int thid);
void Showres (int thid,FILE *fpb,char *atmpstr);
void Loadmemo(int thid);
void Savememo(int thid);
void Savegrid(int thid,int opt,int hi);
void Prexline(int thid);
void Germline(int thid);
void Copyclsr(Clsr *csd,Clsr *css);
void Moveclsr(int thid,Clsr *csd,Clsr *css);
// FILE 4: Mnet, Tagchck, GRN
float Mnetcalc(int thid,int gi);
double Forward(Oxr *oxr); // operation NN-like
void  Iogener(int thid);
void Tagchck2(int thid);
void Tagchck3(int thid);
void Grncalc (int thid);
// FILE 4: neural computation
void  Dsload(int thid);
};


